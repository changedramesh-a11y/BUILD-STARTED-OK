import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Shield, Mail, ArrowLeft } from "lucide-react";

const ForgotPassword = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  const sendCode = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!email.trim()) { toast.error("Enter your registered email id"); return; }
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    setSent(true);
    toast.success("Verification sent to your email");
  };

  const verify = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.verifyOtp({ email: email.trim(), token: code.trim(), type: "recovery" });
    setLoading(false);
    if (error) { toast.error("Invalid or expired code"); return; }
    navigate("/reset-password");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-4">
            <Shield className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-extrabold font-heading text-gradient">MISSION JSSC</h1>
          </div>
          <h2 className="text-lg font-semibold text-foreground">Forgot password</h2>
          <p className="text-sm text-muted-foreground mt-1">Enter the email id you signed up with.</p>
        </div>
        <div className="bg-card rounded-xl card-shadow p-6 border border-border space-y-4">
          <form onSubmit={sendCode} className="space-y-4">
            <Input type="email" placeholder="Your registered email id" value={email}
              onChange={(e) => setEmail(e.target.value)} required disabled={sent && loading} />
            <Button type="submit" className="w-full gap-2" disabled={loading}>
              <Mail className="h-4 w-4" /> {sent ? "Resend verification code" : "Send verification code"}
            </Button>
          </form>
          {sent && (
            <form onSubmit={verify} className="space-y-3 border-t border-border pt-4">
              <p className="text-sm text-muted-foreground">
                Check your inbox (and spam). Tap the link in the email, or type the code from it here.
              </p>
              <Input inputMode="numeric" placeholder="Verification code" value={code}
                onChange={(e) => setCode(e.target.value)} required minLength={6} />
              <Button type="submit" variant="secondary" className="w-full" disabled={loading}>
                Verify & set new password
              </Button>
            </form>
          )}
          <Link to="/auth" className="flex items-center justify-center gap-1 text-sm text-muted-foreground hover:text-primary">
            <ArrowLeft className="h-4 w-4" /> Back to sign in
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;
