import { useMemo } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { ArrowLeft, BookOpen, Clock, Users, Trash2 } from "lucide-react";
import { toast } from "sonner";
import BottomTabBar from "@/components/BottomTabBar";
import SaveButton from "@/components/SaveButton";
import MockDeleteButton from "@/components/MockDeleteButton";
import TestRankBadge from "@/components/TestRankBadge";

interface Quiz {
  id: string;
  title: string;
  description: string;
  type: string;
  category: string;
  exam_mode: "central" | "jharkhand";
  duration_minutes: number;
  total_questions: number;
}

interface Attempt {
  id: string;
  quiz_id: string;
  score: number;
  max_marks: number;
  total_questions: number;
}

const DailyQuiz = ({ quizType = "daily_quiz" }: { quizType?: "daily_quiz" | "weekly_mock" }) => {
  const isWeekly = quizType === "weekly_mock";
  const pageTitle = isWeekly ? "Weekly Mock" : "Daily Quiz";
  const { user, role } = useAuth();
  const navigate = useNavigate();
  const client = useQueryClient();
  const examMode = (localStorage.getItem("exam_mode") as "central" | "jharkhand") || "central";
  const canManage = role === "admin" || role === "moderator";
  const listKey = ["test-list", user?.id, examMode, quizType];
  const listing = useQuery({ queryKey: listKey, queryFn: async ({ signal }) => {
    const { data, error } = await supabase.from("quizzes")
      .select("id,title,description,type,category,exam_mode,duration_minutes,total_questions")
      .eq("is_published", true).eq("type", quizType).eq("exam_mode", examMode)
      .order("created_at", { ascending: false }).abortSignal(signal);
    if (error) throw error;
    return (data || []) as Quiz[];
  } });
  const quizzes = listing.data || [];
  const history = useQuery({ queryKey: ["test-attempts", user?.id, examMode, quizType, quizzes.map(q => q.id)], enabled: Boolean(user) && quizzes.length > 0, queryFn: async ({ signal }) => {
    if (!user) return [];
    const { data, error } = await supabase.from("attempts")
      .select("id,quiz_id,score,max_marks,total_questions,created_at")
      .eq("user_id", user.id).in("quiz_id", quizzes.map(q => q.id))
      .order("created_at", { ascending: false }).abortSignal(signal);
    if (error) throw error;
    return data || [];
  } });
  const attempts = useMemo(() => {
    const map: Record<string, Attempt> = {};
    (history.data || []).forEach(a => { if (!map[a.quiz_id]) map[a.quiz_id] = a; });
    return map;
  }, [history.data]);
  const loading = listing.isLoading || (quizzes.length > 0 && history.isLoading);
  const loadError = listing.isError || history.isError;
  const setQuizzes = (next: Quiz[] | ((previous: Quiz[]) => Quiz[])) => {
    client.setQueryData<Quiz[]>(listKey, previous => typeof next === "function" ? next(previous || []) : next);
    void client.invalidateQueries({ queryKey: ["home-feed"] });
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="bg-[hsl(var(--header-bg))] text-[hsl(var(--header-fg))]">
        <div className="container mx-auto px-3 py-3 flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/home")} aria-label="Back to Home">
            <ArrowLeft className="h-6 w-6" />
          </Button>
          <h1 className="font-bold font-heading text-base">{pageTitle}</h1>
          <span className="ml-auto text-xs bg-white/15 rounded-full px-2 py-0.5">
            {examMode === "central" ? "Central" : "Jharkhand"}
          </span>
        </div>
      </header>

      <main className="container mx-auto px-4 pt-5">
        <p className="text-sm text-muted-foreground mb-4">
          {isWeekly ? "Weekly mocks" : "Fresh daily quizzes"} for your {examMode === "central" ? "Central" : "Jharkhand"} exam preparation.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {loading ? (
            <div className="col-span-full text-center py-12 text-muted-foreground">Loading...</div>
          ) : loadError ? (
            <div className="col-span-full text-center py-12 space-y-3">
              <p className="text-destructive">Unable to load {isWeekly ? "weekly mocks" : "daily quizzes"}.</p>
              <Button variant="outline" onClick={() => { void listing.refetch(); void history.refetch(); }}>Retry</Button>
            </div>
          ) : quizzes.length === 0 ? (
            <div className="col-span-full text-center py-12">
              <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No {isWeekly ? "weekly mocks" : "daily quizzes"} available yet for this exam mode</p>
            </div>
          ) : (
            quizzes.map((quiz) => {
              const attempt = attempts[quiz.id];
              return (
                <div
                  key={quiz.id}
                  className={`bg-card rounded-xl p-4 card-shadow border cursor-pointer ${
                    attempt ? "border-primary/30" : "border-border"
                  } hover:card-shadow-hover`}
                  onClick={() =>
                    attempt
                      ? navigate("/result", { state: { attemptId: attempt.id, quizId: quiz.id } })
                      : navigate(`/quiz/${quiz.id}`)
                  }
                >
                  <div className="flex flex-wrap items-center gap-2 mb-1.5">
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-full gradient-sunset text-white">
                      {isWeekly ? "WEEKLY MOCK" : "📅 DAILY"}
                    </span>
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-full gradient-ocean text-white">
                      {quiz.category}
                    </span>
                    {attempt && <TestRankBadge quizId={quiz.id} />}
                  </div>
                  <h3 className="font-semibold font-heading text-foreground text-sm">{quiz.title}</h3>
                  {quiz.description && (
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{quiz.description}</p>
                  )}
                  {attempt && <p className="mt-2 text-center text-xl font-bold text-home-blue">Score {attempt.score}/{attempt.max_marks || attempt.total_questions}</p>}
                  <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" /> {quiz.duration_minutes}m
                    </span>
                    <span className="flex items-center gap-1">
                      <Users className="h-3 w-3" /> {quiz.total_questions}Q
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mt-3">
                    <SaveButton target="quiz" id={quiz.id} />
                    <Button size="sm" variant="outline" className="flex-1 text-xs h-8">
                      {attempt ? "📊 View Result" : "▶️ Start"}
                    </Button>
                    {<MockDeleteButton id={quiz.id} title={quiz.title} type={quiz.type} onDeleted={() => setQuizzes(previous => previous.filter(item => item.id !== quiz.id))} />}
                    {!isWeekly && canManage && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-xs h-8 text-destructive"
                        onClick={async (e) => {
                          e.stopPropagation();
                          if (!confirm(`Delete "${quiz.title}"?`)) return;
                          const { error } = await supabase.from("quizzes").delete().eq("id", quiz.id);
                          if (error) {
                            toast.error(error.message);
                            return;
                          }
                          setQuizzes(quizzes.filter((q) => q.id !== quiz.id));
                          toast.success("Quiz deleted");
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </main>
      <BottomTabBar />
    </div>
  );
};

export default DailyQuiz;
