import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Trophy, Target, CheckCircle2, XCircle, MinusCircle, ArrowLeft, BookOpen, Share2, Medal } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface AttemptRow {
  id: string;
  quiz_id: string;
  score: number;
  total_questions: number;
  max_marks: number;
  percentage: number;
  answers: Record<string, string>;
  created_at: string;
}

const Result = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  const state = (location.state || {}) as { attemptId?: string; quizId?: string };
  const [attempt, setAttempt] = useState<AttemptRow | null>(null);
  const [quizTitle, setQuizTitle] = useState("");
  const [correctCount, setCorrectCount] = useState(0);
  const [wrongCount, setWrongCount] = useState(0);
  const [unattemptedCount, setUnattemptedCount] = useState(0);
  const [rank, setRank] = useState<number | null>(null);
  const [totalParticipants, setTotalParticipants] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      if (!user) return;

      let query = supabase
        .from("attempts")
        .select("id, quiz_id, score, total_questions, max_marks, percentage, answers, created_at")
        .eq("user_id", user.id);

      if (state.attemptId) query = query.eq("id", state.attemptId);
      else if (state.quizId) query = query.eq("quiz_id", state.quizId);

      const { data } = await query.order("created_at", { ascending: false }).limit(1).maybeSingle();

      if (!data) { setLoading(false); return; }
      const row = data as AttemptRow;
      setAttempt(row);

      const { data: quiz } = await supabase.from("quizzes").select("title").eq("id", row.quiz_id).single();
      if (quiz) setQuizTitle(quiz.title);

      const { data: qs } = await supabase.rpc("get_attempt_questions", { p_attempt_id: row.id });
      const questions = (qs as Array<{ id: string; correct_option: string }>) || [];
      const answers = row.answers || {};
      let c = 0, w = 0, u = 0;
      questions.forEach((q) => {
        const a = answers[q.id];
        if (!a) u++;
        else if (a === q.correct_option) c++;
        else w++;
      });
      setCorrectCount(c);
      setWrongCount(w);
      setUnattemptedCount(u);

      // Ranking: best attempt per user for this quiz, ordered by percentage desc then earliest created_at
      const { data: allAttempts } = await supabase
        .from("attempts")
        .select("user_id, percentage, created_at")
        .eq("quiz_id", row.quiz_id)
        .order("percentage", { ascending: false })
        .order("created_at", { ascending: true });
      if (allAttempts) {
        const bestPerUser = new Map<string, { percentage: number; created_at: string }>();
        allAttempts.forEach((a: any) => {
          if (!bestPerUser.has(a.user_id)) bestPerUser.set(a.user_id, a);
        });
        const sorted = Array.from(bestPerUser.entries()).sort((a, b) => {
          if (b[1].percentage !== a[1].percentage) return b[1].percentage - a[1].percentage;
          return new Date(a[1].created_at).getTime() - new Date(b[1].created_at).getTime();
        });
        setTotalParticipants(sorted.length);
        const myRank = sorted.findIndex(([uid]) => uid === user.id);
        if (myRank >= 0) setRank(myRank + 1);
      }
      setLoading(false);
    };
    load();
  }, [state.attemptId, state.quizId, user]);

  const handleShare = async () => {
    if (!attempt) return;
    const pct = attempt.percentage ?? 0;
    const text = `🎯 I scored ${attempt.score}/${attempt.max_marks || attempt.total_questions} (${pct}%) on "${quizTitle}"${rank ? ` — Rank #${rank} of ${totalParticipants}` : ""}! Can you beat me?`;
    const url = window.location.origin;
    try {
      if (navigator.share) {
        await navigator.share({ title: "My Quiz Scorecard", text, url });
      } else {
        await navigator.clipboard.writeText(`${text}\n${url}`);
        toast({ title: "Copied to clipboard" });
      }
    } catch {}
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-muted-foreground">Loading result...</div>;
  }

  if (!attempt) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-4">
        <div className="w-full max-w-sm bg-card border border-border rounded-xl p-5 text-center space-y-4">
          <p className="text-sm text-muted-foreground">Result not found.</p>
          <Button className="w-full" onClick={() => navigate("/home", { replace: true })}>Back to Dashboard</Button>
        </div>
      </div>
    );
  }

  const pct = attempt.percentage ?? Math.round((Number(attempt.score) / Math.max(1, Number(attempt.max_marks || attempt.total_questions))) * 100);

  return (
    <div className="min-h-screen bg-background pb-10">
      <header className="sticky top-0 z-20 bg-[hsl(var(--header-bg))] text-[hsl(var(--header-fg))] px-4 py-3 flex items-center gap-3">
        <button onClick={() => navigate("/home")} aria-label="Back"><ArrowLeft className="h-5 w-5" /></button>
        <h1 className="flex-1 text-sm font-semibold truncate">Result</h1>
      </header>

      <main className="px-4 pt-6 max-w-lg mx-auto space-y-5">
        <div className="bg-card border border-border rounded-2xl p-6 text-center space-y-3">
          <Trophy className="h-10 w-10 mx-auto text-[hsl(var(--tb-green))]" />
          <h2 className="text-base font-semibold text-foreground">{quizTitle}</h2>
          <div className="text-4xl font-bold text-foreground">
            {Number(attempt.score)} <span className="text-base font-medium text-muted-foreground">/ {Number(attempt.max_marks || attempt.total_questions)}</span>
          </div>
          <div className="flex items-center justify-center gap-2 flex-wrap">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[hsl(var(--tb-green-soft))] text-[hsl(var(--tb-green))] text-sm font-semibold">
              <Target className="h-4 w-4" /> {pct}%
            </div>
            {rank && (
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[hsl(var(--tb-blue-soft))] text-[hsl(var(--tb-blue))] text-sm font-semibold">
                <Medal className="h-4 w-4" /> Rank #{rank} / {totalParticipants}
              </div>
            )}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div className="bg-card border border-border rounded-xl p-3 text-center">
            <CheckCircle2 className="h-5 w-5 mx-auto text-[hsl(var(--tb-green))]" />
            <div className="text-lg font-bold text-foreground mt-1">{correctCount}</div>
            <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Correct</div>
          </div>
          <div className="bg-card border border-border rounded-xl p-3 text-center">
            <XCircle className="h-5 w-5 mx-auto text-[hsl(var(--tb-red))]" />
            <div className="text-lg font-bold text-foreground mt-1">{wrongCount}</div>
            <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Wrong</div>
          </div>
          <div className="bg-card border border-border rounded-xl p-3 text-center">
            <MinusCircle className="h-5 w-5 mx-auto text-muted-foreground" />
            <div className="text-lg font-bold text-foreground mt-1">{unattemptedCount}</div>
            <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Skipped</div>
          </div>
        </div>

        <div className="space-y-2">
          <Button className="w-full h-12" onClick={() => navigate(`/attempt/${attempt.id}`)}>
            <BookOpen className="h-4 w-4 mr-2" /> Solution & Review Questions
          </Button>
          <Button variant="outline" className="w-full h-12" onClick={() => navigate(`/leaderboard/${attempt.quiz_id}`)}>
            🏆 Leaderboard
          </Button>
          <Button variant="outline" className="w-full h-12" onClick={handleShare}>
            <Share2 className="h-4 w-4 mr-2" /> Share Scorecard
          </Button>
          <Button variant="ghost" className="w-full h-10" onClick={() => navigate("/home")}>
            Back to Dashboard
          </Button>
        </div>
      </main>
    </div>
  );
};

export default Result;
