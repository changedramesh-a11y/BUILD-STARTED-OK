import { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { toast } from "sonner";
import { optimizeImage } from "@/lib/optimize-image";
import { ArrowLeft, Camera, Save, User, Trophy, Target, BarChart3 } from "lucide-react";

const Profile = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [displayName, setDisplayName] = useState("");
  const [about, setAbout] = useState("");
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [stats, setStats] = useState({ attempts: 0, avgPct: 0, bestPct: 0 });

  useEffect(() => {
    if (!user) return;
    const controller = new AbortController();
    const fetchProfile = async () => {
      const [{ data }, { data: attemptData }] = await Promise.all([
        supabase
          .from("profiles")
          .select("display_name, about, avatar_url")
          .eq("user_id", user.id)
          .abortSignal(controller.signal).maybeSingle(),
        supabase
          .from("attempts")
          .select("percentage")
          .eq("user_id", user.id).abortSignal(controller.signal),
      ]);
      if (controller.signal.aborted) return;
      if (data) {
        setDisplayName(data.display_name || "");
        setAbout(data.about || "");
        setAvatarUrl(data.avatar_url || null);
      }
      if (attemptData && attemptData.length > 0) {
        const pcts = attemptData.map((a: any) => Number(a.percentage) || 0);
        const avg = Math.round(pcts.reduce((s, p) => s + p, 0) / pcts.length);
        const best = Math.max(...pcts);
        setStats({ attempts: pcts.length, avgPct: avg, bestPct: best });
      }
      setLoading(false);
    };
    fetchProfile();
    return () => controller.abort();
  }, [user?.id]);

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    if (file.size > 2 * 1024 * 1024) {
      toast.error("Image must be less than 2MB");
      return;
    }

    setUploading(true);
    try {
      // Pick extension from mime type so camera files without a name still work
      const optimized = await optimizeImage(file, 512);
      const mime = optimized.type || "image/jpeg";
      const ext = mime.split("/")[1]?.split("+")[0] || "jpg";
      const filePath = `${user.id}/avatar-${Date.now()}.${ext}`;

      const { error: uploadError } = await supabase.storage
        .from("avatars")
        .upload(filePath, optimized, {
          upsert: true,
          contentType: mime,
          cacheControl: "3600",
        });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from("avatars")
        .getPublicUrl(filePath);

      const url = `${publicUrl}?t=${Date.now()}`;

      // Ensure profile row exists, then save avatar_url
      const { error: upsertError } = await supabase
        .from("profiles")
        .upsert(
          { user_id: user.id, avatar_url: url },
          { onConflict: "user_id" }
        );

      if (upsertError) throw upsertError;

      setAvatarUrl(url);
      toast.success("Photo updated!");
    } catch (err: any) {
      console.error("Avatar upload failed:", err);
      toast.error(err?.message || "Upload failed");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    try {
      const { data, error } = await supabase
        .from("profiles")
        .upsert(
          {
            user_id: user.id,
            email: user.email,
            display_name: displayName.trim(),
            about: about.trim(),
          },
          { onConflict: "user_id" }
        )
        .select("display_name, about")
        .single();

      if (error) throw error;
      setDisplayName(data.display_name || "");
      setAbout(data.about || "");
      toast.success("Profile saved!");
    } catch (err: any) {
      toast.error(err.message || "Save failed");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-muted-foreground">
        Loading...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card sticky top-0 z-10">
        <div className="container mx-auto px-4 py-3 flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/home")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-bold font-heading text-foreground">Profile Settings</h1>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-md">
        {/* Avatar */}
        <div className="flex flex-col items-center mb-8">
          <div className="relative">
            <Avatar className="h-24 w-24 border-4 border-primary/20">
              {avatarUrl ? (
                <AvatarImage src={avatarUrl} alt="Profile" />
              ) : null}
              <AvatarFallback className="text-2xl bg-primary/10 text-primary">
                <User className="h-10 w-10" />
              </AvatarFallback>
            </Avatar>
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
              className="absolute bottom-0 right-0 bg-primary text-primary-foreground rounded-full p-2 shadow-md hover:bg-primary/90 transition-colors"
            >
              <Camera className="h-4 w-4" />
            </button>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleAvatarUpload}
          />
          {uploading && (
            <p className="text-sm text-muted-foreground mt-2">Uploading...</p>
          )}
          {displayName && (
            <h2 className="mt-3 text-xl font-bold font-heading text-foreground">{displayName}</h2>
          )}
        </div>

        {/* Performance stats */}
        <div className="grid grid-cols-3 gap-2 mb-6">
          <div className="rounded-xl p-3 gradient-ocean text-white text-center">
            <Trophy className="h-4 w-4 mx-auto mb-1 opacity-90" />
            <p className="text-lg font-bold leading-tight">{stats.attempts}</p>
            <p className="text-[10px] uppercase tracking-wide opacity-90">📋 Tests</p>
          </div>
          <div className="rounded-xl p-3 gradient-tropical text-white text-center">
            <BarChart3 className="h-4 w-4 mx-auto mb-1 opacity-90" />
            <p className="text-lg font-bold leading-tight">{stats.avgPct}%</p>
            <p className="text-[10px] uppercase tracking-wide opacity-90">📈 Avg</p>
          </div>
          <div className="rounded-xl p-3 gradient-sunset text-white text-center">
            <Target className="h-4 w-4 mx-auto mb-1 opacity-90" />
            <p className="text-lg font-bold leading-tight">{stats.bestPct}%</p>
            <p className="text-[10px] uppercase tracking-wide opacity-90">🎯 Best</p>
          </div>
        </div>

        {/* Form */}
        <div className="space-y-5">
          <div>
            <label className="text-sm font-medium text-foreground mb-1.5 block">
              Display Name
            </label>
            <Input
              placeholder="Your name"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              maxLength={50}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground mb-1.5 block">
              About
            </label>
            <Textarea
              placeholder="Tell us about yourself..."
              value={about}
              onChange={(e) => setAbout(e.target.value)}
              maxLength={300}
              rows={4}
            />
            <p className="text-xs text-muted-foreground mt-1 text-right">
              {about.length}/300
            </p>
          </div>

          <div>
            <label className="text-sm font-medium text-foreground mb-1.5 block">
              Email
            </label>
            <Input value={user?.email || ""} disabled className="bg-muted" />
          </div>

          <Button onClick={handleSave} disabled={saving} className="w-full gap-2">
            <Save className="h-4 w-4" /> {saving ? "Saving..." : "Save Profile"}
          </Button>
        </div>
      </main>
    </div>
  );
};

export default Profile;
