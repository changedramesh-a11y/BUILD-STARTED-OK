import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { ArrowLeft, BookOpen, Trophy, Bookmark, Moon, Sun, Clock, Percent, ChevronRight } from "lucide-react";

interface Attempt {
  id: string;
  quiz_id: string;
  score: number;
  percentage: number;
  total_questions: number;
  created_at: string;
  quiz_title?: string;
  quiz_type?: string;
}

interface SavedBlog {
  id: string;
  blog_post_id: string;
  created_at: string;
  title?: string;
  category?: string;
}

const Settings = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<string | null>(null);
  const [attemptedQuizzes, setAttemptedQuizzes] = useState<Attempt[]>([]);
  const [attemptedMocks, setAttemptedMocks] = useState<Attempt[]>([]);
  const [savedBlogs, setSavedBlogs] = useState<SavedBlog[]>([]);
  const [loading, setLoading] = useState(false);
  const [isDark, setIsDark] = useState(() => document.documentElement.classList.contains("dark"));

  const toggleTheme = () => {
    const next = !isDark;
    setIsDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("theme", next ? "dark" : "light");
  };

  useEffect(() => {
    const saved = localStorage.getItem("theme");
    if (saved === "dark") {
      document.documentElement.classList.add("dark");
      setIsDark(true);
    }
  }, []);

  const fetchAttempts = async (type: "quiz" | "mock") => {
    if (!user) return;
    setLoading(true);
    const { data: attempts } = await supabase
      .from("attempts")
      .select("id, quiz_id, score, percentage, total_questions, created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (!attempts) { setLoading(false); return; }

    const quizIds = [...new Set(attempts.map(a => a.quiz_id))];
    const { data: quizzes } = await supabase
      .from("quizzes")
      .select("id, title, type")
      .in("id", quizIds);

    const quizMap = new Map((quizzes || []).map(q => [q.id, q]));
    const enriched = attempts
      .map(a => ({
        ...a,
        quiz_title: quizMap.get(a.quiz_id)?.title || "Unknown",
        quiz_type: quizMap.get(a.quiz_id)?.type || "quiz",
      }))
      .filter(a => a.quiz_type === type);

    if (type === "quiz") setAttemptedQuizzes(enriched);
    else setAttemptedMocks(enriched);
    setLoading(false);
  };

  const fetchSavedBlogs = async () => {
    if (!user) return;
    setLoading(true);
    const { data: saved } = await supabase
      .from("saved_blogs")
      .select("id, blog_post_id, created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (!saved || saved.length === 0) { setSavedBlogs([]); setLoading(false); return; }

    const blogIds = saved.map(s => s.blog_post_id);
    const { data: blogs } = await supabase
      .from("blog_posts")
      .select("id, title, category")
      .in("id", blogIds);

    const blogMap = new Map((blogs || []).map(b => [b.id, b]));
    setSavedBlogs(saved.map(s => ({
      ...s,
      title: blogMap.get(s.blog_post_id)?.title || "Unknown",
      category: blogMap.get(s.blog_post_id)?.category || "",
    })));
    setLoading(false);
  };

  const handleTabClick = (tab: string) => {
    if (activeTab === tab) { setActiveTab(null); return; }
    setActiveTab(tab);
    if (tab === "quizzes") fetchAttempts("quiz");
    else if (tab === "mocks") fetchAttempts("mock");
    else if (tab === "saved") fetchSavedBlogs();
  };

  const menuItems = [
    { key: "quizzes", label: "Attempted Quizzes", icon: BookOpen, color: "text-primary" },
    { key: "mocks", label: "Attempted Mocks", icon: Trophy, color: "text-accent" },
    { key: "saved", label: "Saved Blogs", icon: Bookmark, color: "text-primary" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card sticky top-0 z-10">
        <div className="container mx-auto px-4 py-3 flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/home")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-bold font-heading text-foreground">Settings</h1>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 max-w-lg space-y-3">
        {/* Dark Theme Toggle */}
        <div className="bg-card rounded-xl p-4 border border-border card-shadow flex items-center justify-between">
          <div className="flex items-center gap-3">
            {isDark ? <Moon className="h-5 w-5 text-accent" /> : <Sun className="h-5 w-5 text-accent" />}
            <span className="font-semibold text-foreground">Dark Theme</span>
          </div>
          <Switch checked={isDark} onCheckedChange={toggleTheme} />
        </div>

        {/* Menu Items */}
        {menuItems.map((item) => (
          <div key={item.key}>
            <button
              onClick={() => handleTabClick(item.key)}
              className="w-full bg-card rounded-xl p-4 border border-border card-shadow flex items-center justify-between hover:card-shadow-hover transition-shadow"
            >
              <div className="flex items-center gap-3">
                <item.icon className={`h-5 w-5 ${item.color}`} />
                <span className="font-semibold text-foreground">{item.label}</span>
              </div>
              <ChevronRight className={`h-5 w-5 text-muted-foreground transition-transform ${activeTab === item.key ? "rotate-90" : ""}`} />
            </button>

            {/* Expanded Content */}
            {activeTab === item.key && (
              <div className="mt-2 space-y-2 pl-2">
                {loading ? (
                  <p className="text-sm text-muted-foreground py-4 text-center">Loading...</p>
                ) : item.key === "quizzes" ? (
                  attemptedQuizzes.length === 0 ? (
                    <p className="text-sm text-muted-foreground py-4 text-center">No attempted quizzes yet</p>
                  ) : (
                    attemptedQuizzes.map((a) => (
                      <div key={a.id} className="bg-secondary/50 rounded-lg p-3 border border-border cursor-pointer hover:bg-secondary transition-colors" onClick={() => navigate(`/attempt/${a.id}`)}>
                        <p className="font-medium text-sm text-foreground">{a.quiz_title}</p>
                        <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1"><Percent className="h-3 w-3" />{a.percentage}%</span>
                          <span>{a.score}/{a.total_questions}</span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {new Date(a.created_at).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}
                          </span>
                          <ChevronRight className="h-3 w-3 ml-auto" />
                        </div>
                      </div>
                    ))
                  )
                ) : item.key === "mocks" ? (
                  attemptedMocks.length === 0 ? (
                    <p className="text-sm text-muted-foreground py-4 text-center">No attempted mocks yet</p>
                  ) : (
                    attemptedMocks.map((a) => (
                      <div key={a.id} className="bg-secondary/50 rounded-lg p-3 border border-border cursor-pointer hover:bg-secondary transition-colors" onClick={() => navigate(`/attempt/${a.id}`)}>
                        <p className="font-medium text-sm text-foreground">{a.quiz_title}</p>
                        <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1"><Percent className="h-3 w-3" />{a.percentage}%</span>
                          <span>{a.score}/{a.total_questions}</span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {new Date(a.created_at).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}
                          </span>
                          <ChevronRight className="h-3 w-3 ml-auto" />
                        </div>
                      </div>
                    ))
                  )
                ) : (
                  savedBlogs.length === 0 ? (
                    <p className="text-sm text-muted-foreground py-4 text-center">No saved blogs yet</p>
                  ) : (
                    savedBlogs.map((s) => (
                      <div
                        key={s.id}
                        className="bg-secondary/50 rounded-lg p-3 border border-border cursor-pointer hover:bg-secondary transition-colors"
                        onClick={() => navigate(`/blog/${s.blog_post_id}`)}
                      >
                        <p className="font-medium text-sm text-foreground">{s.title}</p>
                        <span className="text-xs text-primary font-semibold">{s.category}</span>
                      </div>
                    ))
                  )
                )}
              </div>
            )}
          </div>
        ))}
      </main>
    </div>
  );
};

export default Settings;
