import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { ArrowLeft, BookText, Calendar, Trash2 } from "lucide-react";
import { toast } from "sonner";
import SaveButton from "@/components/SaveButton";
import { useExamMode } from "@/hooks/use-exam-mode";

const CATEGORIES = ["ALL", "GK", "MATH", "REASONING", "SCIENCE"] as const;

interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  category: string;
  cover_image_url: string | null;
  created_at: string;
}

const Blog = () => {
  const { user, role } = useAuth();
  const client = useQueryClient();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const canManage = role === "admin" || role === "moderator";
  const activeCategory = searchParams.get("category") || "ALL";
  const [examMode] = useExamMode();
  const key = ["blog-list", user?.id, examMode, activeCategory];
  const listing = useQuery({ queryKey: key, queryFn: async ({ signal }) => {
      let query = supabase
        .from("blog_posts")
        .select("id, title, excerpt, category, cover_image_url, created_at")
        .eq("is_published", true)
        .eq("exam_mode", examMode)
        .order("created_at", { ascending: false });

      if (activeCategory !== "ALL") {
        query = query.eq("category", activeCategory);
      }

      const { data, error } = await query.abortSignal(signal);
      if (error) throw error;
      return (data as BlogPost[]) || [];
  } });
  const posts = listing.data || [];
  const loading = listing.isLoading;

  const setCategory = (cat: string) => {
    if (cat === "ALL") {
      setSearchParams({});
    } else {
      setSearchParams({ category: cat });
    }
  };

  const deletePost = async (e: React.MouseEvent, postId: string) => {
    e.stopPropagation();
    if (!confirm("Delete this blog post?")) return;
    const { error } = await supabase.from("blog_posts").delete().eq("id", postId);
    if (error) { toast.error(error.message); return; }
    client.setQueryData(key, posts.filter(p => p.id !== postId));
    void client.invalidateQueries({ queryKey: ["home-feed"] });
    void client.invalidateQueries({ queryKey: ["saved-collection"] });
    toast.success("Post deleted");
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card sticky top-0 z-10">
        <div className="container mx-auto px-4 py-3 flex items-center gap-3">
          <Button variant="ghost" size="icon" aria-label="Back to Home" onClick={() => navigate("/home")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-2">
            <BookText className="h-5 w-5 text-primary" />
            <h1 className="text-lg font-bold font-heading text-foreground">Blog</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 max-w-2xl">
        {/* Category Filter */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-1">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`px-4 py-1.5 rounded-full text-sm font-semibold whitespace-nowrap transition-colors ${
                activeCategory === cat
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-muted-foreground hover:text-foreground"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Posts */}
        {listing.isError ? <div className="text-center py-12"><p className="text-muted-foreground">Could not load notes.</p><Button variant="outline" onClick={() => void listing.refetch()}>Retry</Button></div> : loading ? (
          <div className="text-center py-12 text-muted-foreground">Loading...</div>
        ) : posts.length === 0 ? (
          <div className="text-center py-12">
            <BookText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No posts in this category yet</p>
          </div>
        ) : (
          <div className="space-y-4">
            {posts.map((post) => (
              <div
                key={post.id}
                className="bg-card rounded-xl p-5 card-shadow border border-border hover:card-shadow-hover transition-shadow cursor-pointer"
                onClick={() => navigate(`/blog/${post.id}`)}
              >
                {post.cover_image_url && (
                  <img
                    src={post.cover_image_url}
                    alt={post.title}
                    className="w-full h-40 object-cover rounded-lg mb-3"
                    loading="lazy"
                    decoding="async"
                  />
                )}
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-primary/10 text-primary">
                  {post.category}
                </span>
                <h2 className="font-bold font-heading text-foreground mt-2">{post.title}</h2>
                {post.excerpt && (
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{post.excerpt}</p>
                )}
                <div className="flex items-center justify-between mt-3">
                  <SaveButton target="note" id={post.id} />
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Calendar className="h-3 w-3" />
                    {new Date(post.created_at).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                  </div>
                  {canManage && (
                    <Button size="sm" variant="ghost" className="gap-1 text-xs text-destructive h-7 px-2" onClick={(e) => deletePost(e, post.id)}>
                      <Trash2 className="h-3 w-3" /> Delete
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default Blog;
