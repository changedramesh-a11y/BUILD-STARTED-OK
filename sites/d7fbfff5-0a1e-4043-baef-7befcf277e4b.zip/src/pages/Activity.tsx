import Dashboard from "@/pages/Dashboard";

export default function Activity() {
  return <Dashboard activityOnly />;
}