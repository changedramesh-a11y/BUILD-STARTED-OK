import { useEffect, useMemo, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { ArrowLeft, ArrowRight, Clock, AlertTriangle, Bookmark, Languages, LayoutGrid } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { paletteStatus, type PaletteStatus } from "@/lib/mock-sections";
import CommentSection from "@/components/CommentSection";
import QuestionBubbles from "@/components/QuestionBubbles";
import SaveButton from "@/components/SaveButton";
import MockDeleteButton from "@/components/MockDeleteButton";
import { mockSchedule, timingAt, canVisitQuestion } from "@/lib/mock-timing";

interface Question {
  id: string;
  question_text: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_option: string;
}

interface QuizMeta {
  id: string;
  title: string;
  duration_minutes: number;
  total_questions: number;
  type: string;
  marks_per_question?: number;
  negative_marks?: number;
  sections?: { name: string; duration_minutes: number }[];
}

const STATUS_STYLE: Record<PaletteStatus, string> = {
  answered: "bg-[hsl(var(--tb-green))] text-white border-transparent",
  not_answered: "bg-[hsl(var(--tb-red))] text-white border-transparent",
  not_visited: "bg-card text-foreground border-border",
  marked: "bg-purple-600 text-white border-transparent rounded-full",
  answered_marked: "bg-purple-600 text-white border-transparent rounded-full ring-2 ring-[hsl(var(--tb-green))]",
};
const STATUS_LABEL: Record<PaletteStatus, string> = {
  answered: "Answered", not_answered: "Not Answered", not_visited: "Not Visited",
  marked: "Marked for Review", answered_marked: "Answered & Marked for Review",
};

const QuizPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [quiz, setQuiz] = useState<QuizMeta | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [timeLeft, setTimeLeft] = useState(0);
  const [perQTime, setPerQTime] = useState<Record<number, number>>({});
  const [started, setStarted] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [bookmarks, setBookmarks] = useState<Set<string>>(new Set());
  const [visited, setVisited] = useState<Set<number>>(new Set([0]));
  const [marked, setMarked] = useState<Set<string>>(new Set());
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [now, setNow] = useState(Date.now());
  const submitting = useRef(false);
  const retryAfter = useRef(0);
  const draftKey = user && id ? `mock-attempt:${user.id}:${id}` : null;
  const sectionRanges = useMemo(() => mockSchedule(quiz?.type || "", questions.length, quiz?.sections || []), [quiz?.type, quiz?.sections, questions.length]);
  const sectioned = sectionRanges.length > 0;
  const timing = timingAt(sectionRanges, startedAt ?? now, now);
  const currentSection = sectioned ? timing.section : undefined;
  const remaining = sectioned ? timing.remaining : timeLeft;
  const timerTotal = currentSection ? currentSection.endsAt - currentSection.startsAt : (quiz?.duration_minutes || 1) * 60;
  const editable = () => {
    if (submitting.current || !startedAt) return false;
    const live = timingAt(sectionRanges, startedAt, Date.now());
    return sectioned ? !live.finished && canVisitQuestion(currentIndex, live.section) : Date.now() < startedAt + (quiz?.duration_minutes || 0) * 60000;
  };
  const jumpTo = (index: number) => {
    if (sectioned && (!startedAt || !canVisitQuestion(index, timingAt(sectionRanges, startedAt, Date.now()).section))) return;
    if (!submitting.current) setCurrentIndex(index);
  };

  useEffect(() => { setVisited((v) => (v.has(currentIndex) ? v : new Set(v).add(currentIndex))); }, [currentIndex]);

  useEffect(() => {
    const controller = new AbortController();
    const fetchQuiz = async () => {
      const { data: quizData } = await supabase.from("quizzes").select("id,title,duration_minutes,total_questions,type,marks_per_question,negative_marks,sections,max_attempts").eq("id", id).abortSignal(controller.signal).single();
      if (controller.signal.aborted) return;
      if (quizData && user) {
        const limit = Number((quizData as any).max_attempts) || 0;
        if (limit > 0) {
          const { data: past } = await supabase.from("attempts").select("id").eq("quiz_id", id).eq("user_id", user.id).order("created_at", { ascending: true }).limit(limit).abortSignal(controller.signal);
          if (controller.signal.aborted) return;
          if (past && past.length >= limit) {
            if (draftKey) localStorage.removeItem(draftKey);
            navigate("/result", { replace: true, state: { attemptId: past[0].id, quizId: id } });
            return;
          }
        }
      }
      if (quizData) {
        setQuiz(quizData as unknown as QuizMeta);
        setTimeLeft((quizData as unknown as QuizMeta).duration_minutes * 60);
      }
      const { data: qData } = await supabase
        .from("public_questions" as any)
        .select("id,question_text,option_a,option_b,option_c,option_d")
        .eq("quiz_id", id)
        .order("created_at").abortSignal(controller.signal) as { data: Question[] | null };
      if (controller.signal.aborted) return;
      setQuestions(qData || []);
      if (quizData && draftKey) {
        try {
          const draft = JSON.parse(localStorage.getItem(draftKey) || "null");
          if (draft && Number.isFinite(draft.startedAt) && draft.answers && typeof draft.answers === "object") {
            setStartedAt(draft.startedAt);
            setNow(Date.now());
            setAnswers(draft.answers);
            setCurrentIndex(Math.min(Math.max(0, draft.currentIndex || 0), Math.max(0, (qData?.length || 1) - 1)));
            setVisited(new Set(draft.visited || [0]));
            setMarked(new Set(draft.marked || []));
            setStarted(true);
          }
        } catch { localStorage.removeItem(draftKey); }
      }
    };
    fetchQuiz();
    return () => controller.abort();
  }, [id, user?.id]);

  // Absolute deadlines keep backgrounding and refresh from extending a section.
  useEffect(() => {
    if (!started || submitted || startedAt === null) return;
    const tick = () => {
      const value = Date.now();
      setNow(value);
      setTimeLeft(Math.max(0, Math.ceil(((startedAt + (quiz?.duration_minutes || 0) * 60000) - value) / 1000)));
    };
    tick();
    const timer = window.setInterval(tick, 1000);
    const resume = () => { if (!document.hidden) tick(); };
    document.addEventListener("visibilitychange", resume);
    return () => { window.clearInterval(timer); document.removeEventListener("visibilitychange", resume); };
  }, [started, submitted, startedAt, quiz?.duration_minutes]);

  useEffect(() => {
    if (!started || startedAt === null || !draftKey || submitting.current) return;
    try {
      localStorage.setItem(draftKey, JSON.stringify({ startedAt, answers, currentIndex, visited: [...visited], marked: [...marked] }));
    } catch { toast.error("Answers cannot be saved on this device. Keep this test open."); }
  }, [started, startedAt, draftKey, answers, currentIndex, visited, marked]);

  // per-question timer
  useEffect(() => {
    if (!started || submitted) return;
    const t = setInterval(() => {
      setPerQTime((p) => ({ ...p, [currentIndex]: (p[currentIndex] || 0) + 1 }));
    }, 1000);
    return () => clearInterval(t);
  }, [started, submitted, currentIndex]);

  const fmt = (s: number) => {
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`;
  };
  const fmtShort = (s: number) => `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;

  const handleAnswer = (option: string) => {
    if (!editable() || !questions[currentIndex]) return;
    setAnswers(previous => ({ ...previous, [questions[currentIndex].id]: option }));
  };

  const toggleBookmark = () => {
    const qid = questions[currentIndex].id;
    setBookmarks((b) => {
      const n = new Set(b);
      n.has(qid) ? n.delete(qid) : n.add(qid);
      return n;
    });
  };

  const handleSubmit = async () => {
    if (submitting.current) return;
    submitting.current = true;
    setSubmitted(true);
    try {
      const { data, error } = await supabase.functions.invoke("submit-quiz", {
        body: { quiz_id: id, answers },
      });
      if (error) { toast.error("Failed to submit quiz"); setSubmitted(false); submitting.current = false; retryAfter.current = Date.now() + 10000; return; }
      const { attemptId, score, totalQuestions, maxMarks, percentage } = data;
      if (attemptId) {
        void queryClient.invalidateQueries({ queryKey: ["test-list"] });
        void queryClient.invalidateQueries({ queryKey: ["test-attempts"] });
        if (draftKey) localStorage.removeItem(draftKey);
        navigate("/result", { replace: true, state: { attemptId, quizId: id, score, totalQuestions, maxMarks, percentage } });
        return;
      }
      toast.error("Quiz submitted, but review could not open");
      setSubmitted(false); submitting.current = false; retryAfter.current = Date.now() + 10000;
    } catch {
      toast.error("Failed to submit quiz");
      setSubmitted(false); submitting.current = false; retryAfter.current = Date.now() + 10000;
    }
  };

  useEffect(() => {
    if (!started || startedAt === null || submitted) return;
    if ((sectioned && timing.finished) || (!sectioned && timeLeft <= 0 && now >= startedAt + (quiz?.duration_minutes || 0) * 60000)) {
      if (Date.now() >= retryAfter.current) void handleSubmit();
      return;
    }
    if (currentSection && !canVisitQuestion(currentIndex, currentSection)) {
      setCurrentIndex(currentSection.start);
      setPaletteOpen(false);
      toast.info(`${currentSection.name} has started`);
    }
  }, [started, startedAt, submitted, now, sectioned, timing.index]);

  if (!quiz) return <div className="min-h-screen flex items-center justify-center text-muted-foreground">Loading...</div>;

  if (!started) {
    return (
      <div className="min-h-screen bg-background px-4 py-8">
        <div className="max-w-md w-full mx-auto">
          <div className="bg-card rounded-xl card-shadow p-8 border border-border text-center">
            <h1 className="text-2xl font-bold font-heading text-foreground mb-2">{quiz.title}</h1>
            <div className="mb-3">{id && <SaveButton target="quiz" id={id} />}</div>
            <p className="text-muted-foreground mb-6">
              {quiz.total_questions} questions · {sectioned ? sectionRanges[sectionRanges.length - 1].endsAt / 60 : quiz.duration_minutes} minutes
            </p>
            {sectioned && <div className="space-y-2 mb-5 text-left">{sectionRanges.map((section, index) => <p key={index} className="text-sm text-foreground flex justify-between gap-3"><span>{section.name}</span><span>{(section.endsAt - section.startsAt) / 60} min</span></p>)}</div>}
            <Button disabled={!questions.length} onClick={() => { const start = Date.now(); setStartedAt(start); setNow(start); setStarted(true); }} className="w-full gap-2" size="lg">
              Start {["mock", "weekly_mock"].includes(quiz.type) ? "Mock Test" : "Quiz"} <ArrowRight className="h-4 w-4" />
            </Button>
            <Button variant="ghost" className="w-full mt-3" onClick={() => navigate("/home")}>
              <ArrowLeft className="h-4 w-4 mr-2" /> Back
            </Button>
          </div>
          <div className="mt-3 flex justify-center"><MockDeleteButton id={quiz.id} title={quiz.title} type={quiz.type} onDeleted={() => navigate("/home", { replace: true })} /></div>
          {id && <CommentSection quizId={id} />}
        </div>
      </div>
    );
  }

  const currentQ = questions[currentIndex];
  const statusAt = (i: number) => paletteStatus(!!answers[questions[i]?.id], visited.has(i), marked.has(questions[i]?.id));
  const counts = questions.reduce((c, _q, i) => { c[statusAt(i)]++; return c; },
    { answered: 0, not_answered: 0, not_visited: 0, marked: 0, answered_marked: 0 } as Record<PaletteStatus, number>);
  const paletteRange = currentSection ?? { name: "All Questions", start: 0, end: questions.length };
  const toggleMark = () => {
    if (!currentQ || !editable()) return;
    setMarked((m) => { const n = new Set(m); n.has(currentQ.id) ? n.delete(currentQ.id) : n.add(currentQ.id); return n; });
  };
  const clearResponse = () => {
    if (!currentQ || !editable()) return;
    setAnswers((a) => { const n = { ...a }; delete n[currentQ.id]; return n; });
  };
  const isBookmarked = currentQ ? bookmarks.has(currentQ.id) : false;

  return (
    <div className="min-h-screen bg-background pb-36">
      {/* Dark header bar */}
      <header className="sticky top-0 z-20 bg-[hsl(var(--header-bg))] text-[hsl(var(--header-fg))]">
        <div className="px-4 py-3 flex items-center gap-3">
          <div className="relative h-9 w-9 shrink-0">
            <svg className="absolute inset-0 -rotate-90" viewBox="0 0 36 36">
              <circle cx="18" cy="18" r="16" fill="none" stroke="hsl(var(--header-fg) / 0.2)" strokeWidth="2" />
              <circle
                cx="18" cy="18" r="16" fill="none"
                stroke="hsl(var(--tb-blue))"
                strokeWidth="2"
                strokeDasharray={`${(remaining / timerTotal) * 100} 100`}
                pathLength={100}
              />
            </svg>
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-mono text-base font-semibold leading-none">{fmt(remaining)}</p>
            <p className="text-[11px] text-white/70 truncate mt-0.5">{currentSection ? `${currentSection.name} · ${quiz.title}` : quiz.title}</p>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setPaletteOpen(true)} className="flex items-center gap-1 text-xs font-semibold" aria-label="View question palette">
            <LayoutGrid className="h-5 w-5" /> View
          </Button>
          <button className="text-white/80" aria-label="Language">
            <Languages className="h-5 w-5" />
          </button>
          <button onClick={handleSubmit} disabled={submitted} className="text-sm font-bold tracking-wide">
            SUBMIT
          </button>
        </div>
      </header>

      {sectionRanges.length > 0 && (
        <div className="px-4 pt-3 flex items-center gap-2 overflow-x-auto">
          <span className="text-xs font-semibold text-muted-foreground shrink-0">Sections:</span>
          {sectionRanges.map((r) => {
            const active = currentSection?.name === r.name && currentSection.start === r.start;
            return (
              <Button variant="outline" size="sm" disabled={r.start !== currentSection?.start || submitted} key={r.name + r.start} onClick={() => jumpTo(r.start)}
                className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold border ${active ? "bg-[hsl(var(--tb-blue))] text-white border-transparent" : "border-border text-foreground bg-card"}`}>
                {r.name}
              </Button>
            );
          })}
        </div>
      )}

      <Sheet open={paletteOpen} onOpenChange={setPaletteOpen}>
        <SheetContent side="right" className="w-[88vw] max-w-sm overflow-y-auto">
          <SheetHeader><SheetTitle>Question Palette</SheetTitle></SheetHeader>
          <div className="grid grid-cols-2 gap-2 mt-4 text-xs">
            {(Object.keys(STATUS_LABEL) as PaletteStatus[]).map((k) => (
              <div key={k} className="flex items-center gap-2">
                <span className={`h-7 w-7 shrink-0 flex items-center justify-center rounded-md border font-semibold ${STATUS_STYLE[k]}`}>{counts[k]}</span>
                <span className="text-muted-foreground leading-tight">{STATUS_LABEL[k]}</span>
              </div>
            ))}
          </div>
          {sectionRanges.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-4">
              {sectionRanges.map((r) => (
                <Button variant="outline" size="sm" disabled={r.start !== currentSection?.start || submitted} key={r.name + r.start} onClick={() => jumpTo(r.start)}
                  className={`px-3 py-1 rounded-full text-xs font-semibold border ${paletteRange.start === r.start ? "bg-[hsl(var(--tb-blue))] text-white border-transparent" : "border-border bg-card text-foreground"}`}>
                  {r.name}
                </Button>
              ))}
            </div>
          )}
          <p className="mt-4 mb-3 text-sm font-semibold text-foreground bg-muted px-3 py-2 rounded">Section: {paletteRange.name}</p>
          <div className="grid grid-cols-5 gap-2">
            {Array.from({ length: paletteRange.end - paletteRange.start }, (_, k) => paletteRange.start + k).map((i) => (
              <Button variant="outline" key={i} disabled={submitted || (sectioned && !canVisitQuestion(i, currentSection))} onClick={() => { jumpTo(i); setPaletteOpen(false); }}
                className={`h-10 rounded-md border text-sm font-semibold ${STATUS_STYLE[statusAt(i)]} ${i === currentIndex ? "outline outline-2 outline-[hsl(var(--tb-blue))] outline-offset-2" : ""}`}>
                {i + 1}
              </Button>
            ))}
          </div>
          <Button onClick={() => { setPaletteOpen(false); handleSubmit(); }} disabled={submitted} variant="outline" className="w-full mt-6">Submit Test</Button>
        </SheetContent>
      </Sheet>

      {/* Question bubbles */}
      <div className="mx-4"><QuestionBubbles
        total={sectioned && currentSection ? currentSection.end - currentSection.start : questions.length}
        current={currentIndex - (currentSection?.start || 0)}
        offset={currentSection?.start || 0}
        statusFor={(i) => answers[questions[i + (currentSection?.start || 0)]?.id] ? "answered" : "unseen"}
        onJump={(i) => jumpTo(i + (currentSection?.start || 0))}
      /></div>

      {/* Meta strip */}
      {currentQ && (
        <div className="px-4 py-3 flex items-center gap-3 text-xs">
          <span className="flex items-center gap-1 text-muted-foreground">
            <Clock className="h-3.5 w-3.5" /> {fmtShort(perQTime[currentIndex] || 0)}
          </span>
          <span className="px-2 py-0.5 rounded bg-[hsl(var(--tb-green-soft))] text-[hsl(var(--tb-green))] font-semibold">+ {Number(quiz?.marks_per_question ?? 1)}</span>
          <span className="px-2 py-0.5 rounded bg-[hsl(var(--tb-red-soft))] text-[hsl(var(--tb-red))] font-semibold">- {Number(quiz?.negative_marks ?? 0.25)}</span>
          <button className="ml-auto text-muted-foreground" aria-label="Report">
            <AlertTriangle className="h-5 w-5" />
          </button>
          <button onClick={toggleBookmark} aria-label="Bookmark">
            <Bookmark className={`h-5 w-5 ${isBookmarked ? "fill-[hsl(var(--tb-blue))] text-[hsl(var(--tb-blue))]" : "text-muted-foreground"}`} />
          </button>
        </div>
      )}

      <main className="px-4 pb-8 max-w-lg mx-auto">
        {currentQ && (
          <>
            <h2 className="text-base font-medium text-foreground mb-5 leading-relaxed">
              {currentQ.question_text}
            </h2>

            <div className="space-y-3">
              {["A", "B", "C", "D"].map((opt, idx) => {
                const optionText = currentQ[`option_${opt.toLowerCase()}` as keyof Question];
                const isSelected = answers[currentQ.id] === opt;
                return (
                  <button
                    key={opt}
                    onClick={() => handleAnswer(opt)}
                    className={`w-full text-left px-4 py-4 rounded-xl border-2 transition-all flex items-start gap-3 ${
                      isSelected
                        ? "border-[hsl(var(--tb-blue))] bg-[hsl(var(--tb-blue-soft))]"
                        : "border-border bg-card hover:border-[hsl(var(--tb-blue))]/40"
                    }`}
                  >
                    <span className={`italic font-medium shrink-0 ${isSelected ? "text-[hsl(var(--tb-blue))]" : "text-muted-foreground"}`}>{idx + 1}.</span>
                    <span className={isSelected ? "font-medium text-[hsl(var(--tb-blue))]" : "text-foreground"}>{optionText}</span>
                  </button>
                );
              })}
            </div>
          </>
        )}
      </main>

      {/* Sticky bottom nav */}
      <div className="fixed bottom-0 inset-x-0 bg-card border-t border-border px-4 py-3 z-20">
      <div className="flex gap-2 mb-2">
        <Button variant="outline" onClick={clearResponse} className="flex-1 h-10 text-xs">Clear Response</Button>
        <Button variant="outline" onClick={toggleMark}
          className={`flex-1 h-10 text-xs ${currentQ && marked.has(currentQ.id) ? "border-purple-600 text-purple-600" : ""}`}>
          {currentQ && marked.has(currentQ.id) ? "Unmark Review" : "Mark for Review"}
        </Button>
      </div>
      <div className="flex gap-3">
        <Button
          variant="outline"
          onClick={() => jumpTo(currentIndex - 1)}
          disabled={submitted || currentIndex === (currentSection?.start || 0)}
          className="flex-1 h-12"
        >
          Previous
        </Button>
        {currentIndex < (currentSection?.end ?? questions.length) - 1 ? (
          <Button
            disabled={submitted} onClick={() => jumpTo(currentIndex + 1)}
            className="flex-1 h-12 bg-[hsl(var(--tb-blue))] hover:bg-[hsl(var(--tb-blue))]/90 text-white"
          >
            Next
          </Button>
        ) : sectioned && !timing.finished ? (
          <Button disabled className="flex-1 h-12">{timing.index < sectionRanges.length - 1 ? "Next section when time ends" : "Submit when time ends"}</Button>
        ) : (
          <Button
            onClick={handleSubmit}
            disabled={submitted}
            className="flex-1 h-12 bg-[hsl(var(--tb-blue))] hover:bg-[hsl(var(--tb-blue))]/90 text-white"
          >
            Submit
          </Button>
        )}
      </div>
      </div>
    </div>
  );
};

export default QuizPage;
