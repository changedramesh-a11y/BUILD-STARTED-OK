import { useState, useRef, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Navigate, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { MAX_MOCK_SECTIONS, prepareMockSections, supportsMockSections, type MockSection } from "@/lib/mock-sections";
import { toast } from "sonner";
import { ArrowLeft, Plus, Trash2, Save, Upload, FileText, Loader2 } from "lucide-react";

const getCategoryOptions = (mode: "central" | "jharkhand") => {
  if (mode === "jharkhand") return ["JSSC POLICE", "JSSC CGL", "JPSC"];
  return ["SSC", "RAILWAY", "OTHER"];
};

interface QuestionInput {
  question_text: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_option: string;
}

const emptyQuestion: QuestionInput = {
  question_text: "",
  option_a: "",
  option_b: "",
  option_c: "",
  option_d: "",
  correct_option: "A",
};

const Admin = () => {
  const { role } = useAuth();
  const client = useQueryClient();
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [type, setType] = useState<"quiz" | "mock" | "weekly_mock" | "daily_quiz">("quiz");
  const [category, setCategory] = useState("SSC");
  const [examMode, setExamMode] = useState<"central" | "jharkhand">("central");
  const [durationMinutes, setDurationMinutes] = useState(15);
  const [marksPerQuestion, setMarksPerQuestion] = useState(1);
  const [negativeMarks, setNegativeMarks] = useState(0.25);
  const [maxAttempts, setMaxAttempts] = useState<number>(0); // 0 = infinite
  const [sectionsEnabled, setSectionsEnabled] = useState(false);
  const [sections, setSections] = useState<MockSection[]>([{ name: "", duration_minutes: 15 }]);
  const [questions, setQuestions] = useState<QuestionInput[]>([{ ...emptyQuestion }]);
  const [saving, setSaving] = useState(false);
  const [extracting, setExtracting] = useState(false);
  const [pdfFileName, setPdfFileName] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const categoryOptions = getCategoryOptions(examMode);

  useEffect(() => {
    setCategory(categoryOptions[0]);
  }, [examMode]);

  if (new URLSearchParams(window.location.search).get("type") === "pyq") return <Navigate to="/pyq-upload" replace />;

  if (role !== "admin" && role !== "moderator") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">You don't have permission to access this page.</p>
          <Button onClick={() => navigate("/home")}>Go to Dashboard</Button>
        </div>
      </div>
    );
  }

  const addQuestion = () => setQuestions([...questions, { ...emptyQuestion }]);

  const removeQuestion = (i: number) => {
    if (questions.length === 1) return;
    setQuestions(questions.filter((_, idx) => idx !== i));
  };

  const updateQuestion = (i: number, field: keyof QuestionInput, value: string) => {
    const updated = [...questions];
    updated[i] = { ...updated[i], [field]: value };
    setQuestions(updated);
  };

  const handlePdfUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type !== "application/pdf") {
      toast.error("Please upload a PDF file");
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      toast.error("File too large. Maximum 10MB allowed.");
      return;
    }

    setPdfFileName(file.name);
    setExtracting(true);

    try {
      toast.info("Uploading PDF and extracting questions with AI...");

      const formData = new FormData();
      formData.append("file", file);

      const { data, error } = await supabase.functions.invoke("extract-questions", {
        body: formData,
      });

      if (error) {
        const msg = (error as any)?.context?.error || error.message || "Failed to extract questions";
        throw new Error(msg);
      }

      if (data?.questions && data.questions.length > 0) {
        setQuestions(data.questions.map((q: any) => ({
          question_text: q.question_text || "",
          option_a: q.option_a || "",
          option_b: q.option_b || "",
          option_c: q.option_c || "",
          option_d: q.option_d || "",
          correct_option: q.correct_option || "A",
        })));
        toast.success(`${data.questions.length} questions extracted successfully! Review and publish.`);
      } else {
        toast.error("No questions could be extracted from this PDF.");
      }
    } catch (err: any) {
      console.error("PDF extraction error:", err);
      toast.error(err.message || "Failed to extract questions from PDF");
    } finally {
      setExtracting(false);
    }
  };


  const handleSave = async () => {
    if (!title.trim()) { toast.error("Please enter a title"); return; }
    if (questions.some((q) => !q.question_text.trim())) { toast.error("All questions need text"); return; }

    setSaving(true);
    try {
      const savedSections = prepareMockSections(type, sectionsEnabled, sections);
      const { data: quizData, error: quizError } = await supabase
        .from("quizzes")
        .insert({
          title,
          description,
          type,
          category,
          exam_mode: examMode,
          duration_minutes: durationMinutes,
          marks_per_question: marksPerQuestion,
          negative_marks: negativeMarks,
          max_attempts: maxAttempts,
          sections: savedSections.map((section) => ({ ...section })),
          total_questions: questions.length,
          is_published: true,
        })
        .select()
        .single();

      if (quizError) throw quizError;

      const questionsToInsert = questions.map((q) => ({
        quiz_id: quizData.id,
        question_text: q.question_text,
        option_a: q.option_a,
        option_b: q.option_b,
        option_c: q.option_c,
        option_d: q.option_d,
        correct_option: q.correct_option,
      }));

      const { error: qError } = await supabase.from("questions").insert(questionsToInsert);
      if (qError) throw qError;
      void client.invalidateQueries({ queryKey: ["test-list"] });
      void client.invalidateQueries({ queryKey: ["home-feed"] });

      toast.success("Quiz created successfully!");
      navigate("/home");
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  };

  const renderQuestionCards = () => (
    <>
      {questions.map((q, i) => (
        <div key={i} className="bg-card rounded-xl p-4 md:p-5 card-shadow border border-border space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold text-muted-foreground">Question {i + 1}</span>
            <Button variant="ghost" size="icon" onClick={() => removeQuestion(i)} disabled={questions.length === 1}>
              <Trash2 className="h-4 w-4 text-destructive" />
            </Button>
          </div>
          <Textarea
            placeholder="Question text"
            value={q.question_text}
            onChange={(e) => updateQuestion(i, "question_text", e.target.value)}
          />
          {(["A", "B", "C", "D"] as const).map((opt) => (
            <div key={opt} className="flex items-center gap-2">
              <span
                className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                  q.correct_option === opt ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"
                }`}
              >
                {opt}
              </span>
              <Input
                placeholder={`Option ${opt}`}
                value={q[`option_${opt.toLowerCase()}` as keyof QuestionInput]}
                onChange={(e) => updateQuestion(i, `option_${opt.toLowerCase()}` as keyof QuestionInput, e.target.value)}
                className="flex-1"
              />
              <button
                onClick={() => updateQuestion(i, "correct_option", opt)}
                className={`text-xs px-2 py-1 rounded-md border transition-colors shrink-0 ${
                  q.correct_option === opt
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border text-muted-foreground hover:border-primary"
                }`}
              >
                ✓
              </button>
            </div>
          ))}
        </div>
      ))}
    </>
  );

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card sticky top-0 z-10">
        <div className="container mx-auto px-4 py-3 flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/home")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-bold font-heading text-foreground">Create Quiz / Mock</h1>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 max-w-lg space-y-6">
        {/* Quiz Details */}
        <div className="bg-card rounded-xl p-5 card-shadow border border-border space-y-4">
          <Input placeholder="Quiz title" value={title} onChange={(e) => setTitle(e.target.value)} />
          <Textarea placeholder="Description (optional)" value={description} onChange={(e) => setDescription(e.target.value)} />
          <div className="flex gap-3 flex-wrap">
            <select
              value={type}
              onChange={(e) => setType(e.target.value as typeof type)}
              className="flex h-10 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring"
            >
              <option value="quiz">Quiz</option>
              <option value="mock">Mock Test</option>
              <option value="weekly_mock">Weekly Mock</option>
              <option value="daily_quiz">Daily Quiz</option>
            </select>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="flex h-10 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring"
            >
              {categoryOptions.map((opt) => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
            <select
              value={examMode}
              onChange={(e) => setExamMode(e.target.value as "central" | "jharkhand")}
              className="flex h-10 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring"
            >
              <option value="central">Central Exam</option>
              <option value="jharkhand">Jharkhand Exam</option>
            </select>
            <Input
              type="number"
              placeholder="Duration (min)"
              value={durationMinutes}
              onChange={(e) => setDurationMinutes(Number(e.target.value))}
              min={1}
              className="w-32"
            />
            <Input
              type="number"
              step="0.25"
              placeholder="Marks / question"
              value={marksPerQuestion}
              onChange={(e) => setMarksPerQuestion(Number(e.target.value))}
              min={0}
              className="w-36"
            />
            <Input
              type="number"
              step="0.25"
              placeholder="Negative marks"
              value={negativeMarks}
              onChange={(e) => setNegativeMarks(Number(e.target.value))}
              min={0}
              className="w-36"
            />
            <select
              value={maxAttempts}
              onChange={(e) => setMaxAttempts(Number(e.target.value))}
              className="flex h-10 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring"
            >
              <option value={1}>Single attempt</option>
              <option value={2}>Double attempt</option>
              <option value={0}>Infinite attempts</option>
            </select>
          </div>
          {supportsMockSections(type) && (
            <div className="border-t border-border pt-4 space-y-4">
              <div className="flex items-center justify-between gap-3">
                <Label htmlFor="mock-sections" className="font-semibold">Sections for this mock</Label>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-sm text-muted-foreground">{sectionsEnabled ? "On" : "Off"}</span>
                  <Switch id="mock-sections" checked={sectionsEnabled} onCheckedChange={setSectionsEnabled} />
                </div>
              </div>
              {sectionsEnabled && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="section-count">Number of sections</Label>
                    <select
                      id="section-count"
                      value={sections.length}
                      onChange={(e) => {
                        const count = Number(e.target.value);
                        setSections((current) => Array.from({ length: count }, (_, index) => current[index] ?? { name: "", duration_minutes: 15 }));
                      }}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                    >
                      {Array.from({ length: MAX_MOCK_SECTIONS }, (_, index) => (
                        <option key={index + 1} value={index + 1}>{index + 1}</option>
                      ))}
                    </select>
                  </div>
                  {sections.map((section, index) => (
                    <div key={index} className="grid grid-cols-[minmax(0,1fr)_6rem] gap-3">
                      <div className="space-y-2 min-w-0">
                        <Label htmlFor={`section-name-${index}`}>Section {index + 1} name</Label>
                        <Input
                          id={`section-name-${index}`}
                          placeholder="Section name"
                          value={section.name}
                          onChange={(e) => setSections((current) => current.map((item, i) => i === index ? { ...item, name: e.target.value } : item))}
                        />
                      </div>
                      <div className="space-y-2 min-w-0">
                        <Label htmlFor={`section-time-${index}`}>Time (min)</Label>
                        <Input
                          id={`section-time-${index}`}
                          aria-label={`Section ${index + 1} time in minutes`}
                          type="number"
                          min={1}
                          step={1}
                          value={section.duration_minutes}
                          onChange={(e) => setSections((current) => current.map((item, i) => i === index ? { ...item, duration_minutes: Number(e.target.value) } : item))}
                        />
                      </div>
                    </div>
                  ))}
                </>
              )}
            </div>
          )}
          <p className="text-xs text-muted-foreground">
            Each correct answer = +{marksPerQuestion} mark{marksPerQuestion === 1 ? "" : "s"}. Each wrong answer = −{negativeMarks}. Unanswered = 0.
            {" "}Attempts allowed: {maxAttempts === 0 ? "Unlimited" : maxAttempts}.
          </p>
        </div>

        {/* Mode Tabs */}
        <Tabs defaultValue="manual" className="w-full">
          <TabsList className="w-full">
            <TabsTrigger value="manual" className="flex-1 gap-1.5">
              <FileText className="h-4 w-4" /> Manual
            </TabsTrigger>
            <TabsTrigger value="ai" className="flex-1 gap-1.5">
              <Upload className="h-4 w-4" /> AI from PDF
            </TabsTrigger>
          </TabsList>

          <TabsContent value="manual" className="space-y-4 mt-4">
            {renderQuestionCards()}
            <Button variant="outline" onClick={addQuestion} className="w-full gap-2">
              <Plus className="h-4 w-4" /> Add Question
            </Button>
          </TabsContent>

          <TabsContent value="ai" className="space-y-4 mt-4">
            <div className="bg-card rounded-xl p-5 card-shadow border border-border space-y-4">
              <div className="text-center space-y-2">
                <Upload className="h-10 w-10 mx-auto text-muted-foreground" />
                <p className="text-sm text-muted-foreground">
                  Upload a PDF with MCQ questions. AI will extract questions, options, and mark the correct answers.
                </p>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf"
                onChange={handlePdfUpload}
                className="hidden"
              />

              <Button
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
                disabled={extracting}
                className="w-full gap-2"
              >
                {extracting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" /> Extracting questions...
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4" /> {pdfFileName || "Choose PDF File"}
                  </>
                )}
              </Button>

              {pdfFileName && !extracting && (
                <p className="text-xs text-muted-foreground text-center">
                  📄 {pdfFileName} — {questions.length} question{questions.length !== 1 ? "s" : ""} loaded
                </p>
              )}
            </div>

            {/* Show extracted questions for review */}
            {questions.length > 0 && questions[0].question_text && (
              <>
                <p className="text-sm font-semibold text-foreground">Review extracted questions:</p>
                {renderQuestionCards()}
                <Button variant="outline" onClick={addQuestion} className="w-full gap-2">
                  <Plus className="h-4 w-4" /> Add Question
                </Button>
              </>
            )}
          </TabsContent>
        </Tabs>

        <Button onClick={handleSave} disabled={saving} className="w-full gap-2" size="lg">
          <Save className="h-4 w-4" /> {saving ? "Saving..." : "Publish Quiz"}
        </Button>
      </main>
    </div>
  );
};

export default Admin;
