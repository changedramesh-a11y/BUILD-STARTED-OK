import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";

type Member = { user_id: string; display_name: string | null; email: string | null; approved: boolean };

export default function MemberApprovals() {
  const navigate = useNavigate();
  const { role, user } = useAuth();
  const [members, setMembers] = useState<Member[] | null>(null);
  const load = async () => {
    const { data, error } = await supabase.rpc("admin_list_members");
    if (error) toast.error("Could not load students");
    setMembers((data || []) as Member[]);
  };
  useEffect(() => { if (role === "admin") void load(); }, [role]);
  if (role !== "admin") return <div className="p-6 text-muted-foreground">Admins only.</div>;
  const toggle = async (m: Member) => {
    const { error } = m.approved
      ? await supabase.from("member_approvals").delete().eq("user_id", m.user_id)
      : await supabase.from("member_approvals").insert({ user_id: m.user_id, approved_by: user!.id });
    if (error) { toast.error("Could not update"); return; }
    toast.success(m.approved ? "Approval removed" : "Student approved");
    void load();
  };
  return <div className="min-h-screen bg-background pb-24">
    <header className="sticky top-0 z-10 flex items-center gap-3 border-b border-border bg-card px-4 py-3">
      <Button variant="ghost" size="icon" aria-label="Back to Home" onClick={() => navigate("/home")}><ArrowLeft /></Button>
      <h1 className="font-heading text-lg font-semibold">Approve Students</h1>
    </header>
    <main className="mx-auto grid max-w-2xl gap-3 p-4">
      {!members ? <p className="text-muted-foreground">Loading…</p> : members.map(m => <article key={m.user_id} className="flex min-w-0 items-center justify-between gap-3 rounded-lg border border-border bg-card p-3">
        <div className="min-w-0"><p className="font-medium [overflow-wrap:anywhere]">{m.display_name || "Student"}</p><p className="text-xs text-muted-foreground [overflow-wrap:anywhere]">{m.email}</p><p className={`text-xs ${m.approved ? "text-primary" : "text-destructive"}`}>{m.approved ? "Approved" : "Waiting for approval"}</p></div>
        <Button size="sm" variant={m.approved ? "outline" : "default"} onClick={() => toggle(m)}>{m.approved ? "Remove" : "Approve"}</Button>
      </article>)}
    </main>
  </div>;
}
