import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Trophy, Medal } from "lucide-react";

interface RankEntry {
  user_id: string;
  display_name: string;
  score: number;
  percentage: number;
  total_questions: number;
  max_marks: number;
  created_at: string;
}

const Leaderboard = () => {
  const { quizId } = useParams<{ quizId: string }>();
  const navigate = useNavigate();
  const [rankings, setRankings] = useState<RankEntry[]>([]);
  const [quizTitle, setQuizTitle] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRankings = async () => {
      if (!quizId) return;

      const { data: quizData } = await supabase
        .from("quizzes")
        .select("title")
        .eq("id", quizId)
        .single();
      if (quizData) setQuizTitle(quizData.title);

      const { data: attempts } = await supabase
        .from("attempts")
        .select("user_id, score, percentage, total_questions, max_marks, created_at")
        .eq("quiz_id", quizId)
        .order("percentage", { ascending: false })
        .order("created_at", { ascending: true });

      if (attempts && attempts.length > 0) {
        const userIds = [...new Set(attempts.map((a) => a.user_id))];
        const { data: profiles } = await supabase
          .from("public_profiles" as any)
          .select("user_id, display_name")
          .in("user_id", userIds) as { data: { user_id: string; display_name: string | null }[] | null };

        const profileMap = new Map(
          (profiles || []).map((p) => [p.user_id, p.display_name || "Anonymous"])
        );

        setRankings(
          attempts.map((a) => ({
            ...a,
            display_name: profileMap.get(a.user_id) || "Anonymous",
          }))
        );
      }
      setLoading(false);
    };
    fetchRankings();
  }, [quizId]);

  const getMedalColor = (rank: number) => {
    if (rank === 0) return "text-yellow-500";
    if (rank === 1) return "text-gray-400";
    if (rank === 2) return "text-amber-600";
    return "text-muted-foreground";
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card sticky top-0 z-10">
        <div className="container mx-auto px-4 py-3 flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-lg font-bold font-heading text-foreground">Leaderboard</h1>
            {quizTitle && <p className="text-xs text-muted-foreground">{quizTitle}</p>}
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 max-w-lg">
        {loading ? (
          <div className="text-center py-12 text-muted-foreground">Loading...</div>
        ) : rankings.length === 0 ? (
          <div className="text-center py-12">
            <Trophy className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No attempts yet for this quiz.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {rankings.map((entry, index) => (
              <div
                key={`${entry.user_id}-${index}`}
                className={`bg-card rounded-xl p-4 card-shadow border ${
                  index < 3 ? "border-primary/30" : "border-border"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-secondary shrink-0">
                    {index < 3 ? (
                      <Medal className={`h-5 w-5 ${getMedalColor(index)}`} />
                    ) : (
                      <span className="text-sm font-bold text-muted-foreground">#{index + 1}</span>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold font-heading text-foreground truncate">
                      {entry.display_name}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {entry.score}/{entry.max_marks || entry.total_questions} marks
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className={`text-xl font-bold font-heading ${
                      entry.percentage >= 70 ? "text-primary" : entry.percentage >= 50 ? "text-accent" : "text-destructive"
                    }`}>
                      {entry.percentage}%
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default Leaderboard;
