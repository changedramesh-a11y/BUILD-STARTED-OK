import { Link, useParams } from "react-router-dom";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, ArrowRight, Bookmark, FileText } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useSavedContent } from "@/hooks/use-saved-content";
import { matchesSavedTest, type SavedKind, type SaveTarget } from "@/lib/saved-content";
import SaveButton from "@/components/SaveButton";
import { Button } from "@/components/ui/button";
import BottomTabBar from "@/components/BottomTabBar";
import PdfReader, { type PdfPaper } from "@/components/PdfReader";

const COLLECTIONS: Record<SavedKind, { title: string; target: SaveTarget; browse: string }> = {
  daily: { title: "Saved Daily Quizzes", target: "quiz", browse: "/daily-quiz" },
  weekly: { title: "Saved Weekly Mocks", target: "quiz", browse: "/weekly-mock" },
  notes: { title: "Saved Study Notes", target: "note", browse: "/blog" },
  papers: { title: "Saved Previous Year Papers", target: "paper", browse: "/prev-papers" },
};

export default function SavedContent() {
  const { kind = "daily" } = useParams();
  if (!(kind in COLLECTIONS)) return <div className="p-6"><Button asChild><Link to="/home">Back to Home</Link></Button></div>;
  return <Collection kind={kind as SavedKind} />;
}

function Collection({ kind }: { kind: SavedKind }) {
  const { user } = useAuth();
  const [reading, setReading] = useState<PdfPaper | null>(null);
  const collection = COLLECTIONS[kind];
  const saves = useSavedContent(collection.target);
  const query = useQuery({
    queryKey: ["saved-collection", user?.id, kind, saves.ids],
    enabled: !saves.loading && !saves.error,
    queryFn: async () => {
      if (!saves.ids.length) return [];
      if (kind === "papers") {
        const { data, error } = await supabase.from("previous_year_papers").select("*").in("id", saves.ids);
        if (error) throw error;
        return (data || []).map(p => ({ id: p.id, title: `${p.exam_name} · ${p.year}`, detail: p.file_name, path: "", pdf: p.file_path }));
      }
      if (kind === "notes") {
        const { data, error } = await supabase.from("blog_posts").select("id,title,excerpt,category").eq("is_published", true).in("id", saves.ids);
        if (error) throw error;
        return (data || []).map(p => ({ id: p.id, title: p.title, detail: p.excerpt || p.category, path: `/blog/${p.id}`, pdf: "" }));
      }
      const { data, error } = await supabase.from("quizzes").select("id,title,type,duration_minutes,total_questions,exam_mode").eq("is_published", true).in("id", saves.ids);
      if (error) throw error;
      return (data || []).filter(q => matchesSavedTest(q.type, kind)).map(q => ({ id: q.id, title: q.title, detail: `${q.total_questions} questions · ${q.duration_minutes} min · ${q.exam_mode === "jharkhand" ? "Jharkhand" : "Central"}`, path: `/quiz/${q.id}`, pdf: "" }));
    },
  });
  return <div className="min-h-screen bg-background pb-28">
    <header className="border-b border-border bg-card"><div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-4"><Button asChild variant="ghost" size="icon" aria-label="Back to Home"><Link to="/home"><ArrowLeft /></Link></Button><h1 className="font-heading text-lg font-bold">{collection.title}</h1></div></header>
    <main className="mx-auto max-w-6xl px-4 py-6">
      <nav className="mb-6 flex gap-2 overflow-x-auto pb-2" aria-label="Saved categories">{Object.entries(COLLECTIONS).map(([key, value]) => <Button key={key} asChild size="sm" variant={kind === key ? "default" : "outline"} className="shrink-0"><Link to={`/saved/${key}`} aria-current={kind === key ? "page" : undefined}>{value.title.replace("Saved ", "")}</Link></Button>)}</nav>
      {saves.error || query.isError ? <div role="alert" className="py-12 text-center"><p className="mb-4 text-muted-foreground">Could not load saved items.</p><Button variant="outline" onClick={() => { void saves.refetch(); void query.refetch(); }}>Retry</Button></div>
        : saves.loading || query.isLoading ? <p role="status" className="py-12 text-center text-muted-foreground">Loading saved items…</p>
        : !query.data?.length ? <div className="py-12 text-center"><Bookmark className="mx-auto mb-3 h-9 w-9 text-muted-foreground" /><h2 className="font-heading font-semibold">Nothing saved yet</h2><Button asChild variant="outline" className="mt-4"><Link to={collection.browse}>Browse {collection.title.replace("Saved ", "")}<ArrowRight /></Link></Button></div>
        : <div className="grid min-w-0 grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">{query.data.map(item => <article key={item.id} className="flex min-w-0 flex-col rounded-lg border border-border bg-card p-5"><h2 className="font-heading font-semibold [overflow-wrap:anywhere]">{item.title}</h2><p className="mt-2 line-clamp-2 text-sm text-muted-foreground [overflow-wrap:anywhere]">{item.detail}</p><div className="mt-auto flex flex-wrap items-center justify-between gap-2 pt-4">{item.pdf ? <Button variant="outline" size="sm" onClick={() => setReading({ file_path: item.pdf, file_name: item.detail })}><FileText />Open PDF</Button> : <Button asChild variant="outline" size="sm"><Link to={item.path}>Open<ArrowRight /></Link></Button>}<SaveButton target={collection.target} id={item.id} /></div></article>)}</div>}
    </main><BottomTabBar /><PdfReader paper={reading} onClose={() => setReading(null)} />
  </div>;
}