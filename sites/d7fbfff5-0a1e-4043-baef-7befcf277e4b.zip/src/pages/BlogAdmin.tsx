import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import AiStudyNotes from "@/components/AiStudyNotes";
import StudyNoteContent from "@/components/StudyNoteContent";
import { extractMindMap, requireMindMap, withMindMapImage } from "../../supabase/functions/_shared/study-note-format";
import { mindMapImage, toMindMapPng } from "@/lib/note-mind-map";
import { optimizeImage } from "@/lib/optimize-image";
import { toast } from "sonner";
import { ArrowLeft, Save, Sparkles, PenLine } from "lucide-react";

const BLOG_CATEGORIES = ["GK", "MATH", "REASONING", "SCIENCE"] as const;

const BlogAdmin = () => {
  const { user, role } = useAuth();
  const client = useQueryClient();
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [excerpt, setExcerpt] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState<string>("GK");
  const [examMode, setExamMode] = useState<"central" | "jharkhand">("central");
  const [coverUrl, setCoverUrl] = useState("");
  const [saving, setSaving] = useState(false);
  const [mode, setMode] = useState("manual");
  const [aiDraft, setAiDraft] = useState(false);
  const [mindMapUpload, setMindMapUpload] = useState("");
  const [thumbnailUpload, setThumbnailUpload] = useState("");
  const [uploadingImage, setUploadingImage] = useState(false);

  const readImageFile = async (file: File, thumbnail = false) => {
    if (!["image/png", "image/jpeg", "image/webp"].includes(file.type) || file.size > 3_000_000) {
      throw new Error("Choose a PNG, JPEG or WebP image under 3 MB.");
    }
    const optimized = await optimizeImage(file, thumbnail ? 1200 : undefined);
    const data = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("Could not read image."));
      reader.onerror = () => reject(new Error("Could not read image."));
      reader.readAsDataURL(optimized);
    });
    const image = new Image(); image.src = data; await image.decode();
    return data;
  };

  const handleImageUpload = async (file?: File) => {
    if (!file) return;
    setUploadingImage(true);
    try {
      const data = await readImageFile(file);
      withMindMapImage("", data);
      setMindMapUpload(data);
    } catch (error) { toast.error(error instanceof Error ? error.message : "Could not upload image."); }
    finally { setUploadingImage(false); }
  };

  const handleThumbnailUpload = async (file?: File) => {
    if (!file) return;
    setUploadingImage(true);
    try {
      setThumbnailUpload(await readImageFile(file, true));
    } catch (error) { toast.error(error instanceof Error ? error.message : "Could not upload image."); }
    finally { setUploadingImage(false); }
  };

  if (role !== "admin" && role !== "moderator") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">You don't have permission to access this page.</p>
          <Button onClick={() => navigate("/home")}>Go to Dashboard</Button>
        </div>
      </div>
    );
  }

  const handleSave = async () => {
    if (!user) { toast.error("Please sign in again"); return; }
    if (!title.trim()) { toast.error("Please enter a title"); return; }
    if (!content.trim()) { toast.error("Please enter content"); return; }
    const draftContent = mindMapUpload ? withMindMapImage(content, mindMapUpload) : content;
    if (aiDraft || draftContent.includes("```mindmap")) {
      try { requireMindMap(draftContent); } catch (error) { toast.error(error instanceof Error ? error.message : "A final mind map is required."); return; }
    }

    setSaving(true);
    try {
      let publishedContent = draftContent;
      const { map, image } = extractMindMap(draftContent);
      if (map && !image) {
        const styles = getComputedStyle(document.documentElement);
        const color = (name: string) => `hsl(${styles.getPropertyValue(name).trim()})`;
        const png = await toMindMapPng(mindMapImage(map, { background: color("--background"), text: color("--foreground"), accent: color("--primary"), border: color("--border"), surface: color("--muted") }));
        publishedContent = withMindMapImage(draftContent, png);
      }
      const { error } = await supabase.from("blog_posts").insert({
        title,
        excerpt,
        content: publishedContent,
        category,
        exam_mode: examMode,
        cover_image_url: thumbnailUpload || coverUrl || null,
        is_published: true,
        author_id: user.id,
      } as any);

      if (error) throw error;
      void client.invalidateQueries({ queryKey: ["blog-list"] });
      void client.invalidateQueries({ queryKey: ["home-feed"] });
      toast.success("Study notes published!");
      navigate("/blog");
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card sticky top-0 z-10">
        <div className="container mx-auto px-4 py-3 flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/home")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-bold font-heading text-foreground">Add Study Notes</h1>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 max-w-lg space-y-4">
        <div className="space-y-4">
          <select
            aria-label="Exam preference"
            value={examMode}
            onChange={(e) => setExamMode(e.target.value as "central" | "jharkhand")}
            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring"
          >
            <option value="central">Central Exam</option>
            <option value="jharkhand">Jharkhand Exam</option>
          </select>

          <select
            aria-label="Subject"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring"
          >
            {BLOG_CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
          <Tabs value={mode} onValueChange={setMode}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="manual" className="gap-2"><PenLine className="h-4 w-4" />Write Notes</TabsTrigger>
              <TabsTrigger value="ai" className="gap-2"><Sparkles className="h-4 w-4" />AI Notes</TabsTrigger>
            </TabsList>
            <TabsContent value="ai">
              <AiStudyNotes examMode={examMode} category={category} isAdmin={role === "admin"} onDraft={(draft) => {
                if ((title.trim() || content.trim()) && !window.confirm("Replace your existing notes with this AI draft?")) return;
                setTitle(draft.title); setExcerpt(draft.excerpt); setContent(draft.content); setMindMapUpload(""); setAiDraft(true); setMode("manual");
                toast.success("Draft ready. Check accuracy before publishing.");
              }} />
            </TabsContent>
            <TabsContent value="manual" className="space-y-4 pt-2">
          <Input aria-label="Notes title" placeholder="Notes title" value={title} onChange={(e) => setTitle(e.target.value)} />
          <Input
            placeholder="Cover image URL (optional)"
            value={coverUrl}
            onChange={(e) => setCoverUrl(e.target.value)}
          />

          <Textarea
            placeholder="Short excerpt / summary"
            value={excerpt}
            onChange={(e) => setExcerpt(e.target.value)}
            rows={2}
          />

          <Textarea
            aria-label="Notes content"
            placeholder="Write your study notes here..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={12}
            className="min-h-[200px]"
          />
          <div className="rounded-lg border border-border bg-muted/30 p-3 space-y-2">
            <label className="block text-sm font-semibold text-foreground" htmlFor="mind-map-upload">
              Final mind-map image (optional)
            </label>
            <p className="text-xs text-muted-foreground">
              Upload a PNG, JPEG or WebP under 3 MB. If you skip this, the app draws the mind map itself from your outline.
            </p>
            <Input
              id="mind-map-upload"
              type="file"
              accept="image/png,image/jpeg,image/webp"
              disabled={uploadingImage}
              onChange={(e) => { handleImageUpload(e.target.files?.[0]); e.target.value = ""; }}
            />
            {mindMapUpload && (
              <div className="flex items-center gap-3">
                <img src={mindMapUpload} alt="Uploaded mind map" className="h-16 w-auto rounded border border-border object-contain" />
                <Button type="button" variant="outline" size="sm" onClick={() => setMindMapUpload("")}>Remove</Button>
              </div>
            )}
          </div>
          <div className="rounded-lg border border-border bg-muted/30 p-3 space-y-2">
            <label className="block text-sm font-semibold text-foreground" htmlFor="thumbnail-upload">
              Notes thumbnail (optional)
            </label>
            <p className="text-xs text-muted-foreground">
              Upload a PNG, JPEG or WebP under 3 MB. This picture shows on the notes card in the list. If you skip this, the cover image URL above is used.
            </p>
            <Input
              id="thumbnail-upload"
              type="file"
              accept="image/png,image/jpeg,image/webp"
              disabled={uploadingImage}
              onChange={(e) => { handleThumbnailUpload(e.target.files?.[0]); e.target.value = ""; }}
            />
            {thumbnailUpload && (
              <div className="flex items-center gap-3">
                <img src={thumbnailUpload} alt="Uploaded thumbnail" className="h-16 w-auto rounded border border-border object-contain" />
                <Button type="button" variant="outline" size="sm" onClick={() => setThumbnailUpload("")}>Remove</Button>
              </div>
            )}
          </div>
          {content.trim() && <section className="border-t border-border pt-4"><h2 className="mb-4 text-lg font-bold">Article preview</h2><StudyNoteContent content={mindMapUpload ? withMindMapImage(content, mindMapUpload) : content} /></section>}
            </TabsContent>
          </Tabs>
        </div>

        {mode === "manual" && (
        <Button onClick={handleSave} disabled={saving || uploadingImage} className="w-full gap-2" size="lg">
          <Save className="h-4 w-4" /> {saving ? "Publishing..." : "Publish Notes"}
        </Button>
        )}
      </main>
    </div>
  );
};

export default BlogAdmin;
