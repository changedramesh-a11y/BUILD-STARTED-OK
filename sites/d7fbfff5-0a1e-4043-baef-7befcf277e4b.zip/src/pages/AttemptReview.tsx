import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { ArrowLeft, ArrowRight, AlertTriangle, Bookmark, Check, Languages } from "lucide-react";
import QuestionBubbles from "@/components/QuestionBubbles";
import { Switch } from "@/components/ui/switch";

interface Question {
  id: string;
  question_text: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_option: string;
  explanation?: string | null;
}

const AttemptReview = () => {
  const { attemptId } = useParams<{ attemptId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [questions, setQuestions] = useState<Question[]>([]);
  const [userAnswers, setUserAnswers] = useState<Record<string, string>>({});
  const [quizTitle, setQuizTitle] = useState("");
  const [loading, setLoading] = useState(true);
  const [idx, setIdx] = useState(0);
  const [reattempt, setReattempt] = useState(false);
  const [practiceAnswers, setPracticeAnswers] = useState<Record<string, string>>({});
  const [marksPerQuestion, setMarksPerQuestion] = useState(1);
  const [negativeMarks, setNegativeMarks] = useState(0.25);

  useEffect(() => {
    const load = async () => {
      if (!user || !attemptId) return;
      const { data: attempt } = await supabase
        .from("attempts")
        .select("quiz_id, answers")
        .eq("id", attemptId)
        .eq("user_id", user.id)
        .single();
      if (!attempt) { setLoading(false); return; }
      setUserAnswers((attempt.answers as Record<string, string>) || {});
      const { data: quiz } = await supabase.from("quizzes").select("title, marks_per_question, negative_marks").eq("id", attempt.quiz_id).single();
      if (quiz) {
        setQuizTitle(quiz.title);
        setMarksPerQuestion(Number(quiz.marks_per_question ?? 1));
        setNegativeMarks(Number(quiz.negative_marks ?? 0.25));
      }
      const { data: qData } = await supabase.rpc("get_attempt_questions", { p_attempt_id: attemptId });
      setQuestions((qData as Question[]) || []);
      setLoading(false);
    };
    load();
  }, [attemptId, user]);

  if (loading) return <div className="min-h-screen flex items-center justify-center text-muted-foreground">Loading...</div>;
  if (questions.length === 0) return <div className="min-h-screen flex items-center justify-center text-muted-foreground">No data</div>;

  const q = questions[idx];
  const userAns = userAnswers[q.id];
  const isCorrect = userAns === q.correct_option;
  const labels = ["A", "B", "C", "D"] as const;
  const keys = ["option_a", "option_b", "option_c", "option_d"] as const;

  const handlePractice = (opt: string) => {
    if (!reattempt) return;
    setPracticeAnswers((p) => ({ ...p, [q.id]: opt }));
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <header className="sticky top-0 z-20 bg-[hsl(var(--header-bg))] text-[hsl(var(--header-fg))] px-4 py-3 flex items-center gap-3">
        <button onClick={() => navigate("/home")} aria-label="Back">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="flex-1 text-sm font-semibold truncate">{quizTitle}</h1>
        <Languages className="h-5 w-5 text-white/80" />
        <span className="text-sm font-semibold">Analysis</span>
      </header>

      {/* Bubbles colored by correctness */}
      <QuestionBubbles
        total={questions.length}
        current={idx}
        statusFor={(i) => {
          const qq = questions[i];
          const u = userAnswers[qq.id];
          if (!u) return "unseen";
          return u === qq.correct_option ? "correct" : "wrong";
        }}
        onJump={(i) => setIdx(i)}
      />

      {/* Meta strip */}
      <div className="px-4 py-3 flex items-center gap-3 text-xs">
        <span className={`w-7 h-7 rounded-full flex items-center justify-center text-white font-semibold text-xs ${
          !userAns ? "bg-muted-foreground" : isCorrect ? "bg-[hsl(var(--tb-green))]" : "bg-[hsl(var(--tb-red))]"
        }`}>{idx + 1}</span>
        <span className="px-2 py-0.5 rounded bg-[hsl(var(--tb-green-soft))] text-[hsl(var(--tb-green))] font-semibold">+{marksPerQuestion}</span>
        <span className="px-2 py-0.5 rounded bg-[hsl(var(--tb-red-soft))] text-[hsl(var(--tb-red))] font-semibold">-{negativeMarks}</span>
        <AlertTriangle className="h-5 w-5 text-muted-foreground ml-auto" />
        <Bookmark className="h-5 w-5 text-muted-foreground" />
      </div>

      <main className="px-4 max-w-lg mx-auto">
        <h2 className="text-base font-medium text-foreground mb-5 leading-relaxed">{q.question_text}</h2>

        <div className="space-y-3">
          {labels.map((opt, i) => {
            const text = q[keys[i]];
            const isCorrectOpt = opt === q.correct_option;
            const isUserPick = opt === userAns;
            const isPractice = practiceAnswers[q.id] === opt;

            let cls = "border-border bg-card";
            let txt = "text-foreground";
            if (reattempt && isPractice) { cls = "border-[hsl(var(--tb-blue))] bg-[hsl(var(--tb-blue-soft))]"; txt = "text-[hsl(var(--tb-blue))] font-semibold"; }
            else if (!reattempt && isCorrectOpt) { cls = "border-[hsl(var(--tb-green))] bg-[hsl(var(--tb-green-soft))]"; txt = "text-[hsl(var(--tb-green))] font-semibold"; }
            else if (!reattempt && isUserPick && !isCorrectOpt) { cls = "border-[hsl(var(--tb-red))] bg-[hsl(var(--tb-red-soft))]"; txt = "text-[hsl(var(--tb-red))] font-semibold"; }

            return (
              <button
                key={opt}
                onClick={() => handlePractice(opt)}
                disabled={!reattempt}
                className={`w-full text-left px-4 py-4 rounded-xl border-2 flex items-start gap-3 ${cls} ${!reattempt ? "cursor-default" : ""}`}
              >
                <span className="italic text-muted-foreground font-medium shrink-0">{i + 1}.</span>
                <span className={`${txt} flex-1`}>{text}</span>
                {!reattempt && isCorrectOpt && <Check className="h-5 w-5 text-[hsl(var(--tb-green))] shrink-0" />}
              </button>
            );
          })}
        </div>

        {!reattempt && (
          <div className="mt-6 flex items-center justify-between text-sm">
            <span className="font-bold text-foreground">Correct Answer Is: {labels.indexOf(q.correct_option as any) + 1}</span>
          </div>
        )}

        {q.explanation && !reattempt && (
          <div className="mt-6 bg-card rounded-xl border border-border p-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2">Solution</h3>
            <p className="text-sm text-foreground whitespace-pre-wrap leading-relaxed">{q.explanation}</p>
          </div>
        )}

        {reattempt && practiceAnswers[q.id] && (
          <div className="mt-4 text-sm text-center font-medium">
            {practiceAnswers[q.id] === q.correct_option ? (
              <span className="text-[hsl(var(--tb-green))]">✓ Correct!</span>
            ) : (
              <span className="text-[hsl(var(--tb-red))]">✗ Try again. Correct: {labels.indexOf(q.correct_option as any) + 1}</span>
            )}
          </div>
        )}
      </main>

      {/* Bottom bar */}
      <div className="fixed bottom-0 inset-x-0 bg-card border-t border-border px-4 py-3 flex items-center gap-3 z-20">
        <div className="flex items-center gap-2 text-sm">
          <Switch checked={reattempt} onCheckedChange={setReattempt} id="reattempt" />
          <label htmlFor="reattempt" className="text-foreground">Reattempt Mode</label>
        </div>
        <div className="ml-auto flex gap-2">
          <button
            onClick={() => setIdx(Math.max(0, idx - 1))}
            disabled={idx === 0}
            className="h-11 w-11 rounded-full bg-[hsl(var(--tb-blue))] text-white flex items-center justify-center disabled:opacity-40"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <button
            onClick={() => setIdx(Math.min(questions.length - 1, idx + 1))}
            disabled={idx === questions.length - 1}
            className="h-11 w-11 rounded-full bg-[hsl(var(--tb-blue))] text-white flex items-center justify-center disabled:opacity-40"
          >
            <ArrowRight className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default AttemptReview;
