import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { isActivityNote, isActivityTest } from "@/lib/activity";
import SaveButton from "@/components/SaveButton";
import TestRankBadge from "@/components/TestRankBadge";

interface Attempt {
  id: string;
  quiz_id: string;
  score: number;
  percentage: number;
  total_questions: number;
  max_marks: number;
}

interface BlogPost {
  id: string;
  title: string;
  excerpt: string | null;
  category: string;
  exam_mode: "central" | "jharkhand";
  cover_image_url: string | null;
  created_at: string;
}
import { Button } from "@/components/ui/button";
import { Shield, BookOpen, Bookmark, Trophy, LogOut, Moon, Plus, Clock, Sun, Users, UserCircle, BookText, Settings, Trash2, FileText, MessageCircle, Menu, Search, Bell, ChevronDown, ClipboardList, Award, FileCode, ArrowLeft, Activity as ActivityIcon } from "lucide-react";
import BottomTabBar from "@/components/BottomTabBar";
import { toast } from "sonner";
import NoticeBoard from "@/components/NoticeBoard";
import NoticeUploader from "@/components/NoticeUploader";
import StoryUploader from "@/components/StoryUploader";
import LikeShareBar from "@/components/LikeShareBar";
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Switch } from "@/components/ui/switch";

interface Quiz {
  id: string;
  title: string;
  description: string;
  type: "quiz" | "mock";
  category: string;
  exam_mode: "central" | "jharkhand";
  duration_minutes: number;
  total_questions: number;
  created_at: string;
}

const EXAM_MODES = [
  { value: "central", label: "Central Exam" },
  { value: "jharkhand", label: "Jharkhand Exam" },
] as const;

const getCategories = (mode: "central" | "jharkhand") => {
  if (mode === "jharkhand") return ["ALL", "JSSC POLICE", "JSSC CGL", "JPSC"] as const;
  return ["ALL", "SSC", "RAILWAY", "OTHER"] as const;
};

const Dashboard = ({ activityOnly = false }: { activityOnly?: boolean }) => {
  const { user, role, signOut } = useAuth();
  const [isDark, setIsDark] = useState(() => document.documentElement.classList.contains("dark"));
  const toggleTheme = () => {
    const next = !isDark;
    setIsDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("theme", next ? "dark" : "light");
  };
  const navigate = useNavigate();
  const location = useLocation();
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState<string>("ALL");
  const [section, setSection] = useState<"quiz" | "mock" | "post">("quiz");
  const [examMode, setExamMode] = useState<"central" | "jharkhand">(() => {
    return (localStorage.getItem("exam_mode") as "central" | "jharkhand") || "central";
  });
  const [attempts, setAttempts] = useState<Record<string, Attempt>>({});
  const [savedNoteIds, setSavedNoteIds] = useState<string[]>([]);
  const [uploaderOpen, setUploaderOpen] = useState(false);
  const [storyRefresh, setStoryRefresh] = useState(0);
  const [noticeOpen, setNoticeOpen] = useState(false);
  const [noticeRefresh, setNoticeRefresh] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);
  const [profile, setProfile] = useState<{ display_name: string | null; avatar_url: string | null }>({ display_name: null, avatar_url: null });

  useEffect(() => {
    if (location.hash === "#stories") {
      setTimeout(() => document.getElementById("stories")?.scrollIntoView({ behavior: "smooth", block: "start" }), 100);
    }
  }, [location.hash]);


  useEffect(() => {
    const fetchData = async () => {
      const [quizRes, attemptRes, postRes, profileRes, savedRes] = await Promise.all([
        supabase.from("quizzes").select("*").eq("is_published", true).order("created_at", { ascending: false }),
        user ? supabase.from("attempts").select("id, quiz_id, score, percentage, total_questions, max_marks, created_at").eq("user_id", user.id).order("created_at", { ascending: false }) : Promise.resolve({ data: [] }),
        supabase.from("blog_posts").select("id, title, excerpt, category, exam_mode, cover_image_url, created_at").eq("is_published", true).order("created_at", { ascending: false }),
        user ? supabase.from("profiles").select("display_name, avatar_url").eq("user_id", user.id).maybeSingle() : Promise.resolve({ data: null }),
        user ? supabase.from("saved_blogs").select("blog_post_id").eq("user_id", user.id) : Promise.resolve({ data: [] }),
      ]);
      setSavedNoteIds((savedRes.data || []).map(saved => saved.blog_post_id));
      setQuizzes((quizRes.data as Quiz[]) || []);
      setPosts((postRes.data as BlogPost[]) || []);
      if (profileRes && (profileRes as any).data) {
        const p = (profileRes as any).data;
        setProfile({ display_name: p.display_name ?? null, avatar_url: p.avatar_url ?? null });
      }
      const attemptMap: Record<string, Attempt> = {};
      // attempts are ordered newest-first; keep only the most recent per quiz
      (attemptRes.data || []).forEach((a: any) => {
        if (!attemptMap[a.quiz_id]) {
          attemptMap[a.quiz_id] = a;
        }
      });
      setAttempts(attemptMap);
      setLoading(false);
    };
    fetchData();
  }, [user]);

  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };

  const filteredQuizzes = quizzes
    .filter(q => !activityOnly || isActivityTest(q.id, attempts))
    .filter(q => (q.exam_mode || "central") === examMode)
    .filter(q => section === "quiz" ? ["quiz", "daily_quiz"].includes(q.type) : section === "mock" ? ["mock", "weekly_mock"].includes(q.type) : false)
    .filter(q => activeCategory === "ALL" ? true : q.category === activeCategory);

  const filteredPosts = posts.filter(p => (p.exam_mode || "central") === examMode).filter(p => !activityOnly || isActivityNote(p.id, savedNoteIds));

  const canManage = role === "admin" || role === "moderator";

  const categories = getCategories(examMode);

  const handleExamModeChange = (mode: "central" | "jharkhand") => {
    setExamMode(mode);
    setActiveCategory("ALL");
    localStorage.setItem("exam_mode", mode);
  };

  // Rotating dual-tone gradients for colorful UI accents
  const CATEGORY_GRADIENTS = [
    "gradient-sunset",
    "gradient-ocean",
    "gradient-forest",
    "gradient-candy",
    "gradient-tropical",
    "gradient-fire",
    "gradient-citrus",
  ];
  const gradientFor = (key: string) => {
    let h = 0;
    for (let i = 0; i < key.length; i++) h = (h * 31 + key.charCodeAt(i)) >>> 0;
    return CATEGORY_GRADIENTS[h % CATEGORY_GRADIENTS.length];
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Testbook-style dark header */}
      <div className="bg-[hsl(var(--header-bg))] text-[hsl(var(--header-fg))]">
        <div className="container mx-auto px-3 py-3 flex items-center gap-3">
          <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="Menu"><Menu className="h-6 w-6" /></Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-72 p-0 flex flex-col">
              <SheetHeader className="px-5 py-4 border-b border-border">
                <SheetTitle className="text-foreground font-heading">Menu</SheetTitle>
              </SheetHeader>
              <nav className="flex flex-col p-3 gap-1 overflow-y-auto">
                {(() => {
                  const go = (path: string) => { setMenuOpen(false); navigate(path); };
                  const items: { label: string; icon: any; onClick: () => void; cls?: string }[] = [
                    { label: "Activity", icon: ActivityIcon, onClick: () => go("/activity") },
                    { label: "Profile", icon: UserCircle, onClick: () => go("/profile") },
                    { label: "Blog", icon: BookText, onClick: () => go("/blog") },
                    { label: "Community", icon: MessageCircle, onClick: () => go("/community") },
                    { label: "Scores", icon: Trophy, onClick: () => go("/scoreboard") },
                    ...(canManage ? [
                      { label: "Manage", icon: Plus, onClick: () => go("/admin"), cls: "text-primary hover:bg-secondary hover:text-primary" },
                      { label: "Add Study Notes", icon: BookOpen, onClick: () => go("/blog-admin") },
                      { label: "Add PYQ", icon: FileText, onClick: () => go("/pyq-upload") },
                      { label: "Add Daily Current Affairs", icon: Plus, onClick: () => { setMenuOpen(false); setUploaderOpen(true); } },
                    ] : []),
                    ...(role === "admin" ? [
                      { label: "Add Notice", icon: Bell, onClick: () => { setMenuOpen(false); setNoticeOpen(true); } },
                    ] : []),
                    { label: "Attempted Quizzes", icon: ClipboardList, onClick: () => go("/activity") },
                    { label: "Attempted Mocks", icon: Trophy, onClick: () => go("/activity") },
                    { label: "Saved Blogs", icon: Bookmark, onClick: () => go("/saved/notes") },
                  ];
                  return (
                    <>
                      {items.map((it) => (
                        <Button variant="ghost" key={it.label} onClick={it.onClick} className={`justify-start gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold text-left transition-colors ${it.cls ?? "hover:bg-secondary text-foreground"}`}>
                          <it.icon className="h-4 w-4" /><span>{it.label}</span>
                        </Button>
                      ))}
                      <div className="flex items-center justify-between rounded-lg px-3 py-2.5">
                        <span className="flex items-center gap-3 text-sm font-semibold text-foreground">{isDark ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}<span>Dark Theme</span></span>
                        <Switch checked={isDark} onCheckedChange={toggleTheme} aria-label="Dark theme" />
                      </div>
                      <Button variant="ghost" onClick={() => { setMenuOpen(false); handleSignOut(); }} className="mt-3 w-full justify-start gap-3 px-3 py-2.5 text-sm font-semibold text-destructive hover:bg-secondary hover:text-destructive">
                        <LogOut className="h-4 w-4" /><span>Logout</span>
                      </Button>
                    </>
                  );
                })()}
              </nav>
            </SheetContent>
          </Sheet>
          <button
            onClick={() => handleExamModeChange(examMode === "central" ? "jharkhand" : "central")}
            className="flex shrink-0 items-center gap-2 font-semibold"
          >
            <span>My Exams</span>
            <span className="text-xs bg-white/15 rounded-full px-2 py-0.5">{examMode === "central" ? "Central" : "JH"}</span>
            <ChevronDown className="h-4 w-4" />
          </button>
          <div className="ml-auto flex shrink-0 items-center gap-2 sm:gap-3">
            {canManage && (
              <Button size="sm" onClick={() => navigate("/admin")}>
                <Settings className="h-4 w-4" />
                Manage
              </Button>
            )}
            <Search className="hidden h-5 w-5 sm:block" />
            <Bell className="hidden h-5 w-5 sm:block" />
            <button onClick={() => navigate("/profile")} aria-label="Profile">
              <Avatar className="h-8 w-8 border-2 border-white/30">
                {profile.avatar_url ? <AvatarImage src={profile.avatar_url} alt="Me" /> : null}
                <AvatarFallback className="text-xs bg-white/10 text-white">
                  {(profile.display_name || user?.email || "U").slice(0, 1).toUpperCase()}
                </AvatarFallback>
              </Avatar>
            </button>
          </div>
        </div>
      </div>


      {/* legacy header removed */}

      {uploaderOpen && (
        <StoryUploader
          examMode={examMode}
          onClose={() => setUploaderOpen(false)}
          onCreated={() => {
            setUploaderOpen(false);
            setStoryRefresh((r) => r + 1);
          }}
        />
      )}
      {noticeOpen && (
        <NoticeUploader onClose={() => setNoticeOpen(false)} onCreated={() => { setNoticeOpen(false); setNoticeRefresh((r) => r + 1); }} />
      )}

      {/* Content */}
      <main className="container mx-auto px-4 pt-5 pb-8">
        {!activityOnly && <NoticeBoard refreshTrigger={noticeRefresh} />}
        {!activityOnly && <Button variant="outline" className="mt-4 gap-2" onClick={() => navigate("/activity")}><ActivityIcon className="h-4 w-4" />Activity</Button>}
        {activityOnly && <>
        <div className="mb-5 flex items-center gap-3">
          <Button variant="outline" size="icon" aria-label="Back to Home" title="Back to Home" onClick={() => navigate("/home")}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="font-heading text-2xl font-bold text-foreground">My Activity</h1>
        </div>

        {/* Section header + tabs */}
        <div className="flex items-center justify-between mb-3 mt-2">
          <h2 className="text-base font-bold font-heading text-foreground flex items-center gap-2">
            <span className="w-1 h-5 bg-[hsl(var(--tb-blue))] rounded" />
            {section === "mock" ? "Attempted Mocks" : section === "post" ? "Saved Notes" : "Attempted Quizzes"}
          </h2>
          <div className="flex gap-1 bg-secondary rounded-full p-1 text-xs font-semibold">
            {(["quiz", "mock", "post"] as const).map((s) => (
              <button
                key={s}
                onClick={() => { setSection(s); setActiveCategory("ALL"); }}
                className={`px-3 py-1 rounded-full transition-colors ${
                  section === s ? "bg-[hsl(var(--tb-blue))] text-white" : "text-muted-foreground"
                }`}
              >
                {s === "quiz" ? "Quiz" : s === "mock" ? "Mock" : "Post"}
              </button>
            ))}
          </div>
        </div>

        {/* Category pills - clean style */}
        {section !== "post" && (
          <div className="flex gap-2 mb-5 overflow-x-auto pb-1 -mx-4 px-4">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap border transition-colors ${
                  activeCategory === cat
                    ? "bg-[hsl(var(--tb-blue))] text-white border-transparent"
                    : "bg-card text-muted-foreground border-border hover:text-foreground"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        )}



        {/* List */}
        {section === "post" ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
            {loading ? (
              <div className="col-span-full text-center py-12 text-muted-foreground">Loading...</div>
            ) : filteredPosts.length === 0 ? (
              <div className="col-span-full text-center py-12">
                <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No saved study notes for this exam preference</p>
              </div>
            ) : (
              filteredPosts.map((post) => (
                <div
                  key={post.id}
                  className="bg-card rounded-xl p-4 md:p-5 card-shadow border border-border cursor-pointer hover:card-shadow-hover"
                  onClick={() => navigate(`/blog/${post.id}`)}
                >
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-full gradient-forest text-white">📃 POST</span>
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${gradientFor(post.category)} text-white`}>{post.category}</span>
                  </div>
                  <h3 className="font-semibold font-heading text-foreground text-sm md:text-base">{post.title}</h3>
                  {post.excerpt && <p className="text-xs md:text-sm text-muted-foreground mt-1 line-clamp-2">{post.excerpt}</p>}
                  <LikeShareBar
                    targetType="post"
                    targetId={post.id}
                    shareUrl={`/blog/${post.id}`}
                    shareTitle={post.title}
                    onCommentClick={(e) => { e.stopPropagation(); navigate(`/blog/${post.id}#comments`); }}
                  />
                </div>
              ))
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
            {loading ? (
              <div className="col-span-full text-center py-12 text-muted-foreground">Loading...</div>
            ) : filteredQuizzes.length === 0 ? (
              <div className="col-span-full text-center py-12">
                <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No attempted {section === "mock" ? "mock tests" : "quizzes"} in this category</p>
              </div>
            ) : (
              filteredQuizzes.map((quiz) => {
                const attempt = attempts[quiz.id];
                return (
                  <div
                    key={quiz.id}
                    className={`bg-card rounded-xl p-4 md:p-5 card-shadow border transition-shadow cursor-pointer ${
                      attempt ? "border-primary/30" : "border-border"
                    } hover:card-shadow-hover`}
                    onClick={() => attempt ? navigate("/result", { state: { attemptId: attempt.id, quizId: quiz.id } }) : navigate(`/quiz/${quiz.id}`)}
                  >
                    <div className="flex flex-wrap items-center gap-2 mb-1.5">
                      <span className={`text-xs font-semibold px-2 py-0.5 rounded-full text-white ${
                        quiz.type === "mock" ? "gradient-candy" : "gradient-sunset"
                      }`}>
                        {["mock", "weekly_mock"].includes(quiz.type) ? "🏆 MOCK" : "📚 QUIZ"}
                      </span>
                      <span className={`text-xs font-semibold px-2 py-0.5 rounded-full text-white ${gradientFor(quiz.category)}`}>
                        {quiz.category}
                      </span>
                      {attempt ? (
                        <TestRankBadge quizId={quiz.id} />
                      ) : (
                        <span className="ml-auto text-xs font-medium px-2 py-0.5 rounded-full gradient-citrus text-amber-foreground">
                          🕜 Not attempted
                        </span>
                      )}
                    </div>
                    <h3 className="font-semibold font-heading text-foreground text-sm md:text-base">{quiz.title}</h3>
                    <p className="text-xs md:text-sm text-muted-foreground mt-1 line-clamp-2">{quiz.description}</p>
                    {attempt && <p className="mt-2 text-center text-xl font-bold text-home-blue">Score {attempt.score}/{attempt.max_marks || attempt.total_questions}</p>}
                    <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" /> {quiz.duration_minutes}m
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="h-3 w-3" /> {quiz.total_questions}Q
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-3">
                      <SaveButton target="quiz" id={quiz.id} />
                      {attempt ? (
                        <>
                          <Button
                            size="sm"
                            variant="outline"
                            className="flex-1 text-xs h-8"
                            onClick={(e) => { e.stopPropagation(); navigate("/result", { state: { attemptId: attempt.id, quizId: quiz.id } }); }}
                          >
                            📊 View Result
                          </Button>
                          <Button size="sm" variant="ghost" className="text-xs h-8" onClick={(e) => { e.stopPropagation(); navigate(`/leaderboard/${quiz.id}`); }}>
                            🏆 Leaderboard
                          </Button>
                        </>
                      ) : (
                        <Button size="sm" variant="outline" className="flex-1 text-xs h-8">
                          ▶️ Start
                        </Button>
                      )}
                      {canManage && (
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-xs h-8 text-destructive"
                          onClick={async (e) => {
                            e.stopPropagation();
                            if (!confirm(`Delete "${quiz.title}"?`)) return;
                            const { error } = await supabase.from("quizzes").delete().eq("id", quiz.id);
                            if (error) { toast.error(error.message); return; }
                            setQuizzes(quizzes.filter(q => q.id !== quiz.id));
                            toast.success("Quiz deleted");
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                    <LikeShareBar
                      targetType="quiz"
                      targetId={quiz.id}
                      shareUrl={`/quiz/${quiz.id}`}
                      shareTitle={quiz.title}
                      onCommentClick={(e) => { e.stopPropagation(); navigate(`/quiz/${quiz.id}#comments`); }}
                    />
                  </div>
                );
              })
            )}
          </div>
        )}
        </>}
      </main>
      <BottomTabBar />
    </div>
  );
};

export default Dashboard;
