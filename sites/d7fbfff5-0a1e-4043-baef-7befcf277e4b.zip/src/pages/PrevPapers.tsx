import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, ChevronRight, FileText, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import { Button } from "@/components/ui/button";
import { PYQ_CATALOG, findCategory } from "@/lib/pyq-catalog";
import SaveButton from "@/components/SaveButton";
import PdfReader, { type PdfPaper } from "@/components/PdfReader";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";

function Shell({ title, back, children }: { title: string; back: string; children: React.ReactNode }) {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto flex items-center gap-3 px-4 py-3">
          <Button variant="ghost" size="icon" className="shrink-0" aria-label={back === "/home" ? "Back to Home" : "Back"} onClick={() => navigate(back, { replace: back !== "/home" })}><ArrowLeft className="h-5 w-5" /></Button>
          <h1 className="min-w-0 font-heading text-lg font-bold [overflow-wrap:anywhere]">{title}</h1>
        </div>
      </header>
      <main className="mx-auto max-w-lg px-4 py-5">{children}</main>
    </div>
  );
}

const Row = ({ label, sub, onClick, icon }: { label: string; sub?: string; onClick: () => void; icon: React.ReactNode }) => (
  <button onClick={onClick} className="flex w-full items-center gap-3 rounded-xl border border-border bg-card p-4 text-left transition hover:border-primary">
    <span className="text-2xl">{icon}</span>
    <span className="min-w-0 flex-1"><span className="block font-semibold">{label}</span>{sub && <span className="block text-sm text-muted-foreground">{sub}</span>}</span>
    <ChevronRight className="h-5 w-5 text-muted-foreground" />
  </button>
);

export function PrevPaperCategories() {
  const navigate = useNavigate();
  return <Shell title="Previous Year Papers" back="/home"><div className="grid gap-3">
    {PYQ_CATALOG.map(c => <Row key={c.id} icon={c.emoji} label={c.name} sub={c.exams.length ? `${c.exams.length} exams` : "Papers"} onClick={() => navigate(`/prev-papers/${c.id}`, { replace: true })} />)}
  </div></Shell>;
}

export function PrevPaperExams() {
  const { category } = useParams();
  const navigate = useNavigate();
  const cat = findCategory(category);
  if (!cat) return <Shell title="Not found" back="/prev-papers"><p className="text-muted-foreground">Category not found.</p></Shell>;
  if (!cat.exams.length) return <PaperList category={cat.id} exam={cat.name} back="/prev-papers" />;
  return <Shell title={`${cat.name} Papers`} back="/prev-papers"><div className="grid gap-3">
    {cat.exams.map(e => <Row key={e} icon={<FileText className="h-6 w-6 text-primary" />} label={e} onClick={() => navigate(`/prev-papers/${cat.id}/${encodeURIComponent(e)}`, { replace: true })} />)}
  </div></Shell>;
}

export function PrevPaperListPage() {
  const { category, exam } = useParams();
  return <PaperList category={category || ""} exam={exam || ""} back={`/prev-papers/${category}`} />;
}

function PaperList({ category, exam, back }: { category: string; exam: string; back: string }) {
  const { user, role } = useAuth();
  const client = useQueryClient();
  const key = ["paper-list", user?.id, category, exam];
  const [reading, setReading] = useState<PdfPaper | null>(null);
  const listing = useQuery({ queryKey: key, queryFn: async ({ signal }) => {
    const { data, error } = await supabase.from("previous_year_papers").select("*").eq("category", category).eq("exam_name", exam).order("year", { ascending: false }).abortSignal(signal);
    if (error) throw error;
    return data || [];
  } });
  const papers = listing.isLoading ? null : listing.data || [];
  const setPapers = (update: (previous: Tables<"previous_year_papers">[]) => Tables<"previous_year_papers">[]) => {
    client.setQueryData<Tables<"previous_year_papers">[]>(key, previous => update(previous || []));
    void client.invalidateQueries({ queryKey: ["home-feed"] });
    void client.invalidateQueries({ queryKey: ["saved-collection"] });
  };
  return <Shell title={exam} back={back}>
    {listing.isError ? <div className="text-center"><p className="text-muted-foreground">Could not load papers</p><Button variant="outline" onClick={() => void listing.refetch()}>Retry</Button></div> : papers === null ? <Loader2 className="mx-auto h-6 w-6 animate-spin text-muted-foreground" />
      : papers.length === 0 ? <p className="text-center text-muted-foreground">No papers uploaded yet.</p>
      : <div className="grid min-w-0 grid-cols-1 gap-3">{papers.map(p => <article key={p.id} className="min-w-0 rounded-lg border border-border bg-card p-4"><h2 className="font-heading font-semibold [overflow-wrap:anywhere]">{p.exam_name} {p.year}</h2><p className="mt-1 text-xs leading-5 text-muted-foreground [overflow-wrap:anywhere]">{p.file_name}</p><div className="mt-3 flex flex-wrap items-center justify-between gap-2"><Button variant="outline" size="sm" onClick={() => setReading(p)}><FileText className="h-4 w-4" />Open PDF</Button><div className="flex gap-2"><SaveButton target="paper" id={p.id} />{role === "admin" && <Button variant="outline" size="sm" className="text-destructive" onClick={async () => { if (!window.confirm(`Delete ${p.file_name}?`)) return; const { error } = await supabase.from("previous_year_papers").delete().eq("id", p.id); if (error) { toast.error("Unable to delete paper"); return; } await supabase.storage.from("previous-year-papers").remove([p.file_path]); setPapers(prev => (prev || []).filter(x => x.id !== p.id)); toast.success("Paper deleted"); }}>Delete</Button>}</div></div></article>)}</div>}
    <PdfReader paper={reading} onClose={() => setReading(null)} />
  </Shell>;
}
