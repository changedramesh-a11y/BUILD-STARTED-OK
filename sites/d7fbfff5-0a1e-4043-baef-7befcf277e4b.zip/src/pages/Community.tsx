import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, ImagePlus, Send, MessageCircle, Trash2, Loader2 } from "lucide-react";
import { optimizeImage } from "@/lib/optimize-image";
import { toast } from "sonner";

interface Post {
  id: string;
  user_id: string;
  caption: string;
  image_url: string;
  created_at: string;
  author_name?: string;
}
interface Reply {
  id: string;
  post_id: string;
  user_id: string;
  caption: string;
  image_url: string;
  created_at: string;
  author_name?: string;
}

const Community = () => {
  const navigate = useNavigate();
  const { user, role } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [caption, setCaption] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [posting, setPosting] = useState(false);
  const [openPostId, setOpenPostId] = useState<string | null>(null);
  const [replies, setReplies] = useState<Record<string, Reply[]>>({});
  const fileRef = useRef<HTMLInputElement>(null);
  const examMode = (localStorage.getItem("exam_mode") as "central" | "jharkhand") || "central";

  const attachAuthors = async <T extends { user_id: string }>(rows: T[]): Promise<(T & { author_name?: string })[]> => {
    const ids = Array.from(new Set(rows.map(r => r.user_id)));
    if (!ids.length) return rows;
    const { data } = await supabase.from("profiles").select("user_id, display_name").in("user_id", ids);
    const map = new Map((data || []).map((p: any) => [p.user_id, p.display_name]));
    return rows.map(r => ({ ...r, author_name: map.get(r.user_id) || "User" }));
  };

  const loadPosts = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("community_posts")
      .select("*")
      .eq("exam_mode", examMode)
      .order("created_at", { ascending: false });
    if (error) toast.error(error.message);
    setPosts(await attachAuthors((data as Post[]) || []));
    setLoading(false);
  };

  useEffect(() => { loadPosts(); }, []);

  const loadReplies = async (postId: string) => {
    const { data } = await supabase
      .from("community_replies")
      .select("*")
      .eq("post_id", postId)
      .order("created_at", { ascending: true });
    const withAuthors = await attachAuthors((data as Reply[]) || []);
    setReplies(prev => ({ ...prev, [postId]: withAuthors }));
  };

  const uploadImage = async (f: File): Promise<string | null> => {
    if (!user) return null;
    f = await optimizeImage(f);
    const ext = f.name.split(".").pop() || "jpg";
    const path = `${user.id}/${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from("community").upload(path, f, { upsert: false });
    if (error) { toast.error(error.message); return null; }
    return supabase.storage.from("community").getPublicUrl(path).data.publicUrl;
  };

  const handlePost = async () => {
    if (!user) return;
    if (!file) { toast.error("Please attach an image"); return; }
    setPosting(true);
    const url = await uploadImage(file);
    if (!url) { setPosting(false); return; }
    const { error } = await supabase.from("community_posts").insert({
      user_id: user.id, caption, image_url: url, exam_mode: examMode,
    });
    setPosting(false);
    if (error) { toast.error(error.message); return; }
    setCaption(""); setFile(null);
    if (fileRef.current) fileRef.current.value = "";
    toast.success("Posted to community");
    loadPosts();
  };

  const handleReply = async (postId: string, replyFile: File | null, replyCaption: string, reset: () => void) => {
    if (!user) return;
    if (!replyFile) { toast.error("Attach an image answer"); return; }
    const url = await uploadImage(replyFile);
    if (!url) return;
    const { error } = await supabase.from("community_replies").insert({
      post_id: postId, user_id: user.id, caption: replyCaption, image_url: url,
    });
    if (error) { toast.error(error.message); return; }
    reset();
    loadReplies(postId);
    toast.success("Answer posted");
  };

  const deletePost = async (id: string) => {
    if (!confirm("Delete this post?")) return;
    const { error } = await supabase.from("community_posts").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    setPosts(prev => prev.filter(p => p.id !== id));
  };

  const canDelete = (uid: string) => uid === user?.id || role === "admin" || role === "moderator";

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card sticky top-0 z-10">
        <div className="container mx-auto px-4 py-3 flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/home")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-bold font-heading text-gradient">Community</h1>
        </div>
      </header>

      <main className="container mx-auto px-4 py-5 max-w-2xl">
        {/* Composer */}
        <div className="bg-card border border-border rounded-xl p-4 mb-6">
          <p className="text-sm font-semibold mb-2">Ask a question with image</p>
          <Textarea
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            placeholder="Type your question (optional)..."
            className="mb-3 min-h-[60px]"
          />
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
          />
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => fileRef.current?.click()} className="gap-2">
              <ImagePlus className="h-4 w-4" /> {file ? "Change image" : "Add image"}
            </Button>
            {file && <span className="text-xs text-muted-foreground truncate flex-1">{file.name}</span>}
            <Button size="sm" onClick={handlePost} disabled={posting || !file} className="gap-2 ml-auto">
              {posting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              Post
            </Button>
          </div>
        </div>

        {/* Posts feed */}
        {loading ? (
          <div className="text-center py-10 text-muted-foreground">Loading...</div>
        ) : posts.length === 0 ? (
          <div className="text-center py-10 text-muted-foreground">
            No community posts yet. Be the first to ask!
          </div>
        ) : (
          <div className="space-y-5">
            {posts.map((p) => (
              <PostCard
                key={p.id}
                post={p}
                isOpen={openPostId === p.id}
                onToggle={() => {
                  const next = openPostId === p.id ? null : p.id;
                  setOpenPostId(next);
                  if (next && !replies[p.id]) loadReplies(p.id);
                }}
                replies={replies[p.id] || []}
                onReply={handleReply}
                onDelete={canDelete(p.user_id) ? () => deletePost(p.id) : undefined}
                canDeleteReply={canDelete}
                onDeleteReply={async (rid) => {
                  if (!confirm("Delete this reply?")) return;
                  const { error } = await supabase.from("community_replies").delete().eq("id", rid);
                  if (error) { toast.error(error.message); return; }
                  loadReplies(p.id);
                }}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

const PostCard = ({
  post, isOpen, onToggle, replies, onReply, onDelete, canDeleteReply, onDeleteReply,
}: {
  post: Post;
  isOpen: boolean;
  onToggle: () => void;
  replies: Reply[];
  onReply: (postId: string, file: File | null, caption: string, reset: () => void) => void;
  onDelete?: () => void;
  canDeleteReply: (uid: string) => boolean;
  onDeleteReply: (id: string) => void;
}) => {
  const [rFile, setRFile] = useState<File | null>(null);
  const [rCap, setRCap] = useState("");
  const ref = useRef<HTMLInputElement>(null);
  const reset = () => { setRFile(null); setRCap(""); if (ref.current) ref.current.value = ""; };

  return (
    <article className="bg-card border border-border rounded-xl overflow-hidden">
      <div className="p-3 flex items-center justify-between">
        <div>
          <p className="text-sm font-semibold">{post.author_name || "User"}</p>
          <p className="text-xs text-muted-foreground">{new Date(post.created_at).toLocaleString()}</p>
        </div>
        {onDelete && (
          <Button size="icon" variant="ghost" className="text-destructive" onClick={onDelete}>
            <Trash2 className="h-4 w-4" />
          </Button>
        )}
      </div>
      <img src={post.image_url} alt={post.caption || "Community question"} className="w-full max-h-[500px] object-contain bg-muted" loading="lazy" />
      {post.caption && <p className="px-4 py-3 text-sm whitespace-pre-wrap">{post.caption}</p>}
      <div className="px-3 pb-3">
        <Button variant="ghost" size="sm" className="gap-2" onClick={onToggle}>
          <MessageCircle className="h-4 w-4" />
          {isOpen ? "Hide answers" : `View answers${replies.length ? ` (${replies.length})` : ""}`}
        </Button>
      </div>

      {isOpen && (
        <div className="border-t border-border bg-secondary/30 px-3 py-3 space-y-3">
          {replies.length === 0 && (
            <p className="text-xs text-muted-foreground text-center py-2">No answers yet. Be the first!</p>
          )}
          {replies.map((r) => (
            <div key={r.id} className="bg-card rounded-lg border border-border overflow-hidden">
              <div className="px-3 py-2 flex items-center justify-between">
                <div>
                  <p className="text-xs font-semibold">{r.author_name || "User"}</p>
                  <p className="text-[10px] text-muted-foreground">{new Date(r.created_at).toLocaleString()}</p>
                </div>
                {canDeleteReply(r.user_id) && (
                  <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={() => onDeleteReply(r.id)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                )}
              </div>
              <img src={r.image_url} alt={r.caption || "Answer"} className="w-full max-h-[400px] object-contain bg-muted" loading="lazy" />
              {r.caption && <p className="px-3 py-2 text-xs whitespace-pre-wrap">{r.caption}</p>}
            </div>
          ))}

          {/* Reply composer */}
          <div className="bg-card rounded-lg border border-border p-3">
            <Input
              value={rCap}
              onChange={(e) => setRCap(e.target.value)}
              placeholder="Your answer caption (optional)"
              className="mb-2 h-9 text-sm"
            />
            <input
              ref={ref}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => setRFile(e.target.files?.[0] || null)}
            />
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => ref.current?.click()} className="gap-2">
                <ImagePlus className="h-4 w-4" /> {rFile ? "Change" : "Image"}
              </Button>
              {rFile && <span className="text-xs text-muted-foreground truncate flex-1">{rFile.name}</span>}
              <Button size="sm" className="gap-2 ml-auto" onClick={() => onReply(post.id, rFile, rCap, reset)} disabled={!rFile}>
                <Send className="h-4 w-4" /> Reply
              </Button>
            </div>
          </div>
        </div>
      )}
    </article>
  );
};

export default Community;
