import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Calendar, Trash2 } from "lucide-react";
import { toast } from "sonner";
import LikeShareBar from "@/components/LikeShareBar";
import BlogCommentSection from "@/components/BlogCommentSection";
import SaveButton from "@/components/SaveButton";
import StudyNoteContent from "@/components/StudyNoteContent";

interface Post {
  id: string;
  title: string;
  content: string;
  category: string;
  cover_image_url: string | null;
  created_at: string;
}

const BlogPost = () => {
  const { id } = useParams<{ id: string }>();
  const { user, role } = useAuth();
  const client = useQueryClient();
  const navigate = useNavigate();
  const [post, setPost] = useState<Post | null>(null);
  const [loading, setLoading] = useState(true);
  const canManage = role === "admin" || role === "moderator";

  useEffect(() => {
    if (!id) return;
    supabase
      .from("blog_posts")
      .select("id, title, content, category, cover_image_url, created_at")
      .eq("id", id)
      .eq("is_published", true)
      .maybeSingle()
      .then(({ data }) => {
        setPost(data as Post | null);
        setLoading(false);
      });
  }, [id]);

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-muted-foreground">Loading...</div>;
  }

  if (!post) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Post not found</p>
          <Button onClick={() => navigate("/blog")}>Back to Blog</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card sticky top-0 z-10">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex min-w-0 items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate("/blog")}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-lg font-bold font-heading text-foreground truncate">{post.title}</h1>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            {canManage && (
              <Button
                variant="ghost"
                size="icon"
                className="text-destructive"
                onClick={async () => {
                  if (!confirm("Delete this blog post?")) return;
                  const { error } = await supabase.from("blog_posts").delete().eq("id", id);
                  if (error) { toast.error(error.message); return; }
                  void client.invalidateQueries({ queryKey: ["blog-list"] });
                  void client.invalidateQueries({ queryKey: ["home-feed"] });
                  void client.invalidateQueries({ queryKey: ["saved-collection"] });
                  toast.success("Post deleted");
                  navigate("/blog");
                }}
              >
                <Trash2 className="h-5 w-5" />
              </Button>
            )}
            {id && <SaveButton target="note" id={id} />}
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 max-w-2xl">
        {post.cover_image_url && (
          <img
            src={post.cover_image_url}
            alt={post.title}
            decoding="async"
            className="w-full h-48 md:h-64 object-cover rounded-xl mb-6"
          />
        )}

        <div className="flex items-center gap-3 mb-4">
          <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-primary/10 text-primary">
            {post.category}
          </span>
          <span className="flex items-center gap-1 text-xs text-muted-foreground">
            <Calendar className="h-3 w-3" />
            {new Date(post.created_at).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
          </span>
        </div>

        <h1 className="text-2xl font-bold font-heading text-foreground mb-6">{post.title}</h1>

        <StudyNoteContent content={post.content} />

        {id && (
          <LikeShareBar
            targetType="post"
            targetId={id}
            shareUrl={`/blog/${id}`}
            shareTitle={post.title}
            onCommentClick={() => {
              document.getElementById("comments")?.scrollIntoView({ behavior: "smooth" });
            }}
            compact={false}
          />
        )}

        {id && (
          <div id="comments">
            <BlogCommentSection blogPostId={id} />
          </div>
        )}
      </main>
    </div>
  );
};

export default BlogPost;
