import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Trophy, Calendar } from "lucide-react";

interface Attempt {
  id: string;
  quiz_id: string;
  score: number;
  total_questions: number;
  max_marks: number;
  percentage: number;
  created_at: string;
  quiz_title?: string;
}

const Scoreboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [attempts, setAttempts] = useState<Attempt[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAttempts = async () => {
      if (!user) return;
      const { data } = await supabase
        .from("attempts")
        .select("*, quizzes(title)")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      const mapped = (data || []).map((a: any) => ({
        ...a,
        quiz_title: a.quizzes?.title || "Unknown Quiz",
      }));
      setAttempts(mapped);
      setLoading(false);
    };
    fetchAttempts();
  }, [user]);

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card sticky top-0 z-10">
        <div className="container mx-auto px-4 py-3 flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/home")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-bold font-heading text-foreground">My Scoreboard</h1>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 max-w-lg">
        {loading ? (
          <div className="text-center py-12 text-muted-foreground">Loading...</div>
        ) : attempts.length === 0 ? (
          <div className="text-center py-12">
            <Trophy className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No attempts yet. Take a quiz!</p>
            <Button className="mt-4" onClick={() => navigate("/home")}>
              Browse Quizzes
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {attempts.map((attempt) => (
              <div key={attempt.id} className="bg-card rounded-xl p-4 card-shadow border border-border">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold font-heading text-foreground">{attempt.quiz_title}</h3>
                    <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                      <Calendar className="h-3.5 w-3.5" />
                      {new Date(attempt.created_at).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-2xl font-bold font-heading ${
                      attempt.percentage >= 70 ? "text-primary" : attempt.percentage >= 50 ? "text-accent" : "text-destructive"
                    }`}>
                      {attempt.percentage}%
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {attempt.score}/{attempt.max_marks || attempt.total_questions}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default Scoreboard;
