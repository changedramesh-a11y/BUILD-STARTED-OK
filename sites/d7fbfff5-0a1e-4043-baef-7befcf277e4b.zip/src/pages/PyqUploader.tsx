import { useEffect, useRef, useState, type FormEvent } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, FileText, Loader2, Upload, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { validatePaper } from "@/lib/previous-year-paper";
import { PYQ_CATALOG, findCategory } from "@/lib/pyq-catalog";
import PdfReader, { type PdfPaper } from "@/components/PdfReader";

const BUCKET = "previous-year-papers";

export default function PyqUploader() {
  const { user, role } = useAuth();
  const client = useQueryClient();
  const navigate = useNavigate();
  const canManage = role === "admin" || role === "moderator";
  const [category, setCategory] = useState(PYQ_CATALOG[0].id);
  const [examName, setExamName] = useState(PYQ_CATALOG[0].exams[0]);
  const cat = findCategory(category) || PYQ_CATALOG[0];
  const [year, setYear] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);
  const [papers, setPapers] = useState<Tables<"previous_year_papers">[]>([]);
  const [reading, setReading] = useState<PdfPaper | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!canManage) return;
    supabase.from("previous_year_papers").select("*").order("created_at", { ascending: false }).then(({ data, error }) => {
      if (error) toast.error("Could not load uploaded papers");
      else setPapers(data || []);
    });
  }, [canManage]);

  async function uploadPaper(event: FormEvent) {
    event.preventDefault();
    if (saving || !user || !canManage) return;
    const validation = validatePaper(examName, year, file);
    if (validation) { toast.error(validation); return; }
    if (!file) return;
    setSaving(true);
    const path = `${user.id}/${crypto.randomUUID()}.pdf`;
    let uploaded = false;
    try {
      const signature = await file.slice(0, 5).text();
      if (signature !== "%PDF-") throw new Error("Please choose a valid PDF file");
      const { error: uploadError } = await supabase.storage.from(BUCKET).upload(path, file, { contentType: "application/pdf", upsert: false });
      if (uploadError) throw uploadError;
      uploaded = true;
      const { data, error } = await supabase.from("previous_year_papers").insert({
        category, exam_name: examName.trim(), year: Number(year), file_path: path, file_name: file.name, uploaded_by: user.id,
      }).select().single();
      if (error) throw error;
      setPapers(current => [data, ...current]);
      void client.invalidateQueries({ queryKey: ["paper-list"] });
      void client.invalidateQueries({ queryKey: ["home-feed"] });
      setYear(""); setFile(null);
      if (inputRef.current) inputRef.current.value = "";
      toast.success("Previous year paper uploaded successfully");
    } catch (error) {
      if (uploaded) await supabase.storage.from(BUCKET).remove([path]);
      toast.error(error instanceof Error ? error.message : "Could not upload the paper. Please try again.");
    } finally { setSaving(false); }
  }


  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto flex items-center gap-3 px-4 py-3">
          <Button variant="ghost" size="icon" aria-label="Back to dashboard" onClick={() => navigate("/home")}><ArrowLeft className="h-5 w-5" /></Button>
          <h1 className="font-heading text-lg font-bold">Add Previous Year Paper</h1>
        </div>
      </header>
      <main className="mx-auto max-w-lg px-4 py-6">
        {!canManage ? <p className="text-muted-foreground">Only admins and moderators can upload papers.</p> : <>
          <form onSubmit={uploadPaper} className="space-y-5">
            <div className="space-y-2"><Label htmlFor="paper-category">Exam section</Label><select id="paper-category" className="h-10 w-full rounded-md border border-input bg-background px-3" value={category} disabled={saving} onChange={e => { const c = findCategory(e.target.value); if (!c) return; setCategory(c.id); setExamName(c.exams[0] || c.name); }}>{PYQ_CATALOG.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
            <div className="space-y-2"><Label htmlFor="exam-name">Exam name</Label>{cat.exams.length ? <select id="exam-name" className="h-10 w-full rounded-md border border-input bg-background px-3" value={examName} disabled={saving} onChange={e => setExamName(e.target.value)}>{cat.exams.map(x => <option key={x}>{x}</option>)}</select> : <Input id="exam-name" value={examName} onChange={e => setExamName(e.target.value)} required disabled={saving} />}</div>
            <div className="space-y-2"><Label htmlFor="paper-year">Year</Label><Input id="paper-year" type="number" min={1900} max={9999} value={year} onChange={e => setYear(e.target.value)} required disabled={saving} /></div>
            <div className="space-y-2">
              <Label htmlFor="paper-pdf">Upload PDF</Label>
              <Input ref={inputRef} id="paper-pdf" type="file" accept=".pdf,application/pdf" disabled={saving} onChange={e => setFile(e.target.files?.[0] || null)} className="h-auto py-3 file:mr-3" />
              {file && <p className="break-all text-sm text-muted-foreground">{file.name}</p>}
            </div>
            <Button type="submit" disabled={saving} className="w-full gap-2">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}{saving ? "Uploading…" : "Upload Paper"}</Button>
          </form>
          {papers.length > 0 && <section className="mt-8 border-t border-border pt-5">
            <h2 className="mb-3 font-heading font-semibold">Uploaded papers</h2>
            <ul className="divide-y divide-border">{papers.map(paper => <li key={paper.id} className="flex items-center gap-3 py-3">
              <FileText className="h-5 w-5 shrink-0 text-primary" />
              <div className="min-w-0 flex-1"><p className="break-words font-medium">{paper.exam_name}</p><p className="text-sm text-muted-foreground">{paper.year}</p></div>
              <Button variant="ghost" size="icon" aria-label={`Open ${paper.exam_name} ${paper.year} PDF`} onClick={() => setReading(paper)}><ExternalLink className="h-4 w-4" /></Button>
            </li>)}</ul>
          </section>}
        </>}
      </main>
      <PdfReader paper={reading} onClose={() => setReading(null)} />
    </div>
  );
}