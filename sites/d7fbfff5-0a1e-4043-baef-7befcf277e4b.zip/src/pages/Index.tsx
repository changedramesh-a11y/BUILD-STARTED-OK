import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Shield, BookOpen, Trophy, ArrowRight, CheckCircle } from "lucide-react";

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <section className="hero-gradient text-primary-foreground">
        <div className="container mx-auto px-4 py-16 text-center">
          <div className="inline-flex items-center gap-2 mb-6">
            <Shield className="h-10 w-10" />
            <span className="text-4xl font-extrabold font-heading">MISSION JSSC</span>
          </div>
          <h1 className="text-2xl md:text-4xl font-bold font-heading mb-4">
            Your Trusted Path to Exam Success
          </h1>
          <p className="text-primary-foreground/80 max-w-md mx-auto mb-8">
            Practice quizzes and mock tests designed to help you ace any exam with confidence.
          </p>
          <Button
            size="lg"
            onClick={() => navigate("/auth")}
            className="bg-card text-foreground hover:bg-card/90 font-semibold gap-2"
          >
            Get Started <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </section>

      {/* Features */}
      <section className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              icon: BookOpen,
              title: "Quizzes & Mocks",
              desc: "Topic-wise quizzes and full-length mock tests curated by experts.",
            },
            {
              icon: Trophy,
              title: "Instant Scorecard",
              desc: "Get detailed results and track your progress over time.",
            },
            {
              icon: CheckCircle,
              title: "Trusted Content",
              desc: "All content reviewed and uploaded by verified admins and moderators.",
            },
          ].map((f, i) => (
            <div key={i} className="bg-card rounded-xl p-6 card-shadow border border-border text-center">
              <f.icon className="h-10 w-10 text-primary mx-auto mb-4" />
              <h3 className="font-bold font-heading text-foreground mb-2">{f.title}</h3>
              <p className="text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="container mx-auto px-4 pb-16 text-center">
        <Button onClick={() => navigate("/auth")} size="lg" className="gap-2">
          Start Practicing Now <ArrowRight className="h-4 w-4" />
        </Button>
      </section>
    </div>
  );
};

export default Index;
