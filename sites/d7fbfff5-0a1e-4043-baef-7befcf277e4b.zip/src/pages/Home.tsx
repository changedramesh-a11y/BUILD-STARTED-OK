import { lazy, Suspense, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Link, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { Activity, Menu, ArrowRight, BookOpen, Bookmark, ClipboardList, FileText, Megaphone, MessageCircle, Moon, Newspaper, RefreshCw, Settings, Shield, Sun, UserCircle, Trophy, Plus, Bell, LogOut } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import BottomTabBar from "@/components/BottomTabBar";
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Switch } from "@/components/ui/switch";
import { loadHomeFeed, type FeedKind } from "@/lib/home-feed";
const StoryUploader = lazy(() => import("@/components/StoryUploader"));
const NoticeUploader = lazy(() => import("@/components/NoticeUploader"));
import SaveButton from "@/components/SaveButton";
import { useExitBack } from "@/hooks/use-exit-back";
import { useExamMode } from "@/hooks/use-exam-mode";
import { useOpenedUploads } from "@/hooks/use-opened-uploads";
import { unopenedUploads } from "@/lib/opened-uploads";

const KINDS = {
  test: { icon: ClipboardList, tone: "text-home-blue bg-home-blue/10" },
  note: { icon: BookOpen, tone: "text-emerald bg-emerald/10" },
  affairs: { icon: Newspaper, tone: "text-home-blue bg-home-blue/10" },
  paper: { icon: FileText, tone: "text-rose bg-rose/10" },
  notice: { icon: Megaphone, tone: "text-amber-foreground bg-amber/20" },
  community: { icon: MessageCircle, tone: "text-cyan bg-cyan/10" },
};
const FILTERS: { value: FeedKind | "all"; label: string }[] = [
  { value: "all", label: "All updates" }, { value: "test", label: "Tests" },
  { value: "note", label: "Study Notes" }, { value: "affairs", label: "Current Affairs" },
  { value: "paper", label: "Papers" }, { value: "notice", label: "Notices" }, { value: "community", label: "Community" },
];

export default function Home() {
  const { user, role, signOut } = useAuth();
  const navigate = useNavigate();
  const { data: approved } = useQuery({ queryKey: ["member-approval", user?.id], enabled: Boolean(user), queryFn: async () => { const { data, error } = await supabase.rpc("is_approved_member"); if (error) throw error; return data; } });
  useExitBack();
  const [examMode, setExamMode] = useExamMode();
  const [filter, setFilter] = useState<FeedKind | "all">("all");
  const [menuOpen, setMenuOpen] = useState(false);
  const [uploaderOpen, setUploaderOpen] = useState(false);
  const [noticeOpen, setNoticeOpen] = useState(false);
  const [isDark, setIsDark] = useState(() => document.documentElement.classList.contains("dark"));
  const toggleTheme = () => {
    const next = !isDark;
    setIsDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("theme", next ? "dark" : "light");
  };
  const { data = [], isLoading, isError, isFetching, refetch } = useQuery({ queryKey: ["home-feed", user?.id, examMode], queryFn: () => loadHomeFeed(examMode) });
  const { opened, markOpened } = useOpenedUploads(user?.id);
  const visible = useMemo(() => unopenedUploads(data, opened).filter(item => filter === "all" || item.kind === filter), [data, opened, filter]);
  const canManage = role === "admin" || role === "moderator";

  return (
    <div className="min-h-screen bg-background pb-28">
      <header className="bg-home-header text-home-header-foreground">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-4 sm:px-6">
          <div className="flex min-w-0 items-center gap-2">
            <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
              <SheetTrigger asChild><Button variant="ghost" size="icon" aria-label="Menu" className="shrink-0 hover:bg-home-header-foreground/10 hover:text-home-header-foreground"><Menu /></Button></SheetTrigger>
              <SheetContent side="left" className="flex w-72 flex-col p-0">
                <SheetHeader className="border-b border-border px-5 py-4"><SheetTitle>Menu</SheetTitle></SheetHeader>
                <nav className="flex min-h-0 flex-col gap-1 overflow-y-auto p-3">
                  <Button asChild variant="ghost" className="justify-start" onClick={() => setMenuOpen(false)}><Link to="/activity"><Activity />Activity</Link></Button>
                  <Button asChild variant="ghost" className="justify-start" onClick={() => setMenuOpen(false)}><Link to="/profile"><UserCircle />Profile</Link></Button>
                  <Button asChild variant="ghost" className="justify-start" onClick={() => setMenuOpen(false)}><Link to="/blog"><BookOpen />Blog</Link></Button>
                  <Button asChild variant="ghost" className="justify-start" onClick={() => setMenuOpen(false)}><Link to="/community"><MessageCircle />Community</Link></Button>
                  <Button asChild variant="ghost" className="justify-start" onClick={() => setMenuOpen(false)}><Link to="/scoreboard"><Trophy />Scores</Link></Button>
                  {canManage && <div className="my-2 flex flex-col gap-1 border-y border-border py-2">
                    <Button asChild variant="ghost" className="justify-start text-home-blue" onClick={() => setMenuOpen(false)}><Link to="/admin"><Settings />Manage</Link></Button>
                    <Button asChild variant="ghost" className="justify-start" onClick={() => setMenuOpen(false)}><Link to="/blog-admin"><BookOpen />Add Study Notes</Link></Button>
                    <Button asChild variant="ghost" className="justify-start" onClick={() => setMenuOpen(false)}><Link to="/pyq-upload"><FileText />Add PYQ</Link></Button>
                    <Button variant="ghost" className="justify-start" onClick={() => { setMenuOpen(false); setUploaderOpen(true); }}><Plus />Add Daily Current Affairs</Button>
                    {role === "admin" && <Button variant="ghost" className="justify-start" onClick={() => { setMenuOpen(false); setNoticeOpen(true); }}><Bell />Add Notice</Button>}
                    {role === "admin" && <Button variant="ghost" className="justify-start" onClick={() => { setMenuOpen(false); navigate("/approvals"); }}><Bell />Approve Students</Button>}
                  </div>}
                  <div className="flex items-center justify-between rounded-md px-4 py-2">
                    <span className="flex items-center gap-2 text-sm font-medium">{isDark ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}Dark Theme</span>
                    <Switch checked={isDark} onCheckedChange={toggleTheme} aria-label="Dark theme" />
                  </div>
                  <Button asChild variant="ghost" className="justify-start" onClick={() => setMenuOpen(false)}><Link to="/activity"><ClipboardList />Attempted Quizzes</Link></Button>
                  <Button asChild variant="ghost" className="justify-start" onClick={() => setMenuOpen(false)}><Link to="/activity"><Trophy />Attempted Mocks</Link></Button>
                  <Button asChild variant="ghost" className="justify-start" onClick={() => setMenuOpen(false)}><Link to="/saved/notes"><Bookmark />Saved Blogs</Link></Button>
                  <Button variant="ghost" className="mt-3 justify-start text-destructive hover:text-destructive" onClick={async () => { setMenuOpen(false); await signOut(); navigate("/auth", { replace: true }); }}><LogOut />Logout</Button>
                </nav>
              </SheetContent>
            </Sheet>
            <Link to="/home" className="flex min-w-0 items-center gap-2 font-heading text-sm font-extrabold sm:text-lg"><Shield className="h-5 w-5 shrink-0 text-home-mint" /><span>MISSION JSSC</span></Link>
          </div>
          <div className="flex shrink-0 items-center gap-1">
            <Button asChild variant="ghost" size="icon" className="hover:bg-home-header-foreground/10 hover:text-home-header-foreground" aria-label="Profile"><Link to="/profile"><UserCircle /></Link></Button>
          </div>
        </div>
      </header>

      <section className="border-b border-border bg-card">
        <div className="mx-auto max-w-6xl px-4 py-7 sm:px-6 sm:py-9">
          <div className="flex flex-wrap items-start justify-between gap-5">
            <div>
              <p className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase text-home-blue"><span className="h-1.5 w-1.5 rounded-full bg-emerald" /> Your daily preparation</p>
              <h1 className="font-heading text-3xl font-extrabold sm:text-4xl">Home</h1>
              <p className="mt-2 text-sm text-muted-foreground">Latest tests, study notes & exam updates.</p>
            </div>
            <div className="flex flex-col gap-2">
              <span className="text-xs font-medium text-muted-foreground">Exam preference</span>
              <div className="flex gap-1 rounded-md bg-secondary p-1" role="group" aria-label="Exam preference">
                {(["central", "jharkhand"] as const).map(mode => <Button key={mode} size="sm" variant="ghost" aria-pressed={examMode === mode} onClick={() => setExamMode(mode)} className={examMode === mode ? "bg-card text-home-blue shadow-sm hover:bg-card hover:text-home-blue" : "text-muted-foreground hover:bg-card hover:text-foreground"}>{mode === "central" ? "Central" : "Jharkhand"}</Button>)}
              </div>
            </div>
          </div>
          <section className="mt-7 border-t border-border pt-5" aria-labelledby="your-saved">
            <h2 id="your-saved" className="mb-4 font-heading text-lg font-bold">Your saved</h2>
            <div className="grid grid-cols-2 gap-x-5 gap-y-4 sm:grid-cols-4">
            {[{ label: "Daily Quiz", path: "/saved/daily", icon: ClipboardList, tone: "text-home-blue bg-home-blue/10" }, { label: "Weekly Mock", path: "/saved/weekly", icon: ClipboardList, tone: "text-emerald bg-emerald/10" }, { label: "Study Notes", path: "/saved/notes", icon: BookOpen, tone: "text-rose bg-rose/10" }, { label: "Previous Papers", path: "/saved/papers", icon: FileText, tone: "text-amber-foreground bg-amber/20" }].map(action => <Button asChild variant="ghost" key={action.path} className="group h-auto justify-start whitespace-normal p-0 text-sm font-semibold hover:bg-transparent"><Link to={action.path}><span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-md ${action.tone}`}><action.icon className="h-5 w-5" /></span><span className="min-w-0 text-left">{action.label}</span><ArrowRight className="ml-auto h-4 w-4 shrink-0 text-muted-foreground" /></Link></Button>)}
            </div>
          </section>
        </div>
      </section>

      <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6">
        {approved === false && <p className="mb-4 rounded-lg border border-border bg-card p-3 text-sm text-muted-foreground">Your account is waiting for admin approval. Notices, previous papers and community posts will appear once you are approved.</p>}
        <div className="mb-4 flex items-center justify-between gap-3">
          <div><h2 className="font-heading text-xl font-bold">Recently uploaded</h2><p className="mt-1 text-xs text-muted-foreground">Newest first · {examMode === "central" ? "Central" : "Jharkhand"} exams</p></div>
          <Button variant="outline" size="icon" aria-label="Refresh updates" title="Refresh updates" disabled={isFetching} onClick={() => void refetch()}><RefreshCw className={isFetching ? "animate-spin motion-reduce:animate-none" : ""} /></Button>
        </div>
        <div className="mb-5 flex gap-2 overflow-x-auto pb-2" role="group" aria-label="Content type">
          {FILTERS.map(item => <Button key={item.value} size="sm" variant="outline" aria-pressed={filter === item.value} onClick={() => setFilter(item.value)} className={`shrink-0 ${filter === item.value ? "border-home-blue bg-home-blue text-home-blue-foreground hover:bg-home-blue/90 hover:text-home-blue-foreground" : "text-muted-foreground hover:bg-secondary hover:text-foreground"}`}>{item.label}</Button>)}
        </div>
        {isLoading ? <div role="status" className="py-16 text-center text-sm text-muted-foreground">Loading latest uploads…</div> : isError ? <div role="alert" className="py-16 text-center"><p className="mb-4 text-muted-foreground">Could not load recent uploads.</p><Button variant="outline" onClick={() => void refetch()}><RefreshCw /> Try again</Button></div> : visible.length === 0 ? <div className="py-16 text-center"><BookOpen className="mx-auto mb-3 h-9 w-9 text-muted-foreground" /><h3 className="font-heading font-semibold">No uploads yet</h3><p className="mt-2 text-sm text-muted-foreground">New published content will appear here.</p></div> : <div className="grid items-start gap-4 md:grid-cols-2 lg:grid-cols-3">
          {visible.map(item => {
            const { icon: Icon, tone } = KINDS[item.kind];
            return <article key={`${item.kind}-${item.id}`} className="mobile-feed-item flex h-full min-w-0 flex-col overflow-hidden rounded-lg border border-border bg-card transition-colors hover:border-home-blue/40">
              {item.image && <Link to={item.path} onClick={() => markOpened(item)} tabIndex={-1} aria-hidden="true"><img src={item.image} alt="" loading="lazy" decoding="async" width={640} height={360} className="aspect-[16/9] w-full bg-muted object-cover" /></Link>}
              <div className="flex flex-1 flex-col p-5">
                <div className="mb-3 flex flex-wrap items-center gap-2"><span className={`flex h-7 w-7 items-center justify-center rounded-md ${tone}`}><Icon className="h-4 w-4" /></span><span className="mr-auto text-xs font-semibold text-muted-foreground">{item.label}</span>{["test", "note", "paper"].includes(item.kind) && <SaveButton target={item.kind === "test" ? "quiz" : item.kind === "note" ? "note" : "paper"} id={item.id} />}</div>
                <h3 className="break-words font-heading text-base font-bold leading-6"><Link to={item.path} onClick={() => markOpened(item)} className="hover:text-home-blue">{item.title}</Link></h3>
                {item.description && <p className="mt-2 line-clamp-3 break-words text-sm leading-6 text-muted-foreground">{item.description}</p>}
                {item.meta && <p className="mt-3 text-xs font-medium text-muted-foreground">{item.meta}</p>}
                <div className="mt-auto flex items-center justify-between gap-2 pt-5"><time dateTime={item.createdAt} className="text-xs text-muted-foreground">{format(new Date(item.createdAt), "d MMM yyyy")}</time><Button asChild variant="ghost" size="sm" className="h-8 px-2 text-home-blue hover:bg-home-blue/10 hover:text-home-blue"><Link to={item.path} onClick={() => markOpened(item)}>{item.kind === "test" ? "Open test" : item.kind === "paper" ? "View paper" : item.kind === "notice" ? "Read notice" : "Read more"}<ArrowRight /></Link></Button></div>
              </div>
            </article>;
          })}
        </div>}
      </main>
      <Suspense fallback={null}>
        {canManage && uploaderOpen && <StoryUploader examMode={examMode} onClose={() => setUploaderOpen(false)} onCreated={() => { setUploaderOpen(false); void refetch(); }} />}
        {role === "admin" && noticeOpen && <NoticeUploader onClose={() => setNoticeOpen(false)} onCreated={() => { setNoticeOpen(false); void refetch(); }} />}
      </Suspense>
      <BottomTabBar />
    </div>
  );
}