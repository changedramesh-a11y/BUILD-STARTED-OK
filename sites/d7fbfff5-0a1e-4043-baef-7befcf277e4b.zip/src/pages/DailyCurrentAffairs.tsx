import { useCallback, useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { ArrowLeft, ChevronLeft, ChevronRight, Newspaper, RefreshCw, Trash2 } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Carousel, CarouselContent, CarouselItem, type CarouselApi } from "@/components/ui/carousel";
import BottomTabBar from "@/components/BottomTabBar";
import type { Story } from "@/components/StoryBar";

const DailyCurrentAffairs = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const articleId = searchParams.get("article");
  const { role } = useAuth();
  const isAdmin = role === "admin";
  const [stories, setStories] = useState<Story[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [api, setApi] = useState<CarouselApi>();
  const [index, setIndex] = useState(0);
  const examMode = localStorage.getItem("exam_mode") === "jharkhand" ? "jharkhand" : "central";

  const load = useCallback(async () => {
    setLoading(true);
    setError(false);
    try {
      const { data, error: requestError } = await supabase
        .from("stories")
        .select("*")
        .eq("exam_mode", examMode)
        .gt("expires_at", new Date().toISOString())
        .order("created_at", { ascending: false });
      if (requestError) throw requestError;
      setStories(data || []);
      setIndex(0);
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  }, [examMode]);

  useEffect(() => { void load(); }, [load]);

  useEffect(() => {
    if (!api || !articleId) return;
    const position = stories.findIndex(story => story.id === articleId);
    if (position >= 0) api.scrollTo(position, true);
  }, [api, articleId, stories]);

  const removeStory = async (id: string) => {
    if (!confirm("Delete this article?")) return;
    const { error: delError } = await supabase.from("stories").delete().eq("id", id);
    if (delError) { toast.error(delError.message); return; }
    setStories((prev) => prev.filter((s) => s.id !== id));
    toast.success("Article deleted");
  };

  useEffect(() => {
    if (!api) return;
    const onSelect = () => setIndex(api.selectedScrollSnap());
    onSelect();
    api.on("select", onSelect);
    api.on("reInit", onSelect);
    return () => {
      api.off("select", onSelect);
      api.off("reInit", onSelect);
    };
  }, [api]);

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="border-b border-border bg-card">
        <div className="mx-auto flex max-w-3xl items-center gap-3 px-4 py-4">
          <Button variant="ghost" size="icon" aria-label="Back to Home" onClick={() => navigate("/home")}>
            <ArrowLeft />
          </Button>
          <div className="min-w-0">
            <h1 className="font-heading text-lg font-bold leading-tight">Daily Current Affairs</h1>
            <p className="mt-1 text-xs text-muted-foreground">{examMode === "central" ? "Central Exam" : "Jharkhand Exam"}</p>
          </div>
          <Newspaper className="ml-auto h-5 w-5 shrink-0 text-primary" />
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4 pt-5">
        {loading ? (
          <div role="status" className="py-20 text-center text-muted-foreground">Loading current affairs…</div>
        ) : error ? (
          <div role="alert" className="py-20 text-center">
            <p className="mb-4 text-muted-foreground">Could not load current affairs.</p>
            <Button variant="outline" onClick={() => void load()}><RefreshCw /> Try again</Button>
          </div>
        ) : stories.length === 0 ? (
          <div className="py-20 text-center">
            <Newspaper className="mx-auto mb-4 h-10 w-10 text-muted-foreground" />
            <h2 className="font-heading font-semibold">No current affairs published yet</h2>
            <p className="mt-2 text-sm text-muted-foreground">New articles will appear here for your {examMode === "central" ? "Central" : "Jharkhand"} exam.</p>
          </div>
        ) : (
          <>
            <Carousel setApi={setApi} opts={{ align: "start", loop: false, watchDrag: true }} aria-label="Current affairs articles">
              <CarouselContent>
                {stories.map((story, position) => (
                  <CarouselItem key={story.id} aria-label={`Article ${position + 1} of ${stories.length}`} aria-hidden={position !== index}>
                    <article className="min-w-0 overflow-hidden pb-5">
                      {story.image_url && (
                        <img src={story.image_url} alt={story.title} loading={position === index ? "eager" : "lazy"} decoding="async" className="mb-5 max-h-80 w-full rounded-lg bg-muted object-contain" draggable={false} />
                      )}
                      <div className="mb-3 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                        <span className="font-semibold uppercase text-primary">Current Affairs</span>
                        <span aria-hidden="true">·</span>
                        <time dateTime={story.created_at}>{new Date(story.created_at).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}</time>
                        {isAdmin && (
                          <Button variant="destructive" size="sm" className="ml-auto h-7" onClick={() => void removeStory(story.id)}>
                            <Trash2 /> Delete
                          </Button>
                        )}
                      </div>
                      <h2 className="break-words font-heading text-2xl font-bold leading-snug">{story.title}</h2>
                      <div className="mt-5 whitespace-pre-line break-words text-base leading-8 text-foreground">{story.content}</div>
                    </article>
                  </CarouselItem>
                ))}
              </CarouselContent>
            </Carousel>
            <div className="sticky bottom-20 mt-4 flex items-center justify-between gap-4 border-t border-border bg-background py-3">
              <Button variant="outline" size="icon" title="Previous article" aria-label="Previous article" disabled={index === 0} onClick={() => api?.scrollPrev()}><ChevronLeft /></Button>
              <p aria-live="polite" aria-atomic="true" className="text-sm tabular-nums text-muted-foreground">{index + 1} / {stories.length}</p>
              <Button variant="outline" size="icon" title="Next article" aria-label="Next article" disabled={index === stories.length - 1} onClick={() => api?.scrollNext()}><ChevronRight /></Button>
            </div>
          </>
        )}
      </main>
      <BottomTabBar />
    </div>
  );
};

export default DailyCurrentAffairs;