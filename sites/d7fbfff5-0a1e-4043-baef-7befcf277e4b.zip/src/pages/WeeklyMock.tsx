import DailyQuiz from "./DailyQuiz";

const WeeklyMock = () => <DailyQuiz quizType="weekly_mock" />;

export default WeeklyMock;