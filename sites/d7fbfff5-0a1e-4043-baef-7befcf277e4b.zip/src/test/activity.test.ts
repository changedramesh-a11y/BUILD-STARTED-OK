import { describe, expect, it } from "vitest";
import { isActivityNote, isActivityTest } from "@/lib/activity";

describe("Personal activity", () => {
  it("shows attempted tests and excludes tests without the user's attempt", () => {
    const attempts = { math: { id: "my-attempt", score: 5 } };
    expect(isActivityTest("math", attempts)).toBe(true);
    expect(isActivityTest("unattempted", attempts)).toBe(false);
    expect(isActivityTest("toString", attempts)).toBe(false);
  });

  it("shows only the user's saved study notes", () => {
    expect(isActivityNote("saved-note", ["saved-note"])).toBe(true);
    expect(isActivityNote("other-note", ["saved-note"])).toBe(false);
  });
});