import { describe, expect, it, vi } from "vitest";
import { createExitBackController, EXIT_BACK_WINDOW_MS } from "@/hooks/use-exit-back";

describe("exit back controller", () => {
  it("warns and stays on the first back press", () => {
    const onExit = vi.fn();
    const onWarn = vi.fn();
    const c = createExitBackController(() => 1000, onExit, onWarn);
    expect(c.handleBack()).toBe(true);
    expect(onWarn).toHaveBeenCalledTimes(1);
    expect(onExit).not.toHaveBeenCalled();
  });

  it("exits on a second back press within the window", () => {
    let t = 1000;
    const onExit = vi.fn();
    const c = createExitBackController(() => t, onExit, vi.fn());
    c.handleBack();
    t = 1000 + EXIT_BACK_WINDOW_MS - 1;
    expect(c.handleBack()).toBe(false);
    expect(onExit).toHaveBeenCalledTimes(1);
  });

  it("warns again when the second press comes after the window", () => {
    let t = 1000;
    const onExit = vi.fn();
    const onWarn = vi.fn();
    const c = createExitBackController(() => t, onExit, onWarn);
    c.handleBack();
    t = 1000 + EXIT_BACK_WINDOW_MS + 1;
    expect(c.handleBack()).toBe(true);
    expect(onWarn).toHaveBeenCalledTimes(2);
    expect(onExit).not.toHaveBeenCalled();
  });
});
