import { describe, expect, it, vi, beforeEach } from "vitest";
import { loadHomeFeed, newestFirst, type FeedItem } from "@/lib/home-feed";

const { calls, records } = vi.hoisted(() => ({
  calls: [] as { table: string; filters: Record<string, unknown>; bounds: Record<string, string> }[],
  records: {} as Record<string, Record<string, unknown>[]>,
}));
vi.mock("@/integrations/supabase/client", () => ({ supabase: {
  from: (table: string) => {
    const call = { table, filters: {} as Record<string, unknown>, bounds: {} as Record<string, string> };
    calls.push(call);
    const query = {
      select: () => query,
      eq: (key: string, value: unknown) => { call.filters[key] = value; return query; },
      in: (key: string, values: unknown[]) => { call.filters[key] = values; return query; },
      gt: (key: string, value: string) => { call.bounds[key] = value; return query; },
      order: () => query,
      limit: () => Promise.resolve({ data: (records[table] || []).filter(row => Object.entries(call.filters).every(([key, value]) => Array.isArray(value) ? value.includes(row[key]) : row[key] === value) && Object.entries(call.bounds).every(([key, value]) => String(row[key]) > value)), error: null }),
    };
    return query;
  },
} }));
beforeEach(() => { calls.length = 0; Object.keys(records).forEach(key => delete records[key]); });

describe("Home recent uploads", () => {
  it("sorts mixed content newest upload first", () => {
    const items = [
      { id: "old", createdAt: "2026-11-01" },
      { id: "new", createdAt: "2026-11-14" },
      { id: "middle", createdAt: "2026-11-10" },
    ] as FeedItem[];
    expect(newestFirst(items).map(item => item.id)).toEqual(["new", "middle", "old"]);
  });
  it("includes all uploaded content types, excludes drafts and expired articles, and respects exam preference", async () => {
    records.quizzes = [
      { id: "weekly", title: "Weekly mock", type: "weekly_mock", is_published: true, exam_mode: "central", created_at: "2026-11-12" },
      { id: "daily", title: "Daily quiz", type: "daily_quiz", is_published: true, exam_mode: "central", created_at: "2026-11-11" },
      { id: "draft", is_published: false, exam_mode: "central" },
      { id: "jh", is_published: true, exam_mode: "jharkhand" },
    ];
    records.blog_posts = [{ id: "note", title: "Notes", is_published: true, exam_mode: "central", created_at: "2026-11-10" }];
    records.stories = [
      { id: "article", title: "Article", exam_mode: "central", expires_at: "2099-01-01", created_at: "2026-11-09" },
      { id: "expired", exam_mode: "central", expires_at: "2000-01-01" },
    ];
    records.previous_year_papers = [{ id: "paper", exam_name: "SSC CGL", category: "ssc", year: 2025, created_at: "2026-11-08" }];
    records.notices = [{ id: "notice", title: "Notice", created_at: "2026-11-07" }];
    records.community_posts = [{ id: "post", caption: "Community", exam_mode: "central", created_at: "2026-11-06" }];
    const feed = await loadHomeFeed("central");
    expect(feed.map(item => item.id)).toEqual(["weekly", "daily", "note", "article", "paper", "notice", "post"]);
    expect(feed.find(item => item.id === "article")?.path).toBe("/daily-current-affairs?article=article");
    expect(feed.find(item => item.id === "paper")?.path).toBe("/prev-papers/ssc/SSC%20CGL");
    expect(calls.find(call => call.table === "quizzes")?.filters).toEqual({ is_published: true, exam_mode: "central" });
  });
  it("uses the selected Jharkhand preference for exam-specific content", async () => {
    records.quizzes = [{ id: "jh", title: "Jharkhand quiz", is_published: true, exam_mode: "jharkhand", created_at: "2026-11-14" }, { id: "central", is_published: true, exam_mode: "central", created_at: "2026-11-14" }];
    expect((await loadHomeFeed("jharkhand")).map(item => item.id)).toEqual(["jh"]);
  });
  it("shows only JSSC papers and Jharkhand notes in Jharkhand mode", async () => {
    records.previous_year_papers = ["jssc", "ssc", "railway", "banking", "upsc", "bssc", "upssc"].map(category => ({ id: category, category, created_at: "2026-11-20" }));
    records.blog_posts = ["central", "jharkhand"].map(exam_mode => ({ id: `${exam_mode}-note`, exam_mode, is_published: true, created_at: "2026-11-20" }));
    expect((await loadHomeFeed("jharkhand")).map(item => item.id)).toEqual(["jharkhand-note", "jssc"]);
  });
  it("shows SSC, Railway, Banking, UPSC and other central papers, not state papers, in Central mode", async () => {
    records.previous_year_papers = ["ssc", "railway", "banking", "upsc", "other", "jssc", "bssc", "upssc"].map(category => ({ id: category, category, created_at: "2026-11-20" }));
    expect((await loadHomeFeed("central")).map(item => item.id)).toEqual(["ssc", "railway", "banking", "upsc", "other"]);
  });
});