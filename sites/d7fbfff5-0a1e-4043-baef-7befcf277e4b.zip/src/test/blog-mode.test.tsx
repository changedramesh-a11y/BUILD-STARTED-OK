import { act, cleanup, render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { afterEach, describe, expect, it, vi } from "vitest";
import Blog from "@/pages/Blog";

vi.mock("@/contexts/AuthContext", () => ({ useAuth: () => ({ user: { id: "student" }, role: "user" }) }));
vi.mock("@/components/SaveButton", () => ({ default: () => null }));
vi.mock("@/integrations/supabase/client", () => ({ supabase: {
  from: () => {
    const filters: Record<string, unknown> = {};
    const query = {
      select: () => query,
      eq: (key: string, value: unknown) => { filters[key] = value; return query; },
      order: () => query,
      abortSignal: async () => ({ data: [
        { id: "jh", title: "Jharkhand JSSC notes", exam_mode: "jharkhand", category: "GK", is_published: true, created_at: "2026-11-20" },
        { id: "ssc", title: "SSC Railway Banking UPSC notes", exam_mode: "central", category: "GK", is_published: true, created_at: "2026-11-20" },
        { id: "draft", title: "Unpublished note", exam_mode: "central", category: "GK", is_published: false },
      ].filter(row => Object.entries(filters).every(([key, value]) => row[key as keyof typeof row] === value)), error: null }),
    };
    return query;
  },
} }));
afterEach(cleanup);

describe("Study Notes examination mode", () => {
  it("follows Jharkhand then Central and back without mixing cached notes", async () => {
    localStorage.setItem("exam_mode", "jharkhand");
    render(<QueryClientProvider client={new QueryClient()}><MemoryRouter initialEntries={["/blog?category=GK"]}><Blog /></MemoryRouter></QueryClientProvider>);
    expect(await screen.findByText("Jharkhand JSSC notes")).toBeInTheDocument();
    expect(screen.queryByText("SSC Railway Banking UPSC notes")).not.toBeInTheDocument();
    act(() => {
      localStorage.setItem("exam_mode", "central");
      window.dispatchEvent(new StorageEvent("storage", { key: "exam_mode" }));
    });
    expect(await screen.findByText("SSC Railway Banking UPSC notes")).toBeInTheDocument();
    expect(screen.queryByText("Jharkhand JSSC notes")).not.toBeInTheDocument();
    expect(screen.queryByText("Unpublished note")).not.toBeInTheDocument();
    act(() => {
      localStorage.setItem("exam_mode", "jharkhand");
      window.dispatchEvent(new Event("exam-mode-changed"));
    });
    expect(await screen.findByText("Jharkhand JSSC notes")).toBeInTheDocument();
    expect(screen.queryByText("SSC Railway Banking UPSC notes")).not.toBeInTheDocument();
  });
});