import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import { afterEach, describe, expect, it, vi } from "vitest";
import Blog from "@/pages/Blog";
import DailyQuiz from "@/pages/DailyQuiz";
import WeeklyMock from "@/pages/WeeklyMock";
import DailyCurrentAffairs from "@/pages/DailyCurrentAffairs";
import { PrevPaperCategories } from "@/pages/PrevPapers";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

vi.mock("@/contexts/AuthContext", () => ({ useAuth: () => ({ user: null, role: "user" }) }));
vi.mock("@/integrations/supabase/client", () => {
  const query = {
    select: () => query,
    eq: () => query,
    gt: () => query,
    order: () => query,
    abortSignal: () => query,
    then: (resolve: (value: { data: never[]; error: null }) => unknown) =>
      Promise.resolve({ data: [], error: null }).then(resolve),
  };
  return { supabase: { from: () => query } };
});

afterEach(cleanup);

describe("Lower-menu section Back navigation", () => {
  it.each([
    ["Study Notes", "/blog", Blog],
    ["Weekly Mock", "/weekly-mock", WeeklyMock],
    ["Daily Quiz", "/daily-quiz", DailyQuiz],
    ["Current Affairs", "/daily-current-affairs", DailyCurrentAffairs],
    ["Previous Papers", "/prev-papers", PrevPaperCategories],
  ] as const)("returns from %s to Home, not My Exams", async (_name, path, Page) => {
    render(
      <QueryClientProvider client={new QueryClient()}><MemoryRouter initialEntries={[path]}>
        <Routes>
          <Route path={path} element={<Page />} />
          <Route path="/home" element={<h1>Home destination</h1>} />
          <Route path="/dashboard" element={<h1>My Exams destination</h1>} />
        </Routes>
      </MemoryRouter></QueryClientProvider>,
    );
    fireEvent.click(screen.getByRole("button", { name: "Back to Home" }));
    expect(await screen.findByRole("heading", { name: "Home destination" })).toBeInTheDocument();
    expect(screen.queryByRole("heading", { name: "My Exams destination" })).not.toBeInTheDocument();
  });
});