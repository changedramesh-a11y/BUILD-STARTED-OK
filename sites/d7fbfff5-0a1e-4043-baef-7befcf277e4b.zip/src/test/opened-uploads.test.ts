import { beforeEach, describe, expect, it } from "vitest";
import { act, renderHook, cleanup } from "@testing-library/react";
import { useOpenedUploads } from "@/hooks/use-opened-uploads";
import { unopenedUploads, parseOpenedUploads } from "@/lib/opened-uploads";
import type { FeedItem } from "@/lib/home-feed";

const item = (id: string, kind: FeedItem["kind"] = "test"): FeedItem => ({ id, kind, title: id, label: id, description: "", createdAt: "2026-11-21", path: `/quiz/${id}` });
beforeEach(() => { cleanup(); localStorage.clear(); });

describe("Recently Uploaded opened items", () => {
  for (const type of ["quiz", "mock", "daily_quiz", "weekly_mock"]) {
    it(`hides an opened ${type} without removing the source item`, () => {
      const source = [item(type), item("new")];
      const { result } = renderHook(() => useOpenedUploads(`student-${type}`));
      act(() => result.current.markOpened(source[0]));
      expect(unopenedUploads(source, result.current.opened).map(row => row.id)).toEqual(["new"]);
      expect(source.map(row => row.id)).toEqual([type, "new"]);
    });
  }
  it("hides an opened blog after remount and keeps it separate from another person's list", () => {
    const note = item("blog", "note");
    const first = renderHook(() => useOpenedUploads("student-blog"));
    act(() => first.result.current.markOpened(note));
    first.unmount();
    const { result, rerender } = renderHook(({ user }) => useOpenedUploads(user), { initialProps: { user: "student-blog" } });
    expect(unopenedUploads([note], result.current.opened)).toEqual([]);
    rerender({ user: "another-student" });
    expect(unopenedUploads([note], result.current.opened)).toEqual([note]);
  });
  it("hides an opened previous-year paper after remount without changing its source list", () => {
    const paper = item("previous-year", "paper");
    const source = [paper, item("unopened-paper", "paper")];
    const first = renderHook(() => useOpenedUploads("paper-student"));
    act(() => first.result.current.markOpened(paper));
    first.unmount();
    const { result } = renderHook(() => useOpenedUploads("paper-student"));
    expect(unopenedUploads(source, result.current.opened).map(row => row.id)).toEqual(["unopened-paper"]);
    expect(source.map(row => row.id)).toEqual(["previous-year", "unopened-paper"]);
  });
  it("does not hide affairs, notices or community posts", () => {
    const source = (["affairs", "notice", "community"] as const).map(kind => item(kind, kind));
    const { result } = renderHook(() => useOpenedUploads("student-other-content"));
    act(() => source.forEach(row => result.current.markOpened(row)));
    expect(unopenedUploads(source, result.current.opened)).toEqual(source);
  });
  it("ignores damaged stored data", () => {
    expect(parseOpenedUploads("broken json")).toEqual([]);
    expect(parseOpenedUploads('["test:quiz",123]')).toEqual(["test:quiz"]);
  });
});