import { describe, expect, it } from "vitest";
import { prepareMockSections, supportsMockSections } from "@/lib/mock-sections";

describe("mock section settings", () => {
  it("supports both mock publication types only", () => {
    expect(supportsMockSections("mock")).toBe(true);
    expect(supportsMockSections("weekly_mock")).toBe(true);
    expect(supportsMockSections("daily_quiz")).toBe(false);
    expect(supportsMockSections("quiz")).toBe(false);
  });
  it("stores no sections when switched off", () => {
    expect(prepareMockSections("mock", false, [{ name: "Math", duration_minutes: 20 }])).toEqual([]);
  });
  it("allows up to five sections but rejects six or zero", () => {
    const sections = Array.from({ length: 5 }, (_, i) => ({ name: `Section ${i + 1}`, duration_minutes: 10 }));
    expect(prepareMockSections("weekly_mock", true, sections)).toHaveLength(5);
    expect(() => prepareMockSections("mock", true, [...sections, sections[0]])).toThrow();
    expect(() => prepareMockSections("mock", true, [])).toThrow();
  });
  it("preserves each manually entered name and time in order", () => {
    expect(prepareMockSections("weekly_mock", true, [
      { name: " Mathematics ", duration_minutes: 20 },
      { name: "Reasoning", duration_minutes: 15 },
    ])).toEqual([{ name: "Mathematics", duration_minutes: 20 }, { name: "Reasoning", duration_minutes: 15 }]);
  });
  it("requires a name for every section", () => {
    expect(() => prepareMockSections("mock", true, [{ name: " ", duration_minutes: 10 }])).toThrow();
  });
  it("requires a positive whole-minute time for every section", () => {
    for (const duration_minutes of [0, -1, 1.5, NaN]) {
      expect(() => prepareMockSections("mock", true, [{ name: "Math", duration_minutes }])).toThrow();
    }
  });
});
import { splitQuestionsIntoSections, paletteStatus } from "@/lib/mock-sections";
describe("mock attempt palette", () => {
  it("splits 10 questions over 4 sections as 3,3,2,2", () => {
    const r = splitQuestionsIntoSections(10, [{ name: "Reasoning" }, { name: "Maths" }, { name: "English" }, { name: "GK" }]);
    expect(r.map((s) => s.end - s.start)).toEqual([3, 3, 2, 2]);
    expect(r[3]).toEqual({ name: "GK", start: 8, end: 10 });
  });
  it("classifies question status", () => {
    expect(paletteStatus(true, true, false)).toBe("answered");
    expect(paletteStatus(false, true, false)).toBe("not_answered");
    expect(paletteStatus(false, false, false)).toBe("not_visited");
    expect(paletteStatus(false, true, true)).toBe("marked");
    expect(paletteStatus(true, true, true)).toBe("answered_marked");
  });
});
