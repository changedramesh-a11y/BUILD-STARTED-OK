import { QueryClient } from "@tanstack/react-query";
import { describe, expect, it, vi } from "vitest";
import { queryDefaults } from "@/lib/query-policy";

describe("mobile page cache", () => {
  it("reuses a fresh page request on repeat visits", async () => {
    const client = new QueryClient({ defaultOptions: { queries: queryDefaults } });
    const queryFn = vi.fn(async () => ["published-mock"]);
    const options = { queryKey: ["test-list", "student-a"], queryFn };
    await client.fetchQuery(options);
    expect(await client.fetchQuery(options)).toEqual(["published-mock"]);
    expect(queryFn).toHaveBeenCalledTimes(1);
    client.clear();
  });
  it("fetches updated attempts after invalidation", async () => {
    const client = new QueryClient({ defaultOptions: { queries: queryDefaults } });
    const queryFn = vi.fn().mockResolvedValueOnce([]).mockResolvedValueOnce(["attempt-1"]);
    const options = { queryKey: ["test-attempts", "student-a"], queryFn };
    await client.fetchQuery(options);
    await client.invalidateQueries({ queryKey: ["test-attempts"] });
    expect(await client.fetchQuery(options)).toEqual(["attempt-1"]);
    expect(queryFn).toHaveBeenCalledTimes(2);
    client.clear();
  });
  it("does not reuse another student's cached data", async () => {
    const client = new QueryClient({ defaultOptions: { queries: queryDefaults } });
    await client.fetchQuery({ queryKey: ["home-feed", "student-a"], queryFn: async () => ["private-a"] });
    const data = await client.fetchQuery({ queryKey: ["home-feed", "student-b"], queryFn: async () => ["private-b"] });
    expect(data).toEqual(["private-b"]);
    client.clear();
    expect(client.getQueryData(["home-feed", "student-a"])).toBeUndefined();
  });
});