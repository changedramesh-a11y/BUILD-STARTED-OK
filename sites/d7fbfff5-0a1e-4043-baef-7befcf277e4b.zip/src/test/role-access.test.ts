import { describe, expect, it } from "vitest";

const sessionJson = process.env.LOVABLE_BROWSER_SUPABASE_SESSION_JSON;
const session = sessionJson ? JSON.parse(sessionJson) : null;
const url = import.meta.env.VITE_SUPABASE_URL;
const apiKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

describe.skipIf(!session)("authenticated role permissions", () => {
  const checkRole = (userId: string, token: string) => fetch(`${url}/rest/v1/rpc/has_role`, {
    method: "POST",
    headers: { apikey: apiKey, Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({ _user_id: userId, _role: "admin" }),
  });

  it("lets the signed-in owner read their admin role", async () => {
    const response = await checkRole(session.user.id, session.access_token);
    expect(response.status).toBe(200);
    expect(await response.json()).toBe(true);
  });

  it("does not expose another user's role", async () => {
    const response = await checkRole("00000000-0000-0000-0000-000000000001", session.access_token);
    expect(response.status).toBe(200);
    expect(await response.json()).toBe(false);
  });

  it("does not allow anonymous role checks", async () => {
    const response = await checkRole(session.user.id, apiKey);
    expect(response.status).toBe(401);
  });
});