import { describe, it, expect } from "vitest";
import { isAndroidWebView } from "@/components/PdfReader";
describe("isAndroidWebView", () => {
  it("detects APK WebView", () => expect(isAndroidWebView("Mozilla/5.0 (Linux; Android 12; SM-A125F Build/SP1A; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/119.0 Mobile Safari/537.36")).toBe(true));
  it("keeps in-app reader in Chrome on Android", () => expect(isAndroidWebView("Mozilla/5.0 (Linux; Android 12; SM-A125F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0 Mobile Safari/537.36")).toBe(false));
  it("keeps in-app reader on desktop", () => expect(isAndroidWebView("Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/119.0 Safari/537.36")).toBe(false));
});
