import { describe, expect, it } from "vitest";

const rawSession = process.env.LOVABLE_BROWSER_SUPABASE_SESSION_JSON;
const session = rawSession ? JSON.parse(rawSession) : null;
const url = import.meta.env.VITE_SUPABASE_URL;
const apiKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

describe.skipIf(!session)("Personal bookmark permissions", () => {
  for (const table of ["saved_quizzes", "saved_papers"]) {
    it(`${table} allows personal reads but hides other users' bookmarks`, async () => {
      const response = await fetch(`${url}/rest/v1/${table}?select=id&user_id=neq.${session.user.id}`, {
        headers: { apikey: apiKey, Authorization: `Bearer ${session.access_token}` },
      });
      expect(response.status).toBe(200);
      expect(await response.json()).toEqual([]);
    });
    it(`${table} never exposes bookmarks to signed-out visitors`, async () => {
      const response = await fetch(`${url}/rest/v1/${table}?select=id`, {
        headers: { apikey: apiKey, Authorization: `Bearer ${apiKey}` },
      });
      expect([200, 401]).toContain(response.status);
      if (response.status === 200) expect(await response.json()).toEqual([]);
    });
  }
});