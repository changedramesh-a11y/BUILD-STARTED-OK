import { describe, expect, it } from "vitest";
import { validatePaper } from "@/lib/previous-year-paper";

const pdf = { name: "paper.pdf", type: "application/pdf", size: 100 };
describe("previous year paper upload", () => {
  it("requires an exam name", () => {
    expect(validatePaper(" ", "2025", pdf)).not.toBeNull();
    expect(validatePaper("JSSC CGL", "2025", pdf)).toBeNull();
  });
  it("requires a year", () => {
    expect(validatePaper("JSSC CGL", "", pdf)).not.toBeNull();
  });
  it("accepts PDFs and rejects other files", () => {
    expect(validatePaper("JSSC CGL", "2025", pdf)).toBeNull();
    expect(validatePaper("JSSC CGL", "2025", { ...pdf, name: "photo.jpg", type: "image/jpeg" })).not.toBeNull();
    expect(validatePaper("JSSC CGL", "2025", null)).not.toBeNull();
  });
});