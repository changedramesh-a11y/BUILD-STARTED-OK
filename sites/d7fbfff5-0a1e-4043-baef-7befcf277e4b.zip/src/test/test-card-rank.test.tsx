import { render, screen, cleanup } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { afterEach, expect, it, vi } from "vitest";
import TestRankBadge from "@/components/TestRankBadge";

vi.mock("@/contexts/AuthContext", () => ({ useAuth: () => ({ user: { id: "me" } }) }));
vi.mock("@/integrations/supabase/client", () => ({ supabase: { from: () => {
  const query = {
    select: () => query, eq: () => query, order: () => query,
    abortSignal: async () => ({ error: null, data: [
      { user_id: "first", percentage: 100, created_at: "2026-11-20" },
      { user_id: "first", percentage: 90, created_at: "2026-11-21" },
      { user_id: "me", percentage: 50, created_at: "2026-11-20" },
      { user_id: "last", percentage: 20, created_at: "2026-11-21" },
    ] }),
  };
  return query;
} } }));
afterEach(cleanup);
it("counts each participant once using the existing best-attempt ordering", async () => {
  render(<QueryClientProvider client={new QueryClient()}><TestRankBadge quizId="mock" /></QueryClientProvider>);
  expect(await screen.findByText("Rank #2")).toBeInTheDocument();
});