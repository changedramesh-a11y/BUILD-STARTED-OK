import { render, screen, cleanup } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import WeeklyMock from "@/pages/WeeklyMock";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

const { query, filters } = vi.hoisted(() => ({
  query: { from: vi.fn(), select: vi.fn(), eq: vi.fn(), order: vi.fn(), abortSignal: vi.fn() },
  filters: {} as Record<string, unknown>,
}));

vi.mock("@/integrations/supabase/client", () => ({ supabase: query }));
vi.mock("@/contexts/AuthContext", () => ({ useAuth: () => ({ user: null, role: "user" }) }));
vi.mock("@/components/SaveButton", () => ({ default: () => null }));

const records = [
  { id: "old", title: "Previously uploaded weekly mock", type: "weekly_mock", exam_mode: "central", is_published: true, created_at: "2025-01-01" },
  { id: "new", title: "Latest weekly mock", type: "weekly_mock", exam_mode: "central", is_published: true, created_at: "2026-11-12" },
  { id: "draft", title: "Unpublished mock", type: "weekly_mock", exam_mode: "central", is_published: false },
  { id: "daily", title: "Daily test", type: "daily_quiz", exam_mode: "central", is_published: true },
  { id: "jh", title: "Jharkhand weekly mock", type: "weekly_mock", exam_mode: "jharkhand", is_published: true },
];

beforeEach(() => {
  localStorage.setItem("exam_mode", "central");
  Object.keys(filters).forEach(key => delete filters[key]);
  query.from.mockReturnValue(query);
  query.select.mockReturnValue(query);
  query.eq.mockImplementation((key, value) => { filters[key] = value; return query; });
  query.order.mockReturnValue(query);
  query.abortSignal.mockImplementation(() => Promise.resolve({
    data: records.filter(record => Object.entries(filters).every(([key, value]) => record[key as keyof typeof record] === value)),
    error: null,
  }));
});
afterEach(cleanup);

describe("Weekly Mock publication listing", () => {
  it("includes all historical published weekly mocks without a date cutoff", async () => {
    render(<QueryClientProvider client={new QueryClient()}><MemoryRouter><WeeklyMock /></MemoryRouter></QueryClientProvider>);
    expect(await screen.findByText("Previously uploaded weekly mock")).toBeInTheDocument();
    expect(screen.getByText("Latest weekly mock")).toBeInTheDocument();
    expect(filters).toEqual({ is_published: true, type: "weekly_mock", exam_mode: "central" });
    expect(screen.queryByText("Daily test")).not.toBeInTheDocument();
    expect(screen.queryByText("Unpublished mock")).not.toBeInTheDocument();
  });

  it("shows weekly mocks for the saved Jharkhand exam preference", async () => {
    localStorage.setItem("exam_mode", "jharkhand");
    render(<QueryClientProvider client={new QueryClient()}><MemoryRouter><WeeklyMock /></MemoryRouter></QueryClientProvider>);
    expect(await screen.findByText("Jharkhand weekly mock")).toBeInTheDocument();
    expect(screen.queryByText("Latest weekly mock")).not.toBeInTheDocument();
  });
});