import { describe, expect, it } from "vitest";
import { pinchZoom, zoomScrollOffset } from "@/lib/pdf-gestures";

describe("PDF touch zoom", () => {
  it("zooms in and out with the distance between two fingers", () => {
    expect(pinchZoom(1, 100, 200)).toBe(2);
    expect(pinchZoom(2, 200, 100)).toBe(1);
  });
  it("keeps the content under the fingers anchored", () => {
    expect(zoomScrollOffset(300, 100, 1, 2)).toBe(700);
    expect(zoomScrollOffset(700, 100, 2, 1)).toBe(300);
  });
});