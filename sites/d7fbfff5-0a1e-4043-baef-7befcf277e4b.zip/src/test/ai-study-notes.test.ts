import { describe, expect, it } from "vitest";
import { parseStudyNotes, readNotesStream } from "@/lib/ai-study-notes";

describe("AI notes drafts", () => {
  it("returns editable title, summary and notes", () => {
    expect(parseStudyNotes("Fundamental Rights\nConstitution revision\n\nKey articles\n• Article 14: Equality")).toEqual({ title: "Fundamental Rights", excerpt: "Constitution revision", content: "Key articles\n• Article 14: Equality" });
  });
  it("does not accept incomplete notes", () => {
    expect(() => parseStudyNotes("Title only")).toThrow("incomplete");
  });
  it("does not accept interrupted output as a publishable draft", async () => {
    const response = new Response('data: {"text":"Title\\nSummary\\n\\nNotes"}\n\n');
    await expect(readNotesStream(response, () => {})).rejects.toThrow("interrupted");
  });
  it("preserves a denied service response", async () => {
    await expect(readNotesStream(new Response(JSON.stringify({ error: "AI access disabled" }), { status: 403 }), () => {})).rejects.toThrow("AI access disabled");
  });
});

describe("AI notes access", () => {
  it("rejects unauthenticated generation before calling AI", async () => {
    const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-study-notes`, {
      method: "POST",
      headers: { apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY, "Content-Type": "application/json" },
      body: JSON.stringify({ topic: "Fundamental Rights", examMode: "central", category: "GK", language: "English" }),
    });
    expect(response.status).toBe(401);
  });
});