import { describe, expect, it } from "vitest";
import { matchesSavedTest, SAVE_TABLES } from "@/lib/saved-content";

describe("Personal saved collections", () => {
  it("puts saved daily quizzes and ordinary quizzes only in daily quizzes", () => {
    expect(matchesSavedTest("daily_quiz", "daily")).toBe(true);
    expect(matchesSavedTest("quiz", "daily")).toBe(true);
    expect(matchesSavedTest("weekly_mock", "daily")).toBe(false);
  });
  it("puts saved weekly mocks and mock tests only in weekly mocks", () => {
    expect(matchesSavedTest("weekly_mock", "weekly")).toBe(true);
    expect(matchesSavedTest("mock", "weekly")).toBe(true);
    expect(matchesSavedTest("daily_quiz", "weekly")).toBe(false);
  });
  it("keeps saved papers and existing saved study notes independent", () => {
    expect(SAVE_TABLES.paper).toEqual({ table: "saved_papers", column: "paper_id" });
    expect(SAVE_TABLES.note).toEqual({ table: "saved_blogs", column: "blog_post_id" });
    expect(matchesSavedTest("quiz", "papers")).toBe(false);
    expect(matchesSavedTest("mock", "notes")).toBe(false);
  });
});