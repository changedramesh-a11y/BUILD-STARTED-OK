import { describe, expect, it } from "vitest";
import { extractMindMap, requireMindMap, withMindMapImage } from "../../supabase/functions/_shared/study-note-format";
import { readNotesStream } from "@/lib/ai-study-notes";
import { mindMapImage } from "@/lib/note-mind-map";

const map = { topic: "National Parks", branches: [
  { label: "Uttarakhand", facts: ["Corbett — 1936"] },
  { label: "Assam", facts: ["Kaziranga — 1974"] },
  { label: "Gujarat", facts: ["Gir — 1975"] },
] };
const table = "| Year | Park | State |\n| --- | --- | --- |\n| 1936 | Corbett | Uttarakhand |";
const content = `${table}\n\n\`\`\`mindmap\n${JSON.stringify(map)}\n\`\`\``;
describe("AI article format", () => {
  it.each([1, 3, 12, 50])("preserves all %i table rows instead of imposing three", (count) => {
    const rows = Array.from({ length: count }, (_, index) => `| ${index + 1} | Park ${index + 1} | State ${index + 1} |`);
    const fullTable = `| Year | Park | State |\n| --- | --- | --- |\n${rows.join("\n")}`;
    const article = `${fullTable}\n\n\`\`\`mindmap\n${JSON.stringify(map)}\n\`\`\``;
    expect(extractMindMap(article).body.split("\n").slice(2)).toEqual(rows);
  });
  it("persists an uploaded image at the end without losing the table or outline", () => {
    const image = "data:image/png;base64,iVBORw0KGgo=";
    const article = withMindMapImage(content, image);
    expect(extractMindMap(article)).toEqual({ body: table, map, image });
    expect(() => requireMindMap(withMindMapImage(table, image))).not.toThrow();
    expect(extractMindMap(withMindMapImage(article, "data:image/jpeg;base64,YWJj" )).image).toBe("data:image/jpeg;base64,YWJj");
  });
  it("rejects non-image uploads and oversized image content", () => {
    expect(() => withMindMapImage(table, "data:text/html;base64,YWJj")).toThrow();
    expect(() => withMindMapImage(table, "data:image/png;base64," + "A".repeat(4_000_000))).toThrow();
  });
  it("retains spreadsheet-style facts alongside the map", () => {
    expect(extractMindMap(content).body).toBe(table);
    expect(extractMindMap(content).map).toEqual(map);
  });
  it("requires a valid mind map at the end of every AI article", () => {
    expect(() => requireMindMap(table)).toThrow("Every AI article");
    expect(() => requireMindMap(content + "\nMore notes")).toThrow();
    expect(() => requireMindMap(content)).not.toThrow();
  });
  it("rejects an incomplete or malformed map", () => {
    expect(() => requireMindMap('```mindmap\n{"topic":"Parks","branches":[]}\n```')).toThrow();
  });
  it("renders the article's own topic and facts into an image", () => {
    const svg = decodeURIComponent(mindMapImage(map, { background: "background", text: "text", accent: "accent", border: "border", surface: "surface" }).split(",")[1]);
    expect(svg).toContain("<svg");
    expect(svg).toContain("National Parks");
    expect(svg).toContain("Corbett — 1936");
    expect(svg).toContain("Kaziranga — 1974");
  });
  it("does not accept a completed AI stream without its mandatory map", async () => {
    const response = new Response(`data: ${JSON.stringify({ text: "Title\nSummary\n\n" + table })}\n\ndata: {"done":true}\n\n`);
    await expect(readNotesStream(response, () => {})).rejects.toThrow("mind map");
  });
  it("accepts a complete table article with a final map", async () => {
    const response = new Response(`data: ${JSON.stringify({ text: "Parks\nRevision\n\n" + content })}\n\ndata: {"done":true}\n\n`);
    expect((await readNotesStream(response, () => {})).content).toBe(content);
  });
});