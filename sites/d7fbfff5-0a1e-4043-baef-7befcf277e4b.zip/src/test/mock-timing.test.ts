import { describe, expect, it } from "vitest";
import { mockSchedule, timingAt, canVisitQuestion, canDeleteMock } from "@/lib/mock-timing";

const sections = [{ name: "Reasoning", duration_minutes: 2 }, { name: "Math", duration_minutes: 3 }];
const schedule = mockSchedule("weekly_mock", 4, sections);
describe("sequential mock timing", () => {
  it("uses the respective section minutes", () => {
    expect(timingAt(schedule, 1000, 1000).remaining).toBe(120);
    expect(timingAt(schedule, 1000, 121000).remaining).toBe(180);
  });
  it("automatically changes sections exactly at expiry", () => {
    expect(timingAt(schedule, 1000, 120999).index).toBe(0);
    expect(timingAt(schedule, 1000, 121000).section?.name).toBe("Math");
  });
  it("does not grant extra time after refresh or delayed ticks", () => {
    expect(timingAt(schedule, 1000, 181000).remaining).toBe(120);
    expect(timingAt(schedule, 1000, 401000).finished).toBe(true);
  });
  it("finishes automatically when the last section expires", () => {
    expect(timingAt(schedule, 1000, 301000)).toMatchObject({ remaining: 0, finished: true });
  });
  it("blocks future and expired sections while allowing the current section", () => {
    expect(canVisitQuestion(2, schedule[0])).toBe(false);
    expect(canVisitQuestion(1, schedule[1])).toBe(false);
    expect(canVisitQuestion(3, schedule[1])).toBe(true);
    expect(canVisitQuestion(0, undefined)).toBe(false);
  });
  it("retains overall timing when sections are off or the test is not a mock", () => {
    expect(mockSchedule("mock", 4, [])).toEqual([]);
    expect(mockSchedule("daily_quiz", 4, sections)).toEqual([]);
  });
  it("allows only admins to use mock deletion", () => {
    expect(canDeleteMock("admin", "mock")).toBe(true);
    expect(canDeleteMock("admin", "weekly_mock")).toBe(true);
    expect(canDeleteMock("moderator", "mock")).toBe(false);
    expect(canDeleteMock("user", "weekly_mock")).toBe(false);
  });
});