import { useEffect, useState, useRef } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { X, Trash2, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import type { Story } from "./StoryBar";

interface Props {
  stories: Story[];
  startIndex: number;
  onClose: () => void;
  onViewed: (id: string) => void;
  canManage: boolean;
  onDeleted: (id: string) => void;
}

const DURATION_MS = 6000;

const StoryViewer = ({ stories, startIndex, onClose, onViewed, canManage, onDeleted }: Props) => {
  const { user, role } = useAuth();
  const [index, setIndex] = useState(startIndex);
  const [progress, setProgress] = useState(0);
  const rafRef = useRef<number>();
  const startTs = useRef<number>(0);
  const pausedRef = useRef(false);

  const story = stories[index];

  useEffect(() => {
    if (!story) return;
    onViewed(story.id);
    setProgress(0);
    startTs.current = performance.now();

    const tick = (now: number) => {
      if (pausedRef.current) {
        startTs.current = now - (progress / 100) * DURATION_MS;
      }
      const elapsed = now - startTs.current;
      const p = Math.min(100, (elapsed / DURATION_MS) * 100);
      setProgress(p);
      if (p >= 100) {
        if (index < stories.length - 1) setIndex(index + 1);
        else onClose();
        return;
      }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [index, story?.id]);

  // Hardware/browser back closes the viewer instead of exiting the app
  useEffect(() => {
    window.history.pushState({ storyViewer: true }, "");
    const onPop = () => onClose();
    window.addEventListener("popstate", onPop);
    return () => {
      window.removeEventListener("popstate", onPop);
      // If viewer closed via UI (not back btn), clean up the pushed entry
      if (window.history.state?.storyViewer) {
        window.history.back();
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!story) return null;

  const goPrev = () => index > 0 && setIndex(index - 1);
  const goNext = () => (index < stories.length - 1 ? setIndex(index + 1) : onClose());

  const canDelete = canManage || (user && user.id === story.author_id);

  const handleDelete = async () => {
    if (!confirm("Delete this story?")) return;
    const { error } = await supabase.from("stories").delete().eq("id", story.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Story deleted");
    onDeleted(story.id);
    if (stories.length <= 1) onClose();
    else if (index === stories.length - 1) setIndex(index - 1);
  };

  return (
    <div className="fixed inset-0 z-[60] bg-black/95 flex items-center justify-center">
      <div className="relative w-full max-w-md h-full md:h-[90vh] md:rounded-xl overflow-hidden bg-home-header flex flex-col">
        {/* Progress bars */}
        <div className="absolute top-0 left-0 right-0 z-20 flex gap-1 p-2">
          {stories.map((_, i) => (
            <div key={i} className="flex-1 h-0.5 bg-white/30 rounded-full overflow-hidden">
              <div
                className="h-full bg-white transition-[width] duration-100"
                style={{ width: i < index ? "100%" : i === index ? `${progress}%` : "0%" }}
              />
            </div>
          ))}
        </div>

        {/* Header */}
        <div className="absolute top-4 left-0 right-0 z-20 flex items-center justify-between px-3 pt-4">
          <div className="text-xs text-white/80 font-medium">
            {new Date(story.created_at).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" })}
          </div>
          <div className="flex items-center gap-1">
            {canDelete && (
              <Button size="icon" variant="ghost" className="h-8 w-8 text-white hover:bg-white/10" onClick={handleDelete}>
                <Trash2 className="h-4 w-4" />
              </Button>
            )}
            <Button size="icon" variant="ghost" className="h-8 w-8 text-white hover:bg-white/10" onClick={onClose}>
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Tap zones */}
        <button
          aria-label="previous"
          className="absolute left-0 top-0 bottom-0 w-1/3 z-10"
          onClick={goPrev}
          onMouseDown={() => (pausedRef.current = true)}
          onMouseUp={() => (pausedRef.current = false)}
          onTouchStart={() => (pausedRef.current = true)}
          onTouchEnd={() => (pausedRef.current = false)}
        />
        <button
          aria-label="next"
          className="absolute right-0 top-0 bottom-0 w-1/3 z-10"
          onClick={goNext}
          onMouseDown={() => (pausedRef.current = true)}
          onMouseUp={() => (pausedRef.current = false)}
          onTouchStart={() => (pausedRef.current = true)}
          onTouchEnd={() => (pausedRef.current = false)}
        />

        {/* Content */}
        <div className="flex-1 flex flex-col pt-16 pb-6 px-6 overflow-y-auto">
          {story.image_url && (
            <img
              src={story.image_url}
              alt={story.title}
              className="w-full max-h-[40vh] object-cover rounded-lg mb-4"
            />
          )}
          <h2 className="text-xl font-bold font-heading text-white mb-3 leading-snug">{story.title}</h2>
          <p className="text-sm text-white/90 whitespace-pre-line leading-relaxed">{story.content}</p>
        </div>

        {/* Desktop nav arrows */}
        <button
          className="hidden md:flex absolute left-2 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-white/10 hover:bg-white/20 text-white items-center justify-center z-30"
          onClick={goPrev}
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <button
          className="hidden md:flex absolute right-2 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-white/10 hover:bg-white/20 text-white items-center justify-center z-30"
          onClick={goNext}
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
};

export default StoryViewer;
