import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Sparkles, Upload, Loader2, ImagePlus, X } from "lucide-react";
import { optimizeImage } from "@/lib/optimize-image";
import { toast } from "sonner";

interface Props {
  examMode: "central" | "jharkhand";
  onClose: () => void;
  onCreated: () => void;
}

const StoryUploader = ({ examMode, onClose, onCreated }: Props) => {
  const { user } = useAuth();
  const [mode, setMode] = useState<"manual" | "ai">("manual");
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [topic, setTopic] = useState("");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => () => { if (imagePreview) URL.revokeObjectURL(imagePreview); }, [imagePreview]);

  const handleImage = (f: File | null) => {
    setImageFile(f);
    if (imagePreview) URL.revokeObjectURL(imagePreview);
    setImagePreview(f ? URL.createObjectURL(f) : null);
  };

  const generateAI = async () => {
    setGenerating(true);
    try {
      const { data, error } = await supabase.functions.invoke("generate-news-story", {
        body: { topic, examMode },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      setTitle(data.title || "");
      setContent(data.content || "");
      setMode("manual");
      toast.success("AI draft ready — review and publish");
    } catch (e: any) {
      toast.error(e.message || "AI generation failed");
    } finally {
      setGenerating(false);
    }
  };

  const handlePublish = async () => {
    if (!user) return;
    if (!title.trim() || !content.trim()) {
      toast.error("Title and content required");
      return;
    }
    setSaving(true);
    try {
      let imageUrl: string | null = null;
      if (imageFile && user) {
        const optimized = await optimizeImage(imageFile);
        const path = `${user.id}/${Date.now()}-${optimized.name.replace(/[^a-z0-9.\-_]/gi, "_")}`;
        const { error: upErr } = await supabase.storage.from("stories").upload(path, optimized);
        if (upErr) throw upErr;
        const { data: pub } = supabase.storage.from("stories").getPublicUrl(path);
        imageUrl = pub.publicUrl;
      }

      const { error } = await supabase.from("stories").insert({
        author_id: user.id,
        title: title.trim(),
        content: content.trim(),
        image_url: imageUrl,
        exam_mode: examMode,
      });
      if (error) throw error;

      toast.success("Story posted! Visible for 24 hours.");
      onCreated();
    } catch (e: any) {
      toast.error(e.message || "Failed to publish");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add Daily News Story</DialogTitle>
        </DialogHeader>

        <Tabs value={mode} onValueChange={(v) => setMode(v as any)}>
          <TabsList className="grid grid-cols-2 w-full">
            <TabsTrigger value="manual" className="gap-1.5"><Upload className="h-3.5 w-3.5" /> Manual</TabsTrigger>
            <TabsTrigger value="ai" className="gap-1.5"><Sparkles className="h-3.5 w-3.5" /> AI Draft</TabsTrigger>
          </TabsList>

          <TabsContent value="ai" className="space-y-3 mt-4">
            <p className="text-xs text-muted-foreground">
              Describe the news topic. AI will draft a short story for {examMode === "jharkhand" ? "Jharkhand" : "Central"} exam aspirants.
            </p>
            <Textarea
              placeholder="e.g. RBI repo rate decision today, ISRO new launch, recent Padma awards..."
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              rows={3}
            />
            <Button onClick={generateAI} disabled={generating} className="w-full gap-2">
              {generating ? <><Loader2 className="h-4 w-4 animate-spin" /> Generating...</> : <><Sparkles className="h-4 w-4" /> Generate Draft</>}
            </Button>
          </TabsContent>

          <TabsContent value="manual" className="space-y-3 mt-4">
            <Input
              placeholder="Headline (under 80 chars)"
              value={title}
              maxLength={120}
              onChange={(e) => setTitle(e.target.value)}
            />
            <Textarea
              placeholder="Story content (bullet points work great — start lines with •)"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={8}
              maxLength={1500}
            />

            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Cover image (optional)</label>
              {imagePreview ? (
                <div className="relative">
                  <img src={imagePreview} alt="preview" className="w-full h-40 object-cover rounded-md" />
                  <button
                    onClick={() => handleImage(null)}
                    className="absolute top-2 right-2 h-7 w-7 rounded-full bg-black/60 text-white flex items-center justify-center"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ) : (
                <label className="flex items-center justify-center gap-2 h-24 border-2 border-dashed border-border rounded-md cursor-pointer hover:border-primary text-sm text-muted-foreground">
                  <ImagePlus className="h-4 w-4" />
                  <span>Tap to add image</span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleImage(e.target.files?.[0] || null)}
                  />
                </label>
              )}
            </div>

            <Button onClick={handlePublish} disabled={saving} className="w-full gap-2" size="lg">
              {saving ? <><Loader2 className="h-4 w-4 animate-spin" /> Publishing...</> : "Publish Story"}
            </Button>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};

export default StoryUploader;
