import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Megaphone, Trash2 } from "lucide-react";
import { toast } from "sonner";

interface Notice { id: string; title: string; content: string; created_at: string }

const NoticeBoard = ({ refreshTrigger }: { refreshTrigger?: number }) => {
  const { role } = useAuth();
  const [notices, setNotices] = useState<Notice[]>([]);
  const isAdmin = role === "admin";

  useEffect(() => {
    supabase.from("notices").select("id, title, content, created_at").order("created_at", { ascending: false }).limit(20)
      .then(({ data }) => setNotices((data as Notice[]) || []));
  }, [refreshTrigger]);

  const remove = async (id: string) => {
    if (!confirm("Delete this notice?")) return;
    const { error } = await supabase.from("notices").delete().eq("id", id);
    if (error) return toast.error(error.message);
    setNotices((n) => n.filter((x) => x.id !== id));
  };

  return (
    <section className="mb-5 rounded-xl border border-border bg-card card-shadow">
      <h2 className="flex items-center gap-2 px-4 py-3 border-b border-border text-sm font-bold font-heading text-foreground">
        <Megaphone className="h-4 w-4 text-primary" /> Notice Board
      </h2>
      {notices.length === 0 ? (
        <p className="px-4 py-4 text-xs text-muted-foreground">No notices yet.</p>
      ) : (
        <ul className="max-h-64 overflow-y-auto divide-y divide-border">
          {notices.map((n) => (
            <li key={n.id} className="px-4 py-3 flex gap-2">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-foreground">{n.title}</p>
                {n.content && <p className="text-xs text-muted-foreground whitespace-pre-line mt-0.5">{n.content}</p>}
                <p className="text-[10px] text-muted-foreground mt-1">{new Date(n.created_at).toLocaleDateString()}</p>
              </div>
              {isAdmin && (
                <button aria-label="Delete notice" onClick={() => remove(n.id)} className="text-destructive self-start p-1">
                  <Trash2 className="h-4 w-4" />
                </button>
              )}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
};

export default NoticeBoard;
