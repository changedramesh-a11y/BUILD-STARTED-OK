import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { MessageCircle, Trash2, Send } from "lucide-react";

interface CommentRow {
  id: string;
  user_id: string;
  content: string;
  created_at: string;
}

interface ProfileLite {
  user_id: string;
  display_name: string | null;
  avatar_url: string | null;
}

const BlogCommentSection = ({ blogPostId }: { blogPostId: string }) => {
  const { user } = useAuth();
  const [comments, setComments] = useState<CommentRow[]>([]);
  const [profiles, setProfiles] = useState<Record<string, ProfileLite>>({});
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(true);
  const [posting, setPosting] = useState(false);

  const load = async () => {
    const { data } = await supabase
      .from("blog_comments" as any)
      .select("id,user_id,content,created_at")
      .eq("blog_post_id", blogPostId)
      .order("created_at", { ascending: false });
    const rows = (data as unknown as CommentRow[]) || [];
    setComments(rows);
    const ids = Array.from(new Set(rows.map((r) => r.user_id)));
    const map: Record<string, ProfileLite> = {};
    await Promise.all(
      ids.map(async (uid) => {
        const { data: p } = await supabase.rpc("get_public_profile", { p_user_id: uid });
        const row = (p as ProfileLite[] | null)?.[0];
        if (row) map[uid] = row;
      })
    );
    setProfiles(map);
    setLoading(false);
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [blogPostId]);

  const handlePost = async () => {
    if (!user) { toast.error("Please sign in to comment"); return; }
    const value = text.trim();
    if (!value) return;
    if (value.length > 1000) { toast.error("Comment must be under 1000 characters"); return; }
    setPosting(true);
    const { error } = await supabase
      .from("blog_comments" as any)
      .insert({ blog_post_id: blogPostId, user_id: user.id, content: value });
    setPosting(false);
    if (error) { toast.error("Failed to post comment"); return; }
    setText("");
    load();
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from("blog_comments" as any).delete().eq("id", id);
    if (error) { toast.error("Failed to delete"); return; }
    setComments((c) => c.filter((x) => x.id !== id));
  };

  const fmt = (s: string) => {
    const d = new Date(s);
    const diff = (Date.now() - d.getTime()) / 1000;
    if (diff < 60) return "just now";
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return d.toLocaleDateString();
  };

  return (
    <section className="bg-card rounded-xl border border-border p-4 mt-6 text-left">
      <div className="flex items-center gap-2 mb-4">
        <MessageCircle className="h-5 w-5 text-primary" />
        <h2 className="font-heading font-semibold text-foreground">
          💬 Comments <span className="text-muted-foreground font-normal">({comments.length})</span>
        </h2>
      </div>

      {user ? (
        <div className="mb-5">
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Share your thoughts about this post..."
            rows={2}
            maxLength={1000}
            className="resize-none"
          />
          <div className="flex justify-between items-center mt-2">
            <span className="text-xs text-muted-foreground">{text.length}/1000</span>
            <Button size="sm" onClick={handlePost} disabled={posting || !text.trim()} className="gap-1.5">
              <Send className="h-3.5 w-3.5" /> Post
            </Button>
          </div>
        </div>
      ) : (
        <p className="text-sm text-muted-foreground mb-4">Sign in to leave a comment.</p>
      )}

      {loading ? (
        <p className="text-sm text-muted-foreground">Loading comments...</p>
      ) : comments.length === 0 ? (
        <p className="text-sm text-muted-foreground">No comments yet. Be the first! 💭</p>
      ) : (
        <ul className="space-y-4">
          {comments.map((c) => {
            const prof = profiles[c.user_id];
            const name = prof?.display_name || "User";
            const initial = name.charAt(0).toUpperCase();
            return (
              <li key={c.id} className="flex gap-3">
                <div className="shrink-0 w-9 h-9 rounded-full bg-primary/10 text-primary flex items-center justify-center font-semibold overflow-hidden">
                  {prof?.avatar_url ? (
                    <img src={prof.avatar_url} alt={name} className="w-full h-full object-cover" />
                  ) : (
                    initial
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-foreground truncate">{name}</span>
                    <span className="text-xs text-muted-foreground">{fmt(c.created_at)}</span>
                  </div>
                  <p className="text-sm text-foreground whitespace-pre-wrap break-words mt-0.5">
                    {c.content}
                  </p>
                </div>
                {user?.id === c.user_id && (
                  <button
                    onClick={() => handleDelete(c.id)}
                    className="text-muted-foreground hover:text-destructive shrink-0"
                    aria-label="Delete comment"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
};

export default BlogCommentSection;