import { lazy, Suspense, useEffect, useRef } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
const BrowserPdfReader = lazy(() => import("./BrowserPdfReader"));
export type PdfPaper = { file_path: string; file_name: string };
/** Android WebView (website-to-APK apps) marks itself with "; wv)" in the user agent. */
export function isAndroidWebView(ua: string = typeof navigator === "undefined" ? "" : navigator.userAgent) {
  return /Android/i.test(ua) && (/; wv\)/i.test(ua) || /Version\/[\d.]+ Chrome\/[\d.]+ Mobile/i.test(ua));
}

/** Hands the original PDF to Android's download manager so the phone's PDF app opens it. */
async function openWithDevice(paper: PdfPaper) {
  const id = toast.loading("Downloading PDF…");
  try {
    const { data, error } = await supabase.storage.from("previous-year-papers").createSignedUrl(paper.file_path, 600, { download: paper.file_name || "paper.pdf" });
    if (error || !data?.signedUrl) throw error || new Error("No link");
    window.location.href = data.signedUrl;
    toast.success("Download started. Tap the notification or open Downloads to view it in your PDF app.", { id, duration: 8000 });
  } catch (failure) {
    console.error("PDF download failed", failure);
    toast.error("Could not download this PDF. Check your internet and try again.", { id });
  }
}

export default function PdfReader({ paper, onClose }: { paper: PdfPaper | null; onClose: () => void }) {
  const external = isAndroidWebView();
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    if (!paper || !external) return;
    void openWithDevice(paper);
    closeRef.current();
  }, [paper, external]);
  if (external || !paper) return null;
  return <Dialog open onOpenChange={open => { if (!open) onClose(); }}>
    <Suspense fallback={<DialogContent><DialogTitle>Opening PDF…</DialogTitle></DialogContent>}>
      <BrowserPdfReader paper={paper} onClose={onClose} />
    </Suspense>
  </Dialog>;
}
