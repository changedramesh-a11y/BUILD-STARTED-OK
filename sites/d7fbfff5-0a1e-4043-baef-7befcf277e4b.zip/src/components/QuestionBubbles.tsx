interface Props {
  total: number;
  offset?: number;
  current: number;
  /** map index -> status. 'answered' (blue), 'correct' (green), 'wrong' (red), 'unseen' (outline) */
  statusFor: (index: number) => "answered" | "correct" | "wrong" | "unseen" | "current";
  onJump?: (index: number) => void;
}

const QuestionBubbles = ({ total, current, statusFor, onJump, offset = 0 }: Props) => {
  return (
    <div className="overflow-x-auto -mx-4 px-4 border-b border-border bg-card">
      <div className="flex gap-3 py-3 min-w-max">
        {Array.from({ length: total }).map((_, i) => {
          const isCurrent = i === current;
          const s = isCurrent ? "current" : statusFor(i);
          const cls = {
            current: "bg-muted text-foreground border-transparent",
            answered: "bg-[hsl(var(--tb-blue))] text-white border-transparent",
            correct: "bg-[hsl(var(--tb-green))] text-white border-transparent",
            wrong: "bg-[hsl(var(--tb-red))] text-white border-transparent",
            unseen: "bg-transparent text-muted-foreground border-border",
          }[s];
          return (
            <button
              key={i}
              onClick={() => onJump?.(i)}
              className={`relative shrink-0 w-9 h-9 rounded-full text-sm font-semibold border-2 ${cls}`}
            >
              {i + offset + 1}
              {isCurrent && <span className="absolute -bottom-3 left-1/2 -translate-x-1/2 h-0.5 w-6 bg-[hsl(var(--tb-blue))]" />}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default QuestionBubbles;
