import { useState } from "react";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { canDeleteMock } from "@/lib/mock-timing";
import { useQueryClient } from "@tanstack/react-query";

export default function MockDeleteButton({ id, title, type, onDeleted }: {
  id: string; title: string; type: string; onDeleted: () => void;
}) {
  const { role } = useAuth();
  const client = useQueryClient();
  const [deleting, setDeleting] = useState(false);
  if (!canDeleteMock(role, type)) return null;
  return <Button variant="outline" size="sm" className="text-destructive" disabled={deleting}
    aria-label={`Delete ${title}`} onClick={async event => {
      event.stopPropagation();
      if (!window.confirm(`Delete "${title}" and its attempts? This cannot be undone.`)) return;
      setDeleting(true);
      const { data, error } = await supabase.rpc("delete_mock", { _quiz_id: id });
      setDeleting(false);
      if (error || data !== true) { toast.error("Unable to delete this test."); return; }
      void client.invalidateQueries({ queryKey: ["test-list"] });
      void client.invalidateQueries({ queryKey: ["test-attempts"] });
      void client.invalidateQueries({ queryKey: ["home-feed"] });
      void client.invalidateQueries({ queryKey: ["saved-collection"] });
      toast.success("Deleted");
      onDeleted();
    }}><Trash2 className="h-4 w-4 mr-2" />Delete</Button>;
}