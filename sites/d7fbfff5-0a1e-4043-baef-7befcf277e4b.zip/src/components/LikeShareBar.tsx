import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Heart, MessageCircle, Share2 } from "lucide-react";
import { toast } from "sonner";

interface Props {
  targetType: "quiz" | "post";
  targetId: string;
  shareUrl: string;
  shareTitle: string;
  onCommentClick: (e: React.MouseEvent) => void;
  commentCount?: number;
  compact?: boolean;
}

const LikeShareBar = ({
  targetType,
  targetId,
  shareUrl,
  shareTitle,
  onCommentClick,
  commentCount,
  compact = true,
}: Props) => {
  const { user } = useAuth();
  const [liked, setLiked] = useState(false);
  const [count, setCount] = useState(0);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      const [countRes, mine] = await Promise.all([
        supabase.rpc("get_like_count" as any, {
          p_target_type: targetType,
          p_target_id: targetId,
        }),
        user
          ? supabase
              .from("likes" as any)
              .select("id")
              .eq("target_type", targetType)
              .eq("target_id", targetId)
              .eq("user_id", user.id)
              .maybeSingle()
          : Promise.resolve({ data: null } as any),
      ]);
      if (cancelled) return;
      setCount(Number((countRes as any)?.data ?? 0));
      setLiked(!!(mine as any)?.data);
    };
    load();
    return () => {
      cancelled = true;
    };
  }, [targetId, targetType, user]);

  const toggleLike = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user) {
      toast.error("Sign in to like");
      return;
    }
    if (busy) return;
    setBusy(true);
    if (liked) {
      const { error } = await supabase
        .from("likes" as any)
        .delete()
        .eq("target_type", targetType)
        .eq("target_id", targetId)
        .eq("user_id", user.id);
      if (!error) {
        setLiked(false);
        setCount((c) => Math.max(0, c - 1));
      }
    } else {
      const { error } = await supabase.from("likes" as any).insert({
        target_type: targetType,
        target_id: targetId,
        user_id: user.id,
      });
      if (!error) {
        setLiked(true);
        setCount((c) => c + 1);
      }
    }
    setBusy(false);
  };

  const handleShare = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const fullUrl = shareUrl.startsWith("http")
      ? shareUrl
      : `${window.location.origin}${shareUrl}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: shareTitle, url: fullUrl });
        return;
      }
    } catch {
      /* user cancelled */
    }
    try {
      await navigator.clipboard.writeText(fullUrl);
      toast.success("🔗 Link copied!");
    } catch {
      toast.error("Couldn't copy link");
    }
  };

  const iconSize = compact ? "h-4 w-4" : "h-5 w-5";
  const textSize = compact ? "text-xs" : "text-sm";

  return (
    <div className="flex items-center gap-1 pt-2 mt-2 border-t border-border">
      <button
        onClick={toggleLike}
        className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg ${textSize} font-medium transition-colors ${
          liked
            ? "text-rose bg-rose/10 hover:bg-rose/15"
            : "text-muted-foreground hover:bg-secondary hover:text-foreground"
        }`}
        aria-label="Like"
      >
        <Heart className={`${iconSize} ${liked ? "fill-current" : ""}`} />
        {count > 0 ? count : ""}
        <span>{liked ? "Liked" : "Like"}</span>
      </button>
      <button
        onClick={onCommentClick}
        className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg ${textSize} font-medium text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors`}
        aria-label="Comment"
      >
        <MessageCircle className={iconSize} />
        {typeof commentCount === "number" && commentCount > 0 ? commentCount : ""}
        <span>Comment</span>
      </button>
      <button
        onClick={handleShare}
        className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg ${textSize} font-medium text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors ml-auto`}
        aria-label="Share"
      >
        <Share2 className={iconSize} />
        <span>Share</span>
      </button>
    </div>
  );
};

export default LikeShareBar;