import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Newspaper } from "lucide-react";
import StoryViewer from "./StoryViewer";

export interface Story {
  id: string;
  author_id: string;
  title: string;
  content: string;
  image_url: string | null;
  exam_mode: string;
  created_at: string;
  expires_at: string;
}

interface StoryBarProps {
  examMode: "central" | "jharkhand";
  refreshTrigger?: number;
}

const StoryBar = ({ examMode, refreshTrigger }: StoryBarProps) => {
  const { user, role } = useAuth();
  const [stories, setStories] = useState<Story[]>([]);
  const [viewedIds, setViewedIds] = useState<Set<string>>(new Set());
  const [viewerIndex, setViewerIndex] = useState<number | null>(null);

  const canManage = role === "admin" || role === "moderator";

  const load = async () => {
    const { data } = await supabase
      .from("stories")
      .select("*")
      .eq("exam_mode", examMode)
      .gt("expires_at", new Date().toISOString())
      .order("created_at", { ascending: false });
    setStories((data as Story[]) || []);

    if (user) {
      const { data: views } = await supabase
        .from("story_views")
        .select("story_id")
        .eq("user_id", user.id);
      setViewedIds(new Set((views || []).map((v: any) => v.story_id)));
    }
  };

  useEffect(() => {
    load();
  }, [examMode, user?.id, refreshTrigger]);

  const handleOpen = (idx: number) => setViewerIndex(idx);

  const handleViewed = async (storyId: string) => {
    if (!user || viewedIds.has(storyId)) return;
    setViewedIds(new Set([...viewedIds, storyId]));
    await supabase.from("story_views").insert({ story_id: storyId, user_id: user.id });
  };

  if (!canManage && stories.length === 0) return null;

  return (
    <div className="mb-5">
      <p className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wide flex items-center gap-1.5">
        <Newspaper className="h-3.5 w-3.5" /> Daily News Stories
      </p>
      <div className="flex gap-3 overflow-x-auto pb-2 -mx-1 px-1 scrollbar-none">
        {stories.map((s, idx) => {
          const seen = viewedIds.has(s.id);
          return (
            <button
              key={s.id}
              onClick={() => handleOpen(idx)}
              className="flex-shrink-0 flex flex-col items-center gap-1 group"
            >
              <div
                className={`p-[2px] rounded-full ${
                  seen
                    ? "bg-muted-foreground/30"
                    : "bg-primary"
                }`}
              >
                <div className="h-16 w-16 rounded-full bg-background p-[2px]">
                  {s.image_url ? (
                    <img src={s.image_url} alt={s.title} className="h-full w-full rounded-full object-cover" />
                  ) : (
                    <div className="h-full w-full rounded-full bg-secondary flex items-center justify-center">
                      <Newspaper className="h-6 w-6 text-primary" />
                    </div>
                  )}
                </div>
              </div>
              <span className="text-[10px] text-foreground max-w-[64px] truncate">{s.title}</span>
            </button>
          );
        })}
      </div>

      {viewerIndex !== null && (
        <StoryViewer
          stories={stories}
          startIndex={viewerIndex}
          onClose={() => setViewerIndex(null)}
          onViewed={handleViewed}
          canManage={canManage}
          onDeleted={(id) => {
            setStories((prev) => prev.filter((x) => x.id !== id));
          }}
        />
      )}

    </div>
  );
};

export default StoryBar;
