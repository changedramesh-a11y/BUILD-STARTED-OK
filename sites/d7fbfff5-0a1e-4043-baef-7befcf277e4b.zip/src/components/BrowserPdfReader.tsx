import { memo, useEffect, useLayoutEffect, useRef, useState } from "react";
import { Document, Page, pdfjs } from "react-pdf";
import { ArrowLeft, ChevronLeft, ChevronRight, Download, FileText, Loader2, Maximize, RotateCw, Share2, ZoomIn, ZoomOut } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import "react-pdf/dist/Page/TextLayer.css";
import { pinchZoom, zoomScrollOffset } from "@/lib/pdf-gestures";
import type { PdfPaper } from "./PdfReader";
pdfjs.GlobalWorkerOptions.workerSrc = "/pdf-assets/pdf.worker.legacy.min.mjs";
const OPTIONS = { cMapUrl: "/pdf-assets/cmaps/", cMapPacked: true, standardFontDataUrl: "/pdf-assets/standard_fonts/", isEvalSupported: false };
export default function BrowserPdfReader({ paper, onClose }: { paper: PdfPaper; onClose: () => void }) {
  return <DialogContent aria-describedby="pdf-description" className="left-0 top-0 flex h-[100dvh] w-screen max-w-[100vw] translate-x-0 translate-y-0 flex-col gap-0 overflow-hidden rounded-none border-0 p-0 sm:rounded-none [&>button]:hidden"><Reader key={paper.file_path} paper={paper} onClose={onClose} /></DialogContent>;
}
function Reader({ paper, onClose }: { paper: PdfPaper; onClose: () => void }) {
  const [blob, setBlob] = useState<Blob | null>(null);
  const [file, setFile] = useState<{ data: Uint8Array } | null>(null);
  const [error, setError] = useState("");
  const [attempt, setAttempt] = useState(0);
  const [pages, setPages] = useState(0);
  const [page, setPage] = useState(1);
  const [pageInput, setPageInput] = useState("1");
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [width, setWidth] = useState(320);
  const [ratio, setRatio] = useState(1.414);
  const viewport = useRef<HTMLDivElement>(null);
  const zoomRef = useRef(1);
  const scrollFrame = useRef<number | null>(null);
  useEffect(() => () => { if (scrollFrame.current !== null) cancelAnimationFrame(scrollFrame.current); }, []);
  const pendingAnchor = useRef<{ left: number; top: number } | null>(null);

  function changeZoom(next: number, x?: number, y?: number) {
    const element = viewport.current;
    if (!element) return;
    const previous = zoomRef.current;
    pendingAnchor.current = {
      left: zoomScrollOffset(element.scrollLeft, x ?? element.clientWidth / 2, previous, next),
      top: zoomScrollOffset(element.scrollTop, y ?? element.clientHeight / 2, previous, next),
    };
    zoomRef.current = next;
    setZoom(next);
  }

  useLayoutEffect(() => {
    const anchor = pendingAnchor.current;
    const element = viewport.current;
    if (anchor && element) { element.scrollLeft = anchor.left; element.scrollTop = anchor.top; pendingAnchor.current = null; }
  }, [zoom]);

  useEffect(() => {
    const element = viewport.current;
    if (!element) return;
    let gesture: { distance: number; zoom: number } | null = null;
    const distance = (touches: TouchList) => Math.hypot(touches[0].clientX - touches[1].clientX, touches[0].clientY - touches[1].clientY);
    function start(event: TouchEvent) {
      if (event.touches.length !== 2) return;
      event.preventDefault();
      gesture = { distance: distance(event.touches), zoom: zoomRef.current };
    }
    function move(event: TouchEvent) {
      if (event.touches.length !== 2 || !gesture) return;
      event.preventDefault();
      const rect = element?.getBoundingClientRect();
      if (!rect) return;
      changeZoom(pinchZoom(gesture.zoom, gesture.distance, distance(event.touches)),
        (event.touches[0].clientX + event.touches[1].clientX) / 2 - rect.left,
        (event.touches[0].clientY + event.touches[1].clientY) / 2 - rect.top);
    }
    function end() { gesture = null; }
    element.addEventListener("touchstart", start, { passive: false });
    // PDF.js may replace a touched canvas while zooming; keep the active
    // gesture on the document so subsequent events are not lost with it.
    document.addEventListener("touchmove", move, { passive: false });
    document.addEventListener("touchend", end);
    document.addEventListener("touchcancel", end);
    return () => {
      element.removeEventListener("touchstart", start); document.removeEventListener("touchmove", move);
      document.removeEventListener("touchend", end); document.removeEventListener("touchcancel", end);
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    setError(""); setFile(null); setBlob(null); setPages(0);
    async function load() {
      try {
        const { data, error: downloadError } = await supabase.storage.from("previous-year-papers").download(paper.file_path);
        if (downloadError || !data) throw downloadError || new Error("File unavailable");
        const bytes = new Uint8Array(await data.arrayBuffer());
        if (!cancelled) { setBlob(data); setFile({ data: bytes }); }
      } catch (failure) {
        if (!cancelled) {
          console.error("PDF download failed", failure);
          setError("Could not load this PDF. Please check your connection and try again.");
        }
      }
    }
    void load();
    return () => { cancelled = true; };
  }, [paper.file_path, attempt]);

  useEffect(() => {
    if (pages > 0 || error) return;
    const timer = window.setTimeout(() => setError("This PDF is taking too long to open in this app. Tap Download to open it in your phone's PDF viewer, or try again."), 25000);
    return () => window.clearTimeout(timer);
  }, [pages, error, attempt]);

  useEffect(() => {
    const element = viewport.current;
    if (!element) return;
    const observer = new ResizeObserver(entries => {
      const entry = entries[0];
      if (entry) setWidth(Math.max(200, Math.min(1000, entry.contentRect.width - 24)));
    });
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  function goToPage(next: number) {
    if (!Number.isInteger(next) || next < 1 || next > pages) { setPageInput(String(page)); return; }
    setPage(next); setPageInput(String(next));
    const element = viewport.current;
    const target = element?.querySelector<HTMLElement>(`[data-pdf-page="${next}"]`);
    if (element && target) element.scrollTo({ top: target.offsetTop - 12, left: element.scrollLeft });
  }

  function download() {
    if (!blob) return;
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url; link.download = paper.file_name; document.body.appendChild(link);
    link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }

  async function share() {
    if (!blob) return;
    const shareFile = new File([blob], paper.file_name, { type: "application/pdf" });
    if (!navigator.canShare?.({ files: [shareFile] })) { download(); return; }
    try { await navigator.share({ files: [shareFile], title: paper.file_name }); }
    catch (failure) { if (!(failure instanceof DOMException && failure.name === "AbortError")) toast.error("Could not share the PDF"); }
  }

  return <>
    <header className="flex shrink-0 items-center gap-2 border-b border-border bg-card px-3 py-2">
      <Button variant="ghost" size="icon" aria-label="Back to papers" title="Back to papers" onClick={onClose}><ArrowLeft /></Button>
      <FileText className="hidden h-5 w-5 shrink-0 text-home-blue sm:block" />
      <DialogTitle className="min-w-0 flex-1 truncate text-sm font-semibold tracking-normal">{paper.file_name}</DialogTitle>
      <DialogDescription id="pdf-description" className="sr-only">PDF document</DialogDescription>
      <Button variant="ghost" size="icon" aria-label="Download PDF" title="Download PDF" disabled={!blob} onClick={download}><Download /></Button>
      <Button variant="ghost" size="icon" aria-label="Share PDF" title="Share PDF" disabled={!blob} onClick={() => void share()}><Share2 /></Button>
    </header>
    <div role="toolbar" aria-label="PDF tools" className="flex shrink-0 flex-wrap items-center justify-center gap-1 border-b border-border bg-card px-2 py-2 [&_button]:h-8 [&_button]:w-8 sm:gap-2 sm:[&_button]:h-10 sm:[&_button]:w-10">
      <Button variant="ghost" size="icon" aria-label="Previous page" title="Previous page" disabled={page <= 1 || !pages} onClick={() => goToPage(page - 1)}><ChevronLeft /></Button>
      <form className="flex items-center gap-2" onSubmit={event => { event.preventDefault(); goToPage(Number(pageInput)); }}>
        <Input aria-label="Page number" type="number" min={1} max={pages || 1} value={pageInput} disabled={!pages} onChange={event => setPageInput(event.target.value)} onBlur={() => goToPage(Number(pageInput))} className="h-9 w-14 px-1 text-center" />
        <span className="min-w-8 text-sm text-muted-foreground" aria-live="polite">/ {pages || "—"}</span>
      </form>
      <Button variant="ghost" size="icon" aria-label="Next page" title="Next page" disabled={!pages || page >= pages} onClick={() => goToPage(page + 1)}><ChevronRight /></Button>
      <span className="mx-1 h-5 border-l border-border" />
      <Button variant="ghost" size="icon" aria-label="Zoom out" title="Zoom out" disabled={!pages || zoom <= 0.5} onClick={() => changeZoom(Math.max(0.5, zoom - 0.25))}><ZoomOut /></Button>
      <span className="hidden w-12 text-center text-xs tabular-nums sm:inline">{Math.round(zoom * 100)}%</span>
      <Button variant="ghost" size="icon" aria-label="Zoom in" title="Zoom in" disabled={!pages || zoom >= 4} onClick={() => changeZoom(Math.min(4, zoom + 0.25))}><ZoomIn /></Button>
      <Button variant="ghost" size="icon" aria-label="Fit to width" title="Fit to width" disabled={!pages} onClick={() => changeZoom(1)}><Maximize /></Button>
      <Button variant="ghost" size="icon" aria-label="Rotate page" title="Rotate page" disabled={!pages} onClick={() => setRotation(value => (value + 90) % 360)}><RotateCw /></Button>
    </div>
    <div ref={viewport} aria-label="PDF pages" className="pdf-scroll-viewport relative min-h-0 flex-1 overflow-auto overscroll-contain bg-muted p-3" onScroll={() => {
      const element = viewport.current;
      if (!element || scrollFrame.current !== null) return;
      scrollFrame.current = requestAnimationFrame(() => {
      scrollFrame.current = null;
      const slots = Array.from(element.querySelectorAll<HTMLElement>("[data-pdf-page]"));
      const marker = element.scrollTop + Math.min(120, element.clientHeight / 3);
      const active = slots.find(slot => slot.offsetTop + slot.offsetHeight > marker);
      if (active) { const current = Number(active.dataset.pdfPage); setPage(current); if (document.activeElement?.getAttribute("aria-label") !== "Page number") setPageInput(String(current)); }
      });
    }}>
      {error ? <div role="alert" className="mx-auto max-w-md py-16 text-center"><FileText className="mx-auto mb-4 h-10 w-10 text-muted-foreground" /><p className="mb-4 text-sm">{error}</p><Button variant="outline" onClick={() => setAttempt(value => value + 1)}>Retry</Button></div>
        : !file ? <div role="status" className="flex items-center justify-center gap-2 py-16 text-sm text-muted-foreground"><Loader2 className="h-5 w-5 animate-spin" />Loading PDF…</div>
        : <Document file={file} options={OPTIONS} onLoadSuccess={async pdf => { setPages(pdf.numPages); setPage(1); setPageInput("1"); const first = await pdf.getPage(1); const size = first.getViewport({ scale: 1 }); setRatio(size.height / size.width); }} onLoadError={failure => { console.error("PDF render failed", failure); setError("This PDF could not be read. Try downloading it or ask for a new copy."); }} loading={<p role="status" className="py-16 text-center text-muted-foreground">Opening PDF…</p>} className="pdf-reader-document mx-auto w-max min-w-full">
          {Array.from({ length: pages }, (_, index) => <ScrollPage key={index} number={index + 1} width={width * zoom} ratio={ratio} rotation={rotation} viewport={viewport} />)}
        </Document>}
    </div>
  </>;
}

const ScrollPage = memo(function ScrollPage({ number, width, ratio, rotation, viewport }: { number: number; width: number; ratio: number; rotation: number; viewport: React.RefObject<HTMLDivElement> }) {
  const ref = useRef<HTMLDivElement>(null);
  const [near, setNear] = useState(number === 1);
  const [pageRatio, setPageRatio] = useState<number | null>(null);
  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    const observer = new IntersectionObserver(entries => setNear(entries.some(entry => entry.isIntersecting)), { root: viewport.current, rootMargin: "800px 0px" });
    observer.observe(element);
    return () => observer.disconnect();
  }, [viewport]);
  const naturalRatio = pageRatio ?? ratio;
  const heightRatio = rotation % 180 ? 1 / naturalRatio : naturalRatio;
  return <div ref={ref} data-pdf-page={number} aria-label={`PDF page ${number}`} className="pdf-reader-paper relative mx-auto mb-3 overflow-hidden shadow-sm [&>*]:pointer-events-none" style={{ width, height: width * heightRatio }}>
    {near ? <Page pageNumber={number} width={width} rotate={rotation} renderAnnotationLayer={false} devicePixelRatio={Math.min(window.devicePixelRatio || 1, 2)} onLoadSuccess={pdf => { const size = pdf.getViewport({ scale: 1, rotation: 0 }); setPageRatio(size.height / size.width); }} loading={<p role="status" className="py-16 text-center text-muted-foreground">Loading page {number}…</p>} error={<p className="p-8 text-center text-sm">Could not display page {number}.</p>} /> : <span className="absolute inset-0 flex items-center justify-center text-sm text-muted-foreground">{number}</span>}
  </div>;
});
