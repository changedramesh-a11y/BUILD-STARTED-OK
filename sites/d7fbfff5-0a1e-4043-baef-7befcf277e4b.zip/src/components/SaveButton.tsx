import { Bookmark, BookmarkCheck, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSavedContent } from "@/hooks/use-saved-content";
import type { SaveTarget } from "@/lib/saved-content";
import { memo } from "react";

export default memo(function SaveButton({ target, id }: { target: SaveTarget; id: string }) {
  const { ids, loading, error, pending, toggle, refetch } = useSavedContent(target);
  const saved = ids.includes(id);
  const label = error ? "Retry saved status" : saved ? "Remove from saved" : "Save";
  return <Button size="sm" variant="ghost" className={saved ? "shrink-0 gap-1.5 text-primary" : "shrink-0 gap-1.5 text-muted-foreground"} aria-label={label} title={label} aria-pressed={saved} disabled={loading || pending} onClick={e => {
    e.stopPropagation();
    if (error) { void refetch(); return; }
    toggle({ id, saved });
  }}>
    {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : saved ? <BookmarkCheck className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
    {saved ? "Saved" : error ? "Retry" : "Save"}
  </Button>;
});