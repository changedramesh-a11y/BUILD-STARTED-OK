import { useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { extractMindMap } from "../../supabase/functions/_shared/study-note-format";
import { mindMapImage, toMindMapPng } from "@/lib/note-mind-map";

export default function StudyNoteContent({ content }: { content: string }) {
  const { body, map, image: uploadedImage } = extractMindMap(content);
  const root = useRef<HTMLDivElement>(null);
  const [image, setImage] = useState("");
  useEffect(() => {
    setImage(uploadedImage || "");
    if (uploadedImage || !map || !root.current) return;
    let active = true;
    let revision = 0;
    const update = async () => {
      if (!root.current) return;
      const currentRevision = ++revision;
      const styles = getComputedStyle(root.current);
      const color = (name: string) => `hsl(${styles.getPropertyValue(name).trim()})`;
      const svg = mindMapImage(map, { background: color("--background"), text: color("--foreground"), accent: color("--primary"), border: color("--border"), surface: color("--muted") });
      try {
        const png = await toMindMapPng(svg);
        if (active && revision === currentRevision) setImage(png);
      } catch { if (active && revision === currentRevision) setImage(svg); }
    };
    update();
    const observer = new MutationObserver(update);
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
    return () => { active = false; observer.disconnect(); };
  }, [content]);
  return <div ref={root} className="study-note-content min-w-0 space-y-6 text-foreground">
    <ReactMarkdown remarkPlugins={[remarkGfm]} components={{
      table: ({ children }) => <div className="max-w-full overflow-x-auto"><table>{children}</table></div>,
      a: ({ children, href }) => <a href={href} rel="noopener noreferrer" className="text-primary underline">{children}</a>,
    }}>{body}</ReactMarkdown>
    {(map || uploadedImage) && <section aria-label="Article mind map" className="border-t border-border pt-6">
      <h2 className="mb-4 text-xl font-bold">Mind map</h2>
      {image && <a href={image} download={`mind-map.${image.startsWith("data:image/svg") ? "svg" : image.startsWith("data:image/jpeg") ? "jpg" : image.startsWith("data:image/webp") ? "webp" : "png"}`} aria-label="Download article mind map"><img src={image} alt={map ? `${map.topic}: ${map.branches.map((b) => `${b.label} — ${b.facts.join("; ")}`).join(". ")}` : "Article mind map"} className="block h-auto w-full" /></a>}
    </section>}
  </div>;
}