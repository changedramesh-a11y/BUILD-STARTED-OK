import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Loader2, Sparkles, Square } from "lucide-react";
import { readNotesStream } from "@/lib/ai-study-notes";

interface Props {
  examMode: string;
  category: string;
  isAdmin: boolean;
  onDraft: (draft: { title: string; excerpt: string; content: string }) => void;
}

export default function AiStudyNotes({ examMode, category, isAdmin, onDraft }: Props) {
  const [topic, setTopic] = useState("");
  const [language, setLanguage] = useState("English");
  const [generating, setGenerating] = useState(false);
  const [preview, setPreview] = useState("");
  const [error, setError] = useState("");
  const [blocked, setBlocked] = useState(false);
  const abort = useRef<AbortController | null>(null);
  useEffect(() => () => abort.current?.abort(), []);

  const generate = async (resume = false) => {
    setGenerating(true); setError(""); setPreview("");
    const controller = new AbortController();
    abort.current = controller;
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("Please sign in again.");
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-study-notes`, {
        method: "POST",
        headers: { Authorization: `Bearer ${session.access_token}`, apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY, "Content-Type": "application/json" },
        body: JSON.stringify({ topic, language, category, examMode, resume }),
        signal: controller.signal,
      });
      setBlocked(response.status === 402 || response.status === 403);
      const draft = await readNotesStream(response, setPreview);
      if (!controller.signal.aborted) onDraft(draft);
    } catch (e) {
      if (!controller.signal.aborted) setError(e instanceof Error ? e.message : "Unable to generate notes.");
    } finally { setGenerating(false); abort.current = null; }
  };

  return <section className="space-y-4 py-4">
    <div className="space-y-2">
      <Label htmlFor="ai-topic">Topic or chapter</Label>
      <Textarea id="ai-topic" placeholder="e.g. Indian Constitution: Fundamental Rights, key articles and examples" value={topic} onChange={(e) => setTopic(e.target.value)} maxLength={2000} rows={4} disabled={generating} />
    </div>
    <div className="space-y-2">
      <Label htmlFor="ai-language">Notes language</Label>
      <select id="ai-language" className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm" value={language} onChange={(e) => setLanguage(e.target.value)} disabled={generating}>
        <option>English</option><option>Hindi</option>
      </select>
    </div>
    {error && <p role="alert" className="break-words text-sm text-destructive">{error}</p>}
    {generating ? <Button variant="outline" className="w-full gap-2" onClick={() => abort.current?.abort()}><Square className="h-4 w-4" />Stop generation</Button> :
      <Button className="w-full gap-2" disabled={!topic.trim() || blocked} onClick={() => generate()}><Sparkles className="h-4 w-4" />Generate Notes</Button>}
    {blocked && isAdmin && <Button variant="outline" className="w-full" disabled={!topic.trim() || generating} onClick={() => generate(true)}>Resume AI after restoring access</Button>}
    {generating && <div role="status" className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" />Preparing notes…</div>}
    {preview && <div className="max-h-80 overflow-y-auto whitespace-pre-wrap break-words border-l-2 border-primary pl-4 text-sm text-foreground">{preview}</div>}
  </section>;
}