import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Trophy } from "lucide-react";

/** Uses the result screen's best-per-user ordering and existing read permissions. */
export default function TestRankBadge({ quizId }: { quizId: string }) {
  const { user } = useAuth();
  const { data: rank, isError } = useQuery({
    queryKey: ["test-card-rank", user?.id, quizId],
    enabled: Boolean(user),
    queryFn: async ({ signal }) => {
      if (!user) return null;
      const { data, error } = await supabase.from("attempts")
        .select("user_id,percentage,created_at").eq("quiz_id", quizId)
        .order("percentage", { ascending: false }).order("created_at", { ascending: true })
        .abortSignal(signal);
      if (error) throw error;
      const participants = [...new Set((data || []).map(attempt => attempt.user_id))];
      const index = participants.indexOf(user.id);
      return index >= 0 ? index + 1 : null;
    },
  });
  return <span className="ml-auto inline-flex shrink-0 items-center gap-1 rounded-full bg-emerald/10 px-2 py-0.5 text-xs font-semibold text-emerald" title={isError ? "Rank unavailable" : undefined}>
    <Trophy className="h-3 w-3" /> Rank {rank ? `#${rank}` : "—"}
  </span>;
}