import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

const NoticeUploader = ({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) => {
  const { user } = useAuth();
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!user || !title.trim()) return toast.error("Title required");
    setSaving(true);
    const { error } = await supabase.from("notices").insert({ author_id: user.id, title: title.trim(), content: content.trim() });
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Notice published");
    onCreated();
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader><DialogTitle>Add Notice</DialogTitle></DialogHeader>
        <Input placeholder="Notice title" value={title} onChange={(e) => setTitle(e.target.value)} />
        <Textarea placeholder="Notice details" rows={5} value={content} onChange={(e) => setContent(e.target.value)} />
        <Button onClick={save} disabled={saving}>{saving ? "Publishing..." : "Publish Notice"}</Button>
      </DialogContent>
    </Dialog>
  );
};

export default NoticeUploader;
