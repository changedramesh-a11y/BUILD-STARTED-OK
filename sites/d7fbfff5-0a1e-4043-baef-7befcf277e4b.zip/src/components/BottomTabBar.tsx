import { Home, BookOpen, ClipboardList, BookMarked, Award, FileCode } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";

const TABS = [
  { id: "home", label: "Home", icon: Home, path: "/home" },
  { id: "notes", label: "Study Notes", icon: BookOpen, path: "/blog" },
  { id: "live", label: "Weekly Mock", icon: ClipboardList, path: "/weekly-mock" },
  { id: "quizzes", label: "Daily Quiz", icon: BookMarked, path: "/daily-quiz" },
  { id: "rankers", label: "Current Affairs", icon: Award, path: "/daily-current-affairs" },
  { id: "papers", label: "Prev. Papers", icon: FileCode, path: "/prev-papers" },
];

const BottomTabBar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  return (
    <nav aria-label="Main navigation" className="fixed bottom-0 inset-x-0 z-30 border-t border-border bg-card pb-[env(safe-area-inset-bottom)]">
      <div className="mx-auto grid max-w-6xl grid-cols-6">
        {TABS.map((t) => {
          const active = t.path && location.pathname.startsWith(t.path.split("#")[0]) && !t.path.includes("#");
          return (
            <Button
              key={t.id}
              variant="ghost"
              aria-current={active ? "page" : undefined}
              onClick={() => navigate(t.path)}
              className={`relative flex h-[72px] min-w-0 flex-col gap-1 rounded-none px-0.5 py-2 text-[9px] font-medium hover:bg-secondary hover:text-foreground sm:text-xs ${active ? "text-home-blue" : "text-muted-foreground"}`}
            >
              {active && <span className="absolute top-0 h-0.5 w-6 bg-home-blue" />}
              <t.icon className="!h-5 !w-5 shrink-0" />
              <span className="flex h-7 w-full items-center justify-center whitespace-normal text-center leading-3 sm:leading-4">{t.label}</span>
            </Button>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomTabBar;
