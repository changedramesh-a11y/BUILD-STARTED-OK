import { createContext, useContext, useEffect, useState, useMemo, useRef, ReactNode, useCallback } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

type UserRole = "admin" | "moderator" | "user";

const SESSION_LOGIN_KEY = "trust_login_timestamp";
const ONE_WEEK_MS = 7 * 24 * 60 * 60 * 1000;

interface AuthContextType {
  session: Session | null;
  user: User | null;
  role: UserRole;
  loading: boolean;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  session: null,
  user: null,
  role: "user",
  loading: true,
  signOut: async () => {},
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const queryClient = useQueryClient();
  const roleRequest = useRef<{ id: string; request: Promise<void> } | null>(null);
  const cacheUser = useRef<string | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<UserRole>("user");
  const [loading, setLoading] = useState(true);

  const fetchRole = useCallback((userId: string) => {
    if (roleRequest.current?.id === userId) return roleRequest.current.request;
    const request = (async () => {
    try {
      const { data } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", userId)
        .maybeSingle();
      if (roleRequest.current?.id === userId) setRole((data?.role as UserRole) ?? "user");
    } catch {
      if (roleRequest.current?.id === userId) setRole("user");
    }
    })();
    roleRequest.current = { id: userId, request };
    void request.finally(() => { if (roleRequest.current?.request === request) roleRequest.current = null; });
    return request;
  }, []);

  const signOut = useCallback(async () => {
    queryClient.clear();
    roleRequest.current = null;
    localStorage.removeItem(SESSION_LOGIN_KEY);
    await supabase.auth.signOut();
    setRole("user");
  }, [queryClient]);

  // Check if session has expired (1 week since login)
  const checkWeeklyExpiry = useCallback(async () => {
    const loginTs = localStorage.getItem(SESSION_LOGIN_KEY);
    if (loginTs && Date.now() - Number(loginTs) > ONE_WEEK_MS) {
      await signOut();
      return true;
    }
    return false;
  }, [signOut]);

  useEffect(() => {
    let mounted = true;
    const resetAccountCache = (nextId: string | null) => {
      if (cacheUser.current === nextId) return;
      queryClient.clear();
      roleRequest.current = null;
      cacheUser.current = nextId;
    };

    // 1. Restore session first
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (!mounted) return;

      if (session?.user) {
        // Check weekly expiry
        const expired = await checkWeeklyExpiry();
        if (expired || !mounted) return;

        resetAccountCache(session.user.id);
        setSession(session);
        setUser(session.user);
        fetchRole(session.user.id);
      } else {
        resetAccountCache(null);
        setSession(null);
        setUser(null);
      }
      setLoading(false);
    });

    // 2. Listen for auth changes (no awaits inside callback!)
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        if (!mounted) return;
        resetAccountCache(session?.user.id ?? null);
        setSession(session);
        setUser(session?.user ?? null);

        if (session?.user) {
          // Record login timestamp on sign-in
          if (_event === "SIGNED_IN") {
            if (!localStorage.getItem(SESSION_LOGIN_KEY)) {
              localStorage.setItem(SESSION_LOGIN_KEY, String(Date.now()));
            }
          }
          // Fire and forget — no await
          fetchRole(session.user.id);
        } else {
          setRole("user");
        }

        setLoading(false);
      }
    );

    return () => {
      mounted = false;
      roleRequest.current = null;
      subscription.unsubscribe();
    };
  }, [fetchRole, checkWeeklyExpiry, queryClient]);

  const value = useMemo(() => ({ session, user, role, loading, signOut }), [session, user, role, loading, signOut]);
  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
