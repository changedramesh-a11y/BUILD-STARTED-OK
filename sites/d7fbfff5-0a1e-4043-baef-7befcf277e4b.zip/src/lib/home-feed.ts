import { supabase } from "@/integrations/supabase/client";

export type FeedKind = "test" | "note" | "affairs" | "paper" | "notice" | "community";
export interface FeedItem {
  id: string;
  kind: FeedKind;
  label: string;
  title: string;
  description: string;
  createdAt: string;
  path: string;
  image?: string | null;
  meta?: string;
}

export function newestFirst(items: FeedItem[]): FeedItem[] {
  return [...items].sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt));
}

export async function loadHomeFeed(examMode: "central" | "jharkhand"): Promise<FeedItem[]> {
  const [tests, notes, affairs, papers, notices, community] = await Promise.all([
    supabase.from("quizzes").select("id,title,description,type,duration_minutes,total_questions,created_at").eq("is_published", true).eq("exam_mode", examMode).order("created_at", { ascending: false }).limit(30),
    supabase.from("blog_posts").select("id,title,excerpt,category,cover_image_url,created_at").eq("is_published", true).eq("exam_mode", examMode).order("created_at", { ascending: false }).limit(30),
    supabase.from("stories").select("id,title,content,image_url,created_at").eq("exam_mode", examMode).gt("expires_at", new Date().toISOString()).order("created_at", { ascending: false }).limit(30),
    supabase.from("previous_year_papers").select("id,exam_name,category,year,created_at").in("category", examMode === "jharkhand" ? ["jssc"] : ["ssc", "railway", "banking", "upsc", "central", "other"]).order("created_at", { ascending: false }).limit(30),
    supabase.from("notices").select("id,title,content,created_at").order("created_at", { ascending: false }).limit(30),
    supabase.from("community_posts").select("id,caption,image_url,created_at").eq("exam_mode", examMode).order("created_at", { ascending: false }).limit(30),
  ]);
  const failure = [tests, notes, affairs, papers, notices, community].find(result => result.error);
  if (failure?.error) throw failure.error;
  return newestFirst([
    ...(tests.data || []).map(q => ({ id: q.id, kind: "test" as const, label: q.type === "weekly_mock" ? "Weekly Mock" : q.type === "daily_quiz" ? "Daily Quiz" : q.type === "mock" ? "Mock Test" : "Quiz", title: q.title, description: q.description || "", createdAt: q.created_at, path: `/quiz/${q.id}`, meta: `${q.total_questions} questions · ${q.duration_minutes} min` })),
    ...(notes.data || []).map(p => ({ id: p.id, kind: "note" as const, label: "Study Notes", title: p.title, description: p.excerpt || "", createdAt: p.created_at, path: `/blog/${p.id}`, image: p.cover_image_url, meta: p.category })),
    ...(affairs.data || []).map(s => ({ id: s.id, kind: "affairs" as const, label: "Current Affairs", title: s.title, description: s.content, createdAt: s.created_at, path: `/daily-current-affairs?article=${encodeURIComponent(s.id)}`, image: s.image_url })),
    ...(papers.data || []).map(p => ({ id: p.id, kind: "paper" as const, label: "Previous Paper", title: `${p.exam_name} · ${p.year}`, description: "", createdAt: p.created_at, path: `/prev-papers/${p.category}/${encodeURIComponent(p.exam_name)}`, meta: "Original paper · PDF" })),
    ...(notices.data || []).map(n => ({ id: n.id, kind: "notice" as const, label: "Notice Board", title: n.title, description: n.content, createdAt: n.created_at, path: "/home", meta: "Official notice" })),
    ...(community.data || []).map(p => ({ id: p.id, kind: "community" as const, label: "Community", title: p.caption || "Community update", description: "", createdAt: p.created_at, path: "/community", image: p.image_url })),
  ]);
}