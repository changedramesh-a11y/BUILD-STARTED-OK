export interface MockSection {
  name: string;
  duration_minutes: number;
}

export const MAX_MOCK_SECTIONS = 5;

export const supportsMockSections = (type: string) => type === "mock" || type === "weekly_mock";

export function prepareMockSections(type: string, enabled: boolean, sections: MockSection[]): MockSection[] {
  if (!enabled || !supportsMockSections(type)) return [];
  if (sections.length < 1 || sections.length > MAX_MOCK_SECTIONS) {
    throw new Error("Choose between 1 and 5 sections.");
  }
  return sections.map((section, index) => {
    if (!section.name.trim()) throw new Error(`Enter a name for section ${index + 1}.`);
    if (!Number.isInteger(section.duration_minutes) || section.duration_minutes < 1) {
      throw new Error(`Enter a time of at least 1 whole minute for section ${index + 1}.`);
    }
    return { name: section.name.trim(), duration_minutes: section.duration_minutes };
  });
}
export interface SectionRange { name: string; start: number; end: number }

/** Splits questions in upload order evenly across sections (earlier sections take any remainder). */
export function splitQuestionsIntoSections(total: number, sections: { name: string }[]): SectionRange[] {
  if (!sections.length || total <= 0) return [];
  const n = Math.min(sections.length, total);
  const base = Math.floor(total / n), extra = total % n;
  const out: SectionRange[] = [];
  let start = 0;
  for (let i = 0; i < n; i++) {
    const size = base + (i < extra ? 1 : 0);
    out.push({ name: sections[i].name, start, end: start + size });
    start += size;
  }
  return out;
}

export type PaletteStatus = "answered" | "not_answered" | "not_visited" | "marked" | "answered_marked";

export function paletteStatus(answered: boolean, visited: boolean, marked: boolean): PaletteStatus {
  if (marked) return answered ? "answered_marked" : "marked";
  if (answered) return "answered";
  return visited ? "not_answered" : "not_visited";
}
