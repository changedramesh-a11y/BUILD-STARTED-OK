import type { NoteMindMap } from "../../supabase/functions/_shared/study-note-format";

const escape = (text: string) => text.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" }[c] || c));
export async function toMindMapPng(source: string): Promise<string> {
  await document.fonts.ready;
  const image = new Image();
  image.src = source;
  await image.decode();
  const canvas = document.createElement("canvas");
  const scale = Math.min(2, 1600 / image.naturalWidth, 10000 / image.naturalHeight);
  canvas.width = Math.round(image.naturalWidth * scale);
  canvas.height = Math.round(image.naturalHeight * scale);
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Unable to prepare the mind-map image.");
  context.drawImage(image, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/png");
}
function lines(text: string, limit: number): string[] {
  const result: string[] = [];
  let current = "";
  for (const word of text.split(/\s+/)) {
    if (current && (current + " " + word).length > limit) { result.push(current); current = ""; }
    current += (current ? " " : "") + word;
  }
  if (current) result.push(current);
  return result;
}

export function mindMapImage(map: NoteMindMap, colors: { background: string; text: string; accent: string; border: string; surface: string }): string {
  const width = 400;
  const topicLines = lines(map.topic, 27);
  const rootHeight = 30 + topicLines.length * 24;
  let y = rootHeight + 64;
  const text = (value: string, x: number, top: number, limit: number, bold = false) => lines(value, limit).map((line, i) => `<text x="${x}" y="${top + i * 24}" fill="${colors.text}" font-family="Arial, sans-serif" font-size="20"${bold ? ' font-weight="700"' : ""}>${escape(line)}</text>`).join("");
  let nodes = "";
  for (const branch of map.branches) {
    const headingHeight = lines(branch.label, 24).length * 24;
    const height = 32 + headingHeight + branch.facts.reduce((sum, fact) => sum + lines("• " + fact, 24).length * 24 + 12, 0);
    nodes += `<path d="M36 ${rootHeight + 36} V${y + 28} H60" fill="none" stroke="${colors.accent}" stroke-width="3"/><rect x="60" y="${y}" width="320" height="${height}" rx="8" fill="${colors.surface}" stroke="${colors.border}"/>`;
    nodes += text(branch.label, 76, y + 30, 24, true);
    let factY = y + 30 + headingHeight + 12;
    for (const fact of branch.facts) { nodes += text("• " + fact, 76, factY, 24); factY += lines("• " + fact, 24).length * 24 + 12; }
    y += height + 24;
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${y}" viewBox="0 0 ${width} ${y}"><rect width="100%" height="100%" fill="${colors.background}"/><rect x="20" y="16" width="360" height="${rootHeight}" rx="8" fill="${colors.surface}" stroke="${colors.accent}" stroke-width="2"/>${text(map.topic, 36, 46, 27, true)}${nodes}</svg>`;
  return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
}