/** Memory-only caches: no private content is persisted on the device. */
export const PAGE_STALE_TIME = 30_000;
export const PAGE_GC_TIME = 5 * 60_000;
export const queryDefaults = {
  staleTime: PAGE_STALE_TIME,
  gcTime: PAGE_GC_TIME,
  refetchOnWindowFocus: false,
  retry: 1,
} as const;