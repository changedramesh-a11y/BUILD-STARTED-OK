import { requireMindMap } from "../../supabase/functions/_shared/study-note-format";

export function parseStudyNotes(text: string) {
  const lines = text.trim().split(/\r?\n/);
  const title = lines.shift()?.trim() || "";
  const excerpt = lines.shift()?.trim() || "";
  const content = lines.join("\n").trim();
  if (!title || !content) throw new Error("AI returned incomplete notes. Your existing draft is unchanged.");
  return { title, excerpt, content };
}

export async function readNotesStream(response: Response, onText: (text: string) => void) {
  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.error || "Unable to generate notes.");
  }
  if (!response.body) throw new Error("No response received.");
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let text = "";
  let completed = false;
  try {
    while (true) {
      const chunk = await reader.read();
      if (chunk.done) break;
      buffer += decoder.decode(chunk.value, { stream: true });
      const events = buffer.split("\n\n");
      buffer = events.pop() || "";
      for (const event of events) {
        if (!event.startsWith("data: ")) continue;
        const data = JSON.parse(event.slice(6));
        if (data.error) throw new Error(data.error);
        if (data.text) { text += data.text; onText(text); }
        if (data.done) completed = true;
      }
    }
    if (!completed) throw new Error("Generation was interrupted. Your existing draft is unchanged.");
    requireMindMap(text);
    return parseStudyNotes(text);
  } finally { await reader.cancel(); reader.releaseLock(); }
}