export type SavedKind = "daily" | "weekly" | "notes" | "papers";
export type SaveTarget = "quiz" | "note" | "paper";

export function matchesSavedTest(type: string, kind: SavedKind) {
  return kind === "daily" ? ["quiz", "daily_quiz"].includes(type)
    : kind === "weekly" ? ["mock", "weekly_mock"].includes(type) : false;
}

export const SAVE_TABLES = {
  quiz: { table: "saved_quizzes", column: "quiz_id" },
  note: { table: "saved_blogs", column: "blog_post_id" },
  paper: { table: "saved_papers", column: "paper_id" },
} as const;