export function validatePaper(examName: string, year: string, file: { name: string; type: string; size: number } | null): string | null {
  if (!examName.trim()) return "Please enter the exam name";
  if (!/^\d{4}$/.test(year) || Number(year) < 1900) return "Please enter a valid four-digit year";
  if (!file) return "Please choose a PDF file";
  if (!file.name.toLowerCase().endsWith(".pdf") || (file.type && file.type !== "application/pdf")) return "Please choose a PDF file";
  if (file.size === 0) return "The PDF file is empty";
  if (file.size > 20 * 1024 * 1024) return "PDF must be 20 MB or smaller";
  return null;
}