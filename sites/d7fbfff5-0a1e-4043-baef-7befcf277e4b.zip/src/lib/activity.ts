export function isActivityTest(quizId: string, attempts: Record<string, unknown>) {
  return Object.prototype.hasOwnProperty.call(attempts, quizId);
}

export function isActivityNote(postId: string, savedIds: readonly string[]) {
  return savedIds.includes(postId);
}