export const PYQ_CATALOG: { id: string; name: string; emoji: string; exams: string[] }[] = [
  { id: "railway", name: "Railway", emoji: "🚆", exams: ["RRB ALP", "RRB GROUP-D", "RRB JE", "RRB NTPC", "RRB TECHNICIAN", "RRB SECTION CONTROLLER"] },
  { id: "ssc", name: "SSC", emoji: "📘", exams: ["SSC CGL", "SSC MTS", "SSC GD", "SSC CHSL", "SSC PHASE"] },
  { id: "jssc", name: "JSSC", emoji: "🏛️", exams: ["JSSC POLICE", "JSSC CGL", "JSSC DAROGA", "JSSC JE"] },
  { id: "bssc", name: "BSSC", emoji: "📗", exams: [] },
  { id: "upssc", name: "UPSSC", emoji: "📙", exams: [] },
];
export const findCategory = (id?: string) => PYQ_CATALOG.find(c => c.id === id);
