/** Keep the original if encoding is unsupported or would make it larger. */
export async function optimizeImage(file: File, maxDimension?: number): Promise<File> {
  if (!["image/png", "image/jpeg", "image/webp"].includes(file.type)) return file;
  const url = URL.createObjectURL(file);
  try {
    const image = new Image();
    image.src = url;
    await image.decode();
    const scale = maxDimension ? Math.min(1, maxDimension / Math.max(image.naturalWidth, image.naturalHeight)) : 1;
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
    const context = canvas.getContext("2d");
    if (!context) return file;
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve, "image/webp", 0.92));
    canvas.width = 0; canvas.height = 0;
    return blob?.type === "image/webp" && blob.size < file.size
      ? new File([blob], file.name.replace(/\.[^.]+$/, "") + ".webp", { type: blob.type }) : file;
  } catch { return file; }
  finally { URL.revokeObjectURL(url); }
}