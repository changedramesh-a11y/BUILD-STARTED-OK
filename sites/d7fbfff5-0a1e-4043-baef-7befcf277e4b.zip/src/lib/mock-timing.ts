import { splitQuestionsIntoSections, supportsMockSections, type MockSection } from "./mock-sections";

export function mockSchedule(type: string, total: number, sections: MockSection[]) {
  if (!supportsMockSections(type)) return [];
  let elapsed = 0;
  return splitQuestionsIntoSections(total, sections).map((range, index) => {
    const startsAt = elapsed;
    elapsed += sections[index].duration_minutes * 60;
    return { ...range, startsAt, endsAt: elapsed };
  });
}

export function timingAt(schedule: ReturnType<typeof mockSchedule>, startedAt: number, now: number) {
  const elapsed = Math.max(0, Math.floor((now - startedAt) / 1000));
  const index = schedule.findIndex(section => elapsed < section.endsAt);
  const section = schedule[index];
  return { index, section, remaining: section ? section.endsAt - elapsed : 0, finished: index < 0 };
}

export function canVisitQuestion(index: number, section: { start: number; end: number } | undefined) {
  return Boolean(section && index >= section.start && index < section.end);
}

export const canDeleteMock = (role: string, _type?: string) => role === "admin";