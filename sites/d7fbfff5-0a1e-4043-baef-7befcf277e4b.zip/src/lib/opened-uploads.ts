import type { FeedItem } from "@/lib/home-feed";

export const openedUploadsKey = (userId: string) => `opened-uploads:${userId}`;
export const uploadIdentity = (item: Pick<FeedItem, "kind" | "id">) => `${item.kind}:${item.id}`;
export const hidesAfterOpening = (item: Pick<FeedItem, "kind">) => item.kind === "test" || item.kind === "note" || item.kind === "paper";

export function parseOpenedUploads(value: string | null): string[] {
  try {
    const parsed: unknown = JSON.parse(value || "[]");
    return Array.isArray(parsed) ? parsed.filter((entry): entry is string => typeof entry === "string") : [];
  } catch {
    return [];
  }
}

export function unopenedUploads(items: FeedItem[], opened: readonly string[]): FeedItem[] {
  const ids = new Set(opened);
  return items.filter(item => !hidesAfterOpening(item) || !ids.has(uploadIdentity(item)));
}