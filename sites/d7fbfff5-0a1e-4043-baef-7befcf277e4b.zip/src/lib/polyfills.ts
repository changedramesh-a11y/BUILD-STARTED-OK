// Older Android WebViews (website-to-APK apps) lack features PDF.js needs.
const P = Promise as any;
if (typeof P.withResolvers !== "function") {
  P.withResolvers = function () { let resolve: any, reject: any; const promise = new Promise((a, b) => { resolve = a; reject = b; }); return { promise, resolve, reject }; };
}
export {};
