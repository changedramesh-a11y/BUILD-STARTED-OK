export function pinchZoom(startZoom: number, startDistance: number, distance: number) {
  if (startDistance <= 0) return startZoom;
  return Math.max(0.5, Math.min(4, startZoom * distance / startDistance));
}

export function zoomScrollOffset(offset: number, focalPoint: number, previousZoom: number, nextZoom: number) {
  return Math.max(0, (offset + focalPoint) * nextZoom / previousZoom - focalPoint);
}