import { useSyncExternalStore } from "react";

export type ExamMode = "central" | "jharkhand";
const MODE_EVENT = "exam-mode-changed";
const readMode = (): ExamMode => localStorage.getItem("exam_mode") === "jharkhand" ? "jharkhand" : "central";

function subscribe(onChange: () => void) {
  const onStorage = (event: StorageEvent) => {
    if (event.key === "exam_mode" || event.key === null) onChange();
  };
  window.addEventListener(MODE_EVENT, onChange);
  window.addEventListener("storage", onStorage);
  return () => {
    window.removeEventListener(MODE_EVENT, onChange);
    window.removeEventListener("storage", onStorage);
  };
}

export function useExamMode() {
  const mode = useSyncExternalStore(subscribe, readMode, () => "central" as ExamMode);
  const setMode = (next: ExamMode) => {
    localStorage.setItem("exam_mode", next);
    window.dispatchEvent(new Event(MODE_EVENT));
  };
  return [mode, setMode] as const;
}