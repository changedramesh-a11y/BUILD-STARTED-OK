import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { SAVE_TABLES, type SaveTarget } from "@/lib/saved-content";
import { toast } from "sonner";

export function useSavedContent(target: SaveTarget) {
  const { user } = useAuth();
  const client = useQueryClient();
  const key = ["saved-content", user?.id, target];
  const query = useQuery({
    queryKey: key, enabled: Boolean(user),
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase.from(SAVE_TABLES[target].table).select("*").eq("user_id", user.id);
      if (error) throw error;
      return (data || []).map(row => "quiz_id" in row ? row.quiz_id : "paper_id" in row ? row.paper_id : row.blog_post_id);
    },
  });
  const mutation = useMutation({
    mutationFn: async ({ id, saved }: { id: string; saved: boolean }) => {
      if (!user) throw new Error("Please sign in to save content.");
      const result = saved
        ? target === "quiz" ? await supabase.from("saved_quizzes").delete().eq("user_id", user.id).eq("quiz_id", id)
        : target === "paper" ? await supabase.from("saved_papers").delete().eq("user_id", user.id).eq("paper_id", id)
        : await supabase.from("saved_blogs").delete().eq("user_id", user.id).eq("blog_post_id", id)
        : target === "quiz" ? await supabase.from("saved_quizzes").insert({ user_id: user.id, quiz_id: id })
        : target === "paper" ? await supabase.from("saved_papers").insert({ user_id: user.id, paper_id: id })
        : await supabase.from("saved_blogs").insert({ user_id: user.id, blog_post_id: id });
      if (result.error) throw result.error;
      return { id, saved };
    },
    onSuccess: ({ id, saved }) => {
      client.setQueryData<string[]>(key, old => saved ? (old || []).filter(value => value !== id) : [...new Set([...(old || []), id])]);
      void client.invalidateQueries({ queryKey: ["saved-collection"] });
      toast.success(saved ? "Removed from saved" : "Saved to your collection");
    },
    onError: () => toast.error("Could not update your saved items. Please try again."),
  });
  return { ids: query.data || [], loading: query.isLoading, error: query.isError, refetch: query.refetch, pending: mutation.isPending, toggle: mutation.mutate };
}