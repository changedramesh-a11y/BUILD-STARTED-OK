import { useEffect } from "react";
import { toast } from "@/hooks/use-toast";

export const EXIT_BACK_WINDOW_MS = 2000;

/**
 * Pure double-back-to-exit logic, kept separate from the DOM so it can be
 * unit-tested. handleBack() returns true when the app should stay on the
 * current page (a warning was shown) and false when it should exit.
 */
export function createExitBackController(
  now: () => number,
  onExit: () => void,
  onWarn: () => void,
) {
  let lastWarnAt = -Infinity;
  return {
    handleBack(): boolean {
      const t = now();
      if (t - lastWarnAt <= EXIT_BACK_WINDOW_MS) {
        onExit();
        return false;
      }
      lastWarnAt = t;
      onWarn();
      return true;
    },
  };
}

/**
 * Call on the Home page only. Pushes a guard history entry so the first
 * hardware/browser back press is intercepted: it shows "Press back again to
 * exit" instead of leaving Home. A second press within EXIT_BACK_WINDOW_MS
 * closes the app (installed PWA) or falls back to leaving the page.
 */
export function useExitBack(enabled = true) {
  useEffect(() => {
    if (!enabled) return;
    let exiting = false;
    const controller = createExitBackController(
      () => Date.now(),
      () => {
        // Stop listening before leaving; otherwise every following popstate
        // re-triggers exit and the app races back through its whole history,
        // which freezes Android WebView (website-to-APK) apps.
        exiting = true;
        window.removeEventListener("popstate", onPopState);
        window.close();
        window.history.back();
      },
      () => toast({ title: "Press back again to exit" }),
    );
    // Only one guard entry per Home visit; re-mounting on an existing guard
    // must not stack more entries.
    const pushGuard = () => {
      if (!window.history.state?.homeExitGuard) window.history.pushState({ ...window.history.state, homeExitGuard: true }, "");
    };
    pushGuard();
    function onPopState() {
      if (exiting) return;
      if (controller.handleBack()) pushGuard();
    }
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, [enabled]);
}
