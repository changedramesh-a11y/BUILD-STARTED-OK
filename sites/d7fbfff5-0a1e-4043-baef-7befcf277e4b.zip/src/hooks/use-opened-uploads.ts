import { useCallback, useMemo, useSyncExternalStore } from "react";
import { hidesAfterOpening, openedUploadsKey, parseOpenedUploads, uploadIdentity } from "@/lib/opened-uploads";
import type { FeedItem } from "@/lib/home-feed";

const EVENT = "opened-uploads-changed";
const fallback = new Map<string, string>();

export function useOpenedUploads(userId?: string) {
  const key = userId ? openedUploadsKey(userId) : null;
  const subscribe = useCallback((onChange: () => void) => {
    const onStorage = (event: StorageEvent) => { if (event.key === key || event.key === null) onChange(); };
    window.addEventListener(EVENT, onChange);
    window.addEventListener("storage", onStorage);
    return () => {
      window.removeEventListener(EVENT, onChange);
      window.removeEventListener("storage", onStorage);
    };
  }, [key]);
  const read = useCallback(() => {
    if (!key) return "[]";
    try { return localStorage.getItem(key) || fallback.get(key) || "[]"; }
    catch { return fallback.get(key) || "[]"; }
  }, [key]);
  const snapshot = useSyncExternalStore(subscribe, read, () => "[]");
  const opened = useMemo(() => parseOpenedUploads(snapshot), [snapshot]);
  const markOpened = (item: FeedItem) => {
    if (!key || !hidesAfterOpening(item)) return;
    const next = JSON.stringify([...new Set([...parseOpenedUploads(read()), uploadIdentity(item)])]);
    fallback.set(key, next);
    try { localStorage.setItem(key, next); } catch { /* Keep navigation working when browser storage is unavailable. */ }
    window.dispatchEvent(new Event(EVENT));
  };
  return { opened, markOpened };
}