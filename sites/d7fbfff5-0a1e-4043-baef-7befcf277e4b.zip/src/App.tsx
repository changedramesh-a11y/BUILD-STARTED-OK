import { lazy, Suspense } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { queryDefaults } from "@/lib/query-policy";

const Home = lazy(() => import("./pages/Home"));
const Auth = lazy(() => import("./pages/Auth"));
const ForgotPassword = lazy(() => import("./pages/ForgotPassword"));
const ResetPassword = lazy(() => import("./pages/ResetPassword"));

const Activity = lazy(() => import("./pages/Activity"));
const SavedContent = lazy(() => import("./pages/SavedContent"));
const QuizPage = lazy(() => import("./pages/QuizPage"));
const Result = lazy(() => import("./pages/Result"));
const Scoreboard = lazy(() => import("./pages/Scoreboard"));
const Admin = lazy(() => import("./pages/Admin"));
const PyqUploader = lazy(() => import("./pages/PyqUploader"));
const Leaderboard = lazy(() => import("./pages/Leaderboard"));
const Profile = lazy(() => import("./pages/Profile"));
const Blog = lazy(() => import("./pages/Blog"));
const BlogPost = lazy(() => import("./pages/BlogPost"));
const BlogAdmin = lazy(() => import("./pages/BlogAdmin"));
const Settings = lazy(() => import("./pages/Settings"));
const AttemptReview = lazy(() => import("./pages/AttemptReview"));
const Community = lazy(() => import("./pages/Community"));
const MemberApprovals = lazy(() => import("./pages/MemberApprovals"));
const DailyQuiz = lazy(() => import("./pages/DailyQuiz"));
const WeeklyMock = lazy(() => import("./pages/WeeklyMock"));
const DailyCurrentAffairs = lazy(() => import("./pages/DailyCurrentAffairs"));
const PrevPaperCategories = lazy(() => import("./pages/PrevPapers").then(m => ({ default: m.PrevPaperCategories })));
const PrevPaperExams = lazy(() => import("./pages/PrevPapers").then(m => ({ default: m.PrevPaperExams })));
const PrevPaperListPage = lazy(() => import("./pages/PrevPapers").then(m => ({ default: m.PrevPaperListPage })));
const NotFound = lazy(() => import("./pages/NotFound"));

const queryClient = new QueryClient({ defaultOptions: { queries: queryDefaults } });

const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, loading } = useAuth();
  if (loading) return <div className="min-h-screen flex items-center justify-center text-muted-foreground">Loading...</div>;
  if (!user) return <Navigate to="/auth" replace />;
  return <>{children}</>;
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Suspense fallback={<div className="min-h-screen flex items-center justify-center text-muted-foreground">Loading...</div>}>
            <Routes>
              <Route path="/" element={<ProtectedRoute><Navigate to="/home" replace /></ProtectedRoute>} />
              <Route path="/home" element={<ProtectedRoute><Home /></ProtectedRoute>} />
              <Route path="/auth" element={<Auth />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/reset-password" element={<ResetPassword />} />

              <Route path="/dashboard" element={<Navigate to="/home" replace />} />
              <Route path="/approvals" element={<ProtectedRoute><MemberApprovals /></ProtectedRoute>} />
              <Route path="/activity" element={<ProtectedRoute><Activity /></ProtectedRoute>} />
              <Route path="/saved/:kind" element={<ProtectedRoute><SavedContent /></ProtectedRoute>} />
              <Route path="/quiz/:id" element={<ProtectedRoute><QuizPage /></ProtectedRoute>} />
              <Route path="/result" element={<ProtectedRoute><Result /></ProtectedRoute>} />
              <Route path="/scoreboard" element={<ProtectedRoute><Scoreboard /></ProtectedRoute>} />
              <Route path="/admin" element={<ProtectedRoute><Admin /></ProtectedRoute>} />
              <Route path="/pyq-upload" element={<ProtectedRoute><PyqUploader /></ProtectedRoute>} />
              <Route path="/leaderboard/:quizId" element={<ProtectedRoute><Leaderboard /></ProtectedRoute>} />
              <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
              <Route path="/blog" element={<ProtectedRoute><Blog /></ProtectedRoute>} />
              <Route path="/blog/:id" element={<ProtectedRoute><BlogPost /></ProtectedRoute>} />
              <Route path="/blog-admin" element={<ProtectedRoute><BlogAdmin /></ProtectedRoute>} />
              <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
              <Route path="/attempt/:attemptId" element={<ProtectedRoute><AttemptReview /></ProtectedRoute>} />
              <Route path="/community" element={<ProtectedRoute><Community /></ProtectedRoute>} />
              <Route path="/daily-quiz" element={<ProtectedRoute><DailyQuiz /></ProtectedRoute>} />
              <Route path="/weekly-mock" element={<ProtectedRoute><WeeklyMock /></ProtectedRoute>} />
              <Route path="/daily-current-affairs" element={<ProtectedRoute><DailyCurrentAffairs /></ProtectedRoute>} />
              <Route path="/prev-papers" element={<ProtectedRoute><PrevPaperCategories /></ProtectedRoute>} />
              <Route path="/prev-papers/:category" element={<ProtectedRoute><PrevPaperExams /></ProtectedRoute>} />
              <Route path="/prev-papers/:category/:exam" element={<ProtectedRoute><PrevPaperListPage /></ProtectedRoute>} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Suspense>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
