import "./lib/polyfills";
import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

// Restore theme preference
if (localStorage.getItem("theme") === "dark") {
  document.documentElement.classList.add("dark");
}

const root = document.getElementById("root");
if (root) createRoot(root).render(<App />);
