import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.trust',
  appName: 'Trust',
  webDir: 'dist',
  server: {
    url: 'https://516c9c2f-6edb-4406-b987-f43247cef0af.lovableproject.com?forceHideBadge=true',
    cleartext: true
  }
};

export default config;
