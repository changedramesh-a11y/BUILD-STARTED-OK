## Goal
Refresh the UI of 5 key flows to match Testbook + Gradeup style (clean white, dark header bar, blue/green accent dots, card-based lists). Backend, data model, scoring, and routing stay exactly the same.

## Scope (UI-only changes)

### 1. Quiz Page (`src/pages/QuizPage.tsx`)
- Dark slim header bar: timer (HH:MM:SS), quiz title underneath, SUBMIT on right
- Numbered question-status bubbles row (1,2,3...) showing answered (blue filled), current (gray), unseen (outline)
- Small meta strip: per-question timer, `+1.0` green chip, `-0.25` red chip, report (⚠) icon, bookmark icon
- Options as numbered (1./2./3./4.) bordered cards with selected = blue border + light blue fill
- Sticky bottom bar with **Previous** (outline) and **Next** (blue) buttons

### 2. Result / Scorecard (`src/pages/Result.tsx`)
- Blue gradient hero with "Thank you for taking Quiz" + medal/trophy illustration
- White card "Your Rank" with rank chip (EXCELLENT/GOOD) — derived from percentage (no leaderboard backend change needed; show percentage-based label)
- Stats card: Correct / Wrong / Skipped big numbers + Attempts, Marks, Accuracy, Speed row with emoji icons
- White "Solutions" CTA button (navigates to attempt review)
- Keep existing Share scorecard + Continue buttons below

### 3. Attempt Review = "Reattempt Mode" (`src/pages/AttemptReview.tsx`)
- Same dark header with "Analysis" label on right
- Numbered bubbles row showing green (correct) / red (wrong) per question
- Each option card: correct answer highlighted in green with ✓; show "Correct Answers Is: X" and "X% got this right" line
- Solution / Explanation block below
- Bottom bar with **Reattempt Mode** toggle + arrow nav

### 4. Dashboard / Exam Preference (`src/pages/Dashboard.tsx`)
- Top dark bar: hamburger, "My Exams" with count chip, search & bell icons
- "Enrolled Test Series" horizontal scroll cards (pastel purple bg, icon, title, progress bar, x/y count)
- Quick-action icon row: Study Notes, Live Test, Live Quizzes, Rankers Tests, Prev. Papers — circular pastel icon tiles with NEW/FREE badges
- "All Your Attempted Tests" pill button
- "New Test Series" section with white cards
- Bottom tab bar: Home, Tests, Super, Pass, Super Pass, PYP's (visual only — Home + Tests wired, others show "Coming soon" toast)

### 5. Categories / All Exams listing
- Restyle exam category listing using the same card pattern (icon + title + meta + progress)

## Design tokens (add to `src/index.css`)
- `--header-bg: 0 0% 7%` (near-black bar)
- `--accent-blue: 217 91% 60%`
- `--accent-green: 142 71% 45%`
- `--accent-red: 0 84% 60%`
- Pastel surface: `--surface-lilac`, `--surface-mint`, `--surface-peach`
- Soft card shadow

## Out of scope
- No DB schema changes, no edge function changes, no scoring changes
- No new routes, no auth changes, bottom-tab "Super/Pass/PYP's" are placeholders
- "Rank" on result is a label derived from %, not a real cohort rank (avoids extra queries)

## Files touched
- `src/index.css` (tokens)
- `src/pages/QuizPage.tsx`
- `src/pages/Result.tsx`
- `src/pages/AttemptReview.tsx`
- `src/pages/Dashboard.tsx`
- New: `src/components/BottomTabBar.tsx`, `src/components/QuestionBubbles.tsx`

Ready to build on approval.