# Architecture rules

- Recently Uploaded hides opened test/note/paper IDs in user-scoped device storage only; opening never creates attempts/saves or alters source lists and permissions.

- Attempted test cards show latest score centrally and use the result screen's best-per-user percentage/earliest-attempt ordering for rank through existing user-scoped read access.

- Home and Study Notes subscribe to the shared persisted exam-mode store and key queries by mode; paper feeds filter by examination category because papers have no exam_mode column.

- Keep query caches memory-only, user-scoped and short-lived; clear them on account changes/logout and invalidate affected lists after writes so caching never crosses accounts or hides completed attempts.
- Load the browser PDF engine only when opening a paper; retain the lightweight Android handoff without downloading PDF.js, and memoize near-viewport page shells to avoid repainting every page on scroll.
- Optimize uploaded raster images only when the result is smaller, preserve full-resolution note diagrams, and defer offscreen image decoding without changing content or navigation.

- Optional mock sections are validated quiz JSON; timed mock attempts follow absolute sequential section deadlines, lock navigation to the active section, and checkpoint answers in user/quiz-scoped local drafts until final server-scored submission. Nonsectioned tests retain overall timing.
- Use the shared mock deletion control and admin-validated security-invoker delete_mock transaction to remove attempts/questions before a mock; existing row policies remain enforced.

- AI study notes are staff-authorized server-generated drafts; reuse blog publication and student readers, and keep blocked AI service state server-only to prevent repeated denied calls.
- AI notes persist unrestricted Markdown tables, validated mind-map outlines and final PNG images in existing article content; image uploads use validated PNG/JPEG/WebP data blocks, avoiding new storage permissions and keeping preview and publication identical. Legacy outlines render as downloadable PNGs.

- All paper entry points use the shared PDF reader: browsers get the PDF.js in-app reader; Android WebView (APK wrappers) gets a short-lived signed attachment URL handed to the device PDF app, since WebViews cannot reliably render or save blobs.
- PDF pages scroll continuously with near-viewport canvas rendering and focal-point touch zoom, keeping long papers usable without rendering every page at once.

- Saved collections use user-owned quiz/paper bookmarks and the existing saved notes table through one shared save control; keep saves separate from attempts and source visibility.
- Daily quizzes and weekly mocks share a listing component keyed by publication type and exam preference, with no date cutoff so historical published tests remain accessible.
- Activity reuses the dashboard's test cards and filters by the signed-in user's attempts and saved notes; keep published browsing on the existing content pages so personal history stays separate.
- Home is the signed-in startup destination; aggregate existing published content by exam preference and upload date without changing source permissions, and link feed entries to their existing readers.
- Keep `has_role` executable for authenticated row-security checks, scoped to `auth.uid()`; anonymous calls and querying other users' roles must remain blocked.
- Role-access integration tests use the injected owner session and skip when absent, so credentials never enter source files.
- Daily current affairs uses the existing stories feed and shared Embla carousel, preserving exam preference and publication visibility without timed auto-advance so articles remain readable.
- Store previous-year papers separately from quizzes, with private PDF storage and staff-only upload policies; original papers must not require question extraction.- Previous-year paper sections and exam names come from one shared catalog used by both the uploader and the student browse pages, so uploads always land under the right exam.
- Shared comments, community posts/replies, notices and paper PDFs are readable only by admin-approved members (member_approvals, staff implicit) because sign-up is open; admins approve on /approvals.
