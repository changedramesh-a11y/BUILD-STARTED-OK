DROP POLICY IF EXISTS "Authenticated can view blog comments" ON public.blog_comments;
CREATE POLICY "Authenticated can view blog comments" ON public.blog_comments FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);
DROP POLICY IF EXISTS "Authenticated can view community replies" ON public.community_replies;
CREATE POLICY "Authenticated can view community replies" ON public.community_replies FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);
DROP POLICY IF EXISTS "Authenticated can view comments" ON public.quiz_comments;
CREATE POLICY "Authenticated can view comments" ON public.quiz_comments FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);
DROP POLICY IF EXISTS "Authenticated can view community posts" ON public.community_posts;
CREATE POLICY "Authenticated can view community posts" ON public.community_posts FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);
DROP POLICY IF EXISTS "Signed-in users read previous year papers" ON public.previous_year_papers;
CREATE POLICY "Signed-in users read previous year papers" ON public.previous_year_papers FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);
DROP POLICY IF EXISTS "Signed-in users read notices" ON public.notices;
CREATE POLICY "Signed-in users read notices" ON public.notices FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);
DROP POLICY IF EXISTS "Signed-in users read paper PDFs" ON storage.objects;
CREATE POLICY "Signed-in users read paper PDFs" ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'previous-year-papers' AND auth.uid() IS NOT NULL
  AND EXISTS (SELECT 1 FROM public.previous_year_papers p WHERE p.file_path = storage.objects.name));