CREATE TABLE public.saved_quizzes (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL DEFAULT auth.uid(),
 quiz_id uuid NOT NULL REFERENCES public.quizzes(id) ON DELETE CASCADE,
 created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE (user_id, quiz_id)
);
GRANT SELECT, INSERT, DELETE ON public.saved_quizzes TO authenticated;
GRANT ALL ON public.saved_quizzes TO service_role;
ALTER TABLE public.saved_quizzes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Read own saved quizzes" ON public.saved_quizzes FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "Save accessible published quizzes" ON public.saved_quizzes FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid() AND EXISTS (SELECT 1 FROM public.quizzes q WHERE q.id = quiz_id AND q.is_published));
CREATE POLICY "Remove own saved quizzes" ON public.saved_quizzes FOR DELETE TO authenticated USING (user_id = auth.uid());
CREATE TABLE public.saved_papers (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL DEFAULT auth.uid(),
 paper_id uuid NOT NULL REFERENCES public.previous_year_papers(id) ON DELETE CASCADE,
 created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE (user_id, paper_id)
);
GRANT SELECT, INSERT, DELETE ON public.saved_papers TO authenticated;
GRANT ALL ON public.saved_papers TO service_role;
ALTER TABLE public.saved_papers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Read own saved papers" ON public.saved_papers FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "Save accessible papers" ON public.saved_papers FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid() AND EXISTS (SELECT 1 FROM public.previous_year_papers p WHERE p.id = paper_id));
CREATE POLICY "Remove own saved papers" ON public.saved_papers FOR DELETE TO authenticated USING (user_id = auth.uid());