ALTER TABLE public.quizzes DROP CONSTRAINT quizzes_type_check;
ALTER TABLE public.quizzes ADD CONSTRAINT quizzes_type_check CHECK (type = ANY (ARRAY['quiz','mock','weekly_mock','daily_quiz','pyq']));