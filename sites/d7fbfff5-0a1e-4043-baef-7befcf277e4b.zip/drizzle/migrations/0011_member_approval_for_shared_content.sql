CREATE TABLE public.member_approvals (
  user_id uuid PRIMARY KEY,
  approved_by uuid,
  approved_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, DELETE ON public.member_approvals TO authenticated;
GRANT ALL ON public.member_approvals TO service_role;
ALTER TABLE public.member_approvals ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own approval or admin read" ON public.member_approvals FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "Admins approve" ON public.member_approvals FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role) AND approved_by = auth.uid());
CREATE POLICY "Admins revoke" ON public.member_approvals FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::public.app_role));

INSERT INTO public.member_approvals (user_id) SELECT user_id FROM public.profiles ON CONFLICT DO NOTHING;

CREATE OR REPLACE FUNCTION public.is_approved_member()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public' AS $$
  SELECT auth.uid() IS NOT NULL AND (
    EXISTS (SELECT 1 FROM public.member_approvals WHERE user_id = auth.uid())
    OR EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role IN ('admin','moderator'))
  );
$$;
REVOKE EXECUTE ON FUNCTION public.is_approved_member() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_approved_member() TO authenticated;

ALTER POLICY "Authenticated can view comments" ON public.quiz_comments USING (public.is_approved_member());
ALTER POLICY "Authenticated can view community posts" ON public.community_posts USING (public.is_approved_member());
ALTER POLICY "Authenticated can view community replies" ON public.community_replies USING (public.is_approved_member());
ALTER POLICY "Authenticated can view blog comments" ON public.blog_comments USING (public.is_approved_member());
ALTER POLICY "Signed-in users read notices" ON public.notices USING (public.is_approved_member());
ALTER POLICY "Signed-in users read previous year papers" ON public.previous_year_papers USING (public.is_approved_member());
ALTER POLICY "Signed-in users read paper PDFs" ON storage.objects USING (bucket_id = 'previous-year-papers' AND public.is_approved_member() AND EXISTS (SELECT 1 FROM public.previous_year_papers p WHERE p.file_path = objects.name));