CREATE OR REPLACE FUNCTION public.admin_list_members()
RETURNS TABLE(user_id uuid, display_name text, email text, approved boolean, created_at timestamptz)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin'::public.app_role) THEN RAISE EXCEPTION 'Admin access required'; END IF;
  RETURN QUERY SELECT p.user_id, p.display_name, p.email,
    EXISTS (SELECT 1 FROM public.member_approvals m WHERE m.user_id = p.user_id), p.created_at
  FROM public.profiles p ORDER BY 4, p.created_at DESC;
END; $$;
REVOKE EXECUTE ON FUNCTION public.admin_list_members() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_list_members() TO authenticated;