ALTER TABLE public.previous_year_papers ADD COLUMN category text NOT NULL DEFAULT 'other';
CREATE POLICY "Signed-in users read previous year papers" ON public.previous_year_papers FOR SELECT TO authenticated USING (true);
CREATE POLICY "Signed-in users read paper PDFs" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'previous-year-papers');