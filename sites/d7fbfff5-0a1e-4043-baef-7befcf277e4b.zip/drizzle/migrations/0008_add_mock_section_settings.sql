CREATE FUNCTION public.valid_mock_sections(value jsonb)
RETURNS boolean LANGUAGE plpgsql IMMUTABLE SET search_path = public AS $$
DECLARE item jsonb;
BEGIN
  IF jsonb_typeof(value) <> 'array' THEN RETURN false; END IF;
  IF jsonb_array_length(value) > 5 THEN RETURN false; END IF;
  FOR item IN SELECT jsonb_array_elements(value) LOOP
    IF jsonb_typeof(item) <> 'object' OR jsonb_typeof(item->'name') IS DISTINCT FROM 'string' OR btrim(item->>'name') = '' OR jsonb_typeof(item->'duration_minutes') IS DISTINCT FROM 'number' THEN RETURN false; END IF;
    IF (item->>'duration_minutes')::numeric < 1 OR trunc((item->>'duration_minutes')::numeric) <> (item->>'duration_minutes')::numeric THEN RETURN false; END IF;
  END LOOP;
  RETURN true;
END;
$$;
ALTER TABLE public.quizzes ADD COLUMN sections jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE public.quizzes ADD CONSTRAINT quizzes_sections_valid CHECK (public.valid_mock_sections(sections) AND (type IN ('mock', 'weekly_mock') OR sections = '[]'::jsonb));