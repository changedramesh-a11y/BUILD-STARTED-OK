CREATE OR REPLACE FUNCTION public.admin_list_members()
RETURNS TABLE(user_id uuid, display_name text, email text, approved boolean, created_at timestamptz)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin'::public.app_role) THEN RAISE EXCEPTION 'Admin access required'; END IF;
  RETURN QUERY SELECT u.id, COALESCE(p.display_name, split_part(u.email::text,'@',1))::text, u.email::text,
    EXISTS (SELECT 1 FROM public.member_approvals m WHERE m.user_id = u.id), u.created_at
  FROM auth.users u LEFT JOIN public.profiles p ON p.user_id = u.id ORDER BY 4, u.created_at DESC;
END; $$;