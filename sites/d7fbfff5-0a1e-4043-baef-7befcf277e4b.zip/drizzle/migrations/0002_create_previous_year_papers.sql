CREATE TABLE public.previous_year_papers (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 exam_name text NOT NULL CHECK (length(trim(exam_name)) > 0),
 year integer NOT NULL CHECK (year BETWEEN 1900 AND 9999),
 file_path text NOT NULL UNIQUE,
 file_name text NOT NULL,
 uploaded_by uuid NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, DELETE ON public.previous_year_papers TO authenticated;
GRANT ALL ON public.previous_year_papers TO service_role;
ALTER TABLE public.previous_year_papers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff read previous year papers" ON public.previous_year_papers FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'moderator'));
CREATE POLICY "Staff upload previous year papers" ON public.previous_year_papers FOR INSERT TO authenticated WITH CHECK (uploaded_by = auth.uid() AND split_part(file_path, '/', 1) = auth.uid()::text AND (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'moderator')));
CREATE POLICY "Staff delete own previous year papers" ON public.previous_year_papers FOR DELETE TO authenticated USING (uploaded_by = auth.uid() AND (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'moderator')));
CREATE POLICY "Staff upload paper PDFs" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'previous-year-papers' AND (storage.foldername(name))[1] = auth.uid()::text AND lower(storage.extension(name)) = 'pdf' AND (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'moderator')));
CREATE POLICY "Staff read paper PDFs" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'previous-year-papers' AND (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'moderator')));
CREATE POLICY "Staff remove own paper PDFs" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'previous-year-papers' AND (storage.foldername(name))[1] = auth.uid()::text AND (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'moderator')));