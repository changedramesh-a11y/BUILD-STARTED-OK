import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { extractText } from "https://esm.sh/unpdf@0.12.1";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Auth: require admin or moderator (only admins create quizzes)
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const userClient = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: authHeader } } });
    const { data: { user }, error: userErr } = await userClient.auth.getUser();
    if (userErr || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const { data: roleRow } = await userClient
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .in("role", ["admin", "moderator"])
      .maybeSingle();
    if (!roleRow) {
      return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      console.error("extract-questions: missing LOVABLE_API_KEY");
      return new Response(JSON.stringify({ error: "Service temporarily unavailable" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const contentType = req.headers.get("content-type") || "";
    let pdfText = "";

    if (contentType.includes("multipart/form-data")) {
      // Handle binary PDF upload
      const formData = await req.formData();
      const file = formData.get("file");

      if (!file || !(file instanceof File)) {
        return new Response(JSON.stringify({ error: "No PDF file provided" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (file.size > 15 * 1024 * 1024) {
        return new Response(JSON.stringify({ error: "PDF too large. Maximum 15MB." }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      console.log("Extracting text from PDF using unpdf, size:", file.size);
      const buffer = await file.arrayBuffer();
      const result = await extractText(new Uint8Array(buffer), { mergePages: true });
      pdfText = result.text || "";
      console.log("Extracted text length:", pdfText.length);

      if (pdfText.trim().length < 20) {
        // Fallback: try vision API for scanned PDFs
        console.log("Text extraction minimal, trying vision API for scanned PDF");
        const bytes = new Uint8Array(buffer);
        let binary = "";
        const chunk = 0x8000;
        for (let i = 0; i < bytes.length; i += chunk) {
          binary += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + chunk)));
        }
        const base64Pdf = btoa(binary);

        const visionResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${LOVABLE_API_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: "google/gemini-2.5-flash",
            messages: [
              {
                role: "user",
                content: [
                  { type: "text", text: "Extract ALL text from this PDF document. Preserve the structure of questions, options, and answers." },
                  {
                    type: "image_url",
                    image_url: { url: `data:application/pdf;base64,${base64Pdf}` },
                  },
                ],
              },
            ],
          }),
        });

        if (visionResponse.ok) {
          const visionData = await visionResponse.json();
          pdfText = visionData.choices?.[0]?.message?.content || "";
          console.log("Vision API text length:", pdfText.length);
        }
      }
    } else {
      // Handle JSON body with pdfText (legacy)
      const body = await req.json();
      pdfText = body.pdfText || "";
    }

    if (!pdfText || typeof pdfText !== "string" || pdfText.trim().length < 10) {
      return new Response(JSON.stringify({ error: "Could not extract text from PDF. Try a text-based PDF." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Limit text to stay within token budgets
    pdfText = pdfText.slice(0, 40000);

    const systemPrompt = `You are an expert question extractor for competitive exam preparation (SSC, Railway, etc.).

Given the text extracted from a PDF, extract ALL multiple-choice questions with their options (A, B, C, D) and the correct answer.

You MUST respond by calling the extract_questions function with the extracted data. Do not respond with plain text.

Rules:
- Each question must have exactly 4 options: A, B, C, D
- Identify the correct option. If the PDF indicates the answer, use that. If not, determine the correct answer yourself.
- Clean up any formatting issues from the PDF extraction
- Preserve the original question text as closely as possible
- If a question doesn't have clear 4 options, skip it`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: `Extract all MCQ questions from the following PDF text:\n\n${pdfText}` },
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "extract_questions",
              description: "Extract multiple choice questions from text",
              parameters: {
                type: "object",
                properties: {
                  questions: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        question_text: { type: "string", description: "The question text" },
                        option_a: { type: "string", description: "Option A" },
                        option_b: { type: "string", description: "Option B" },
                        option_c: { type: "string", description: "Option C" },
                        option_d: { type: "string", description: "Option D" },
                        correct_option: {
                          type: "string",
                          enum: ["A", "B", "C", "D"],
                          description: "The correct option letter",
                        },
                      },
                      required: ["question_text", "option_a", "option_b", "option_c", "option_d", "correct_option"],
                      additionalProperties: false,
                    },
                  },
                },
                required: ["questions"],
                additionalProperties: false,
              },
            },
          },
        ],
        tool_choice: { type: "function", function: { name: "extract_questions" } },
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limited. Please try again in a moment." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add funds." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errText = await response.text();
      console.error("AI gateway error:", response.status, errText);
      return new Response(JSON.stringify({ error: "AI processing failed" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await response.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];

    if (!toolCall || toolCall.function.name !== "extract_questions") {
      return new Response(JSON.stringify({ error: "AI did not return structured questions" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const extracted = JSON.parse(toolCall.function.arguments);

    return new Response(JSON.stringify(extracted), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("extract-questions error:", e);
    return new Response(JSON.stringify({ error: "PDF extraction failed. Please try again." }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
