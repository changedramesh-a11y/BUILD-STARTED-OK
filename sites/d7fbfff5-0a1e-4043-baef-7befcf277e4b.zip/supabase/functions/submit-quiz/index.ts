import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.2";
import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    // Validate auth
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // User client to get user identity
    const userClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user }, error: userError } = await userClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Parse and validate input
    const body = await req.json();
    const quizId = body.quiz_id;
    const answers = body.answers; // Record<questionId, selectedOption>

    if (!quizId || typeof quizId !== "string") {
      return new Response(JSON.stringify({ error: "quiz_id is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!answers || typeof answers !== "object" || Array.isArray(answers)) {
      return new Response(JSON.stringify({ error: "answers must be an object" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Service role client for privileged operations
    const adminClient = createClient(supabaseUrl, supabaseServiceKey);

    // Fetch quiz scoring settings
    const { data: quiz, error: quizErr } = await adminClient
      .from("quizzes")
      .select("marks_per_question, negative_marks, max_attempts, is_published")
      .eq("id", quizId)
      .maybeSingle();
    if (quizErr || !quiz || quiz.is_published !== true) {
      return new Response(JSON.stringify({ error: "Quiz not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const marksPerQuestion = Number(quiz.marks_per_question ?? 1);
    const negativeMarks = Number(quiz.negative_marks ?? 0.25);
    const maxAttempts = Number(quiz.max_attempts ?? 0); // 0 = unlimited

    // Enforce max attempts. If unlimited, replace previous to keep one row.
    const { data: prior, error: priorErr } = await adminClient
      .from("attempts")
      .select("id")
      .eq("user_id", user.id)
      .eq("quiz_id", quizId);
    if (priorErr) {
      return new Response(JSON.stringify({ error: "Failed to check attempts" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const priorCount = prior?.length ?? 0;
    if (maxAttempts === 0) {
      // Unlimited: keep only latest by deleting previous
      await adminClient.from("attempts").delete().eq("user_id", user.id).eq("quiz_id", quizId);
    } else if (priorCount >= maxAttempts) {
      return new Response(
        JSON.stringify({ error: `Attempt limit reached (${maxAttempts} allowed)` }),
        { status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Fetch questions with correct answers server-side
    const { data: questions, error: qError } = await adminClient
      .from("questions")
      .select("id, correct_option")
      .eq("quiz_id", quizId);

    if (qError || !questions || questions.length === 0) {
      return new Response(JSON.stringify({ error: "Quiz not found or has no questions" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Calculate score server-side using per-quiz marking scheme
    let score = 0;
    const totalQuestions = questions.length;
    for (const q of questions) {
      if (answers[q.id] === q.correct_option) {
        score += marksPerQuestion;
      } else if (answers[q.id]) {
        score -= negativeMarks;
      }
    }
    score = Math.max(0, parseFloat(score.toFixed(2)));
    const maxScore = totalQuestions * marksPerQuestion;
    const percentage = maxScore > 0 ? Math.round((score / maxScore) * 100) : 0;

    // Insert attempt with service role and return its id for direct review navigation
    const { data: insertedAttempt, error: insertError } = await adminClient.from("attempts").insert({
      user_id: user.id,
      quiz_id: quizId,
      score,
      total_questions: totalQuestions,
      max_marks: maxScore,
      percentage,
      answers,
    }).select("id").single();

    if (insertError) {
      return new Response(JSON.stringify({ error: "Failed to save attempt" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(
      JSON.stringify({ score, totalQuestions, maxMarks: maxScore, percentage, attemptId: insertedAttempt?.id }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
