export interface NoteMindMap {
  topic: string;
  branches: { label: string; facts: string[] }[];
}

export function isMindMapImage(value: string): boolean {
  return /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(value) && value.length <= 4_000_000;
}

export function withMindMapImage(content: string, image: string): string {
  if (!isMindMapImage(image)) throw new Error("Choose a PNG, JPEG or WebP mind-map image under 3 MB.");
  const withoutImage = content.replace(/\n*```mindmap-image\s*\n[\s\S]*?\n```\s*$/, "").trim();
  return `${withoutImage}\n\n\`\`\`mindmap-image\n${image}\n\`\`\``;
}

export function extractMindMap(content: string): { body: string; map: NoteMindMap | null; image?: string } {
  const imageMatch = /```mindmap-image\s*\n([\s\S]*?)\n```\s*$/.exec(content);
  if (imageMatch && isMindMapImage(imageMatch[1].trim())) {
    return { ...extractMindMap(content.slice(0, imageMatch.index).trim()), image: imageMatch[1].trim() };
  }
  const match = /```mindmap\s*\n([\s\S]*?)\n```\s*$/.exec(content);
  if (!match) return { body: content, map: null };
  try {
    const map = JSON.parse(match[1]);
    if (typeof map.topic !== "string" || !map.topic.trim() || map.topic.length > 120 || !Array.isArray(map.branches) || map.branches.length < 3 || map.branches.length > 6) throw new Error();
    for (const branch of map.branches) {
      if (typeof branch.label !== "string" || !branch.label.trim() || branch.label.length > 90 || !Array.isArray(branch.facts) || branch.facts.length < 1 || branch.facts.length > 4 || branch.facts.some((fact: unknown) => typeof fact !== "string" || !fact.trim() || fact.length > 120)) throw new Error();
    }
    return { body: content.slice(0, match.index).trim(), map };
  } catch { return { body: content, map: null }; }
}

export function requireMindMap(content: string): void {
  const { map, image } = extractMindMap(content);
  if (!map && !image) throw new Error("Every AI article needs a complete final mind map. Generate the notes again or upload a mind-map image before publishing.");
}