// Generate a short daily news story for govt-exam aspirants via Lovable AI
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.2";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });

  try {
    // Require authenticated admin/moderator (story creation is admin-gated in UI)
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...CORS, "Content-Type": "application/json" } });
    }
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const userClient = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: authHeader } } });
    const { data: { user }, error: userErr } = await userClient.auth.getUser();
    if (userErr || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...CORS, "Content-Type": "application/json" } });
    }
    const { data: roleRow } = await userClient
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .in("role", ["admin", "moderator"])
      .maybeSingle();
    if (!roleRow) {
      return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers: { ...CORS, "Content-Type": "application/json" } });
    }

    const { topic, examMode } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      console.error("generate-news-story: missing LOVABLE_API_KEY");
      return new Response(JSON.stringify({ error: "Service temporarily unavailable" }), { status: 500, headers: { ...CORS, "Content-Type": "application/json" } });
    }

    const prompt = `Write a short daily news/current-affairs story for Indian government job (${examMode === "jharkhand" ? "Jharkhand state" : "Central"}) exam aspirants.
Topic / hint: ${topic || "today's most important current affairs"}.
Return JSON with two fields:
- "title": a punchy headline under 80 characters
- "content": 3-5 short crisp bullet points (each on a new line, prefixed with •) covering what, when, where, why-it-matters for the exam. Total under 600 characters. Indian English. No markdown bold.`;

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: "You are a current-affairs editor for Indian government exam aspirants. Always respond with valid JSON only, no prose, no code fences." },
          { role: "user", content: prompt },
        ],
      }),
    });

    if (res.status === 429) return new Response(JSON.stringify({ error: "Rate limit, try again shortly" }), { status: 429, headers: { ...CORS, "Content-Type": "application/json" } });
    if (res.status === 402) return new Response(JSON.stringify({ error: "AI credits exhausted" }), { status: 402, headers: { ...CORS, "Content-Type": "application/json" } });
    if (!res.ok) throw new Error(`AI gateway error: ${res.status}`);

    const data = await res.json();
    let text: string = data?.choices?.[0]?.message?.content ?? "";
    text = text.replace(/^```json\s*/i, "").replace(/```$/i, "").trim();

    let parsed: { title: string; content: string };
    try {
      parsed = JSON.parse(text);
    } catch {
      parsed = { title: "Daily News Update", content: text };
    }

    return new Response(JSON.stringify(parsed), { headers: { ...CORS, "Content-Type": "application/json" } });
  } catch (e) {
    console.error("generate-news-story error:", e);
    return new Response(JSON.stringify({ error: "Story generation failed. Please try again." }), { status: 500, headers: { ...CORS, "Content-Type": "application/json" } });
  }
});
