-- Community posts (image questions) and image replies
CREATE TABLE public.community_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  caption text NOT NULL DEFAULT '',
  image_url text NOT NULL,
  exam_mode text NOT NULL DEFAULT 'central',
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.community_posts TO authenticated;
GRANT ALL ON public.community_posts TO service_role;

ALTER TABLE public.community_posts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can view community posts"
ON public.community_posts FOR SELECT TO authenticated USING (true);

CREATE POLICY "Users can create own community posts"
ON public.community_posts FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own community posts"
ON public.community_posts FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "Admins manage community posts"
ON public.community_posts FOR ALL TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Moderators manage community posts"
ON public.community_posts FOR ALL TO authenticated
USING (has_role(auth.uid(), 'moderator'::app_role))
WITH CHECK (has_role(auth.uid(), 'moderator'::app_role));

CREATE TABLE public.community_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES public.community_posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  caption text NOT NULL DEFAULT '',
  image_url text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.community_replies TO authenticated;
GRANT ALL ON public.community_replies TO service_role;

ALTER TABLE public.community_replies ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can view community replies"
ON public.community_replies FOR SELECT TO authenticated USING (true);

CREATE POLICY "Users can create own community replies"
ON public.community_replies FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own community replies"
ON public.community_replies FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "Admins manage community replies"
ON public.community_replies FOR ALL TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Moderators manage community replies"
ON public.community_replies FOR ALL TO authenticated
USING (has_role(auth.uid(), 'moderator'::app_role))
WITH CHECK (has_role(auth.uid(), 'moderator'::app_role));

CREATE INDEX idx_community_replies_post ON public.community_replies(post_id, created_at);
CREATE INDEX idx_community_posts_created ON public.community_posts(created_at DESC);

-- Storage bucket for community images
INSERT INTO storage.buckets (id, name, public) VALUES ('community', 'community', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Community images publicly viewable"
ON storage.objects FOR SELECT USING (bucket_id = 'community');

CREATE POLICY "Users upload community images to own folder"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'community' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users delete own community images"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'community' AND auth.uid()::text = (storage.foldername(name))[1]);
