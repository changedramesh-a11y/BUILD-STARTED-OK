
-- 1. Fix profiles: restrict SELECT to own profile only
DROP POLICY IF EXISTS "Authenticated users can view all profiles" ON public.profiles;
CREATE POLICY "Users can view own profile"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- 2. Fix questions: create view without correct_option, restrict base table
CREATE OR REPLACE VIEW public.public_questions AS
  SELECT id, quiz_id, question_text, option_a, option_b, option_c, option_d, created_at
  FROM public.questions;

GRANT SELECT ON public.public_questions TO anon, authenticated;

DROP POLICY IF EXISTS "Anyone can view questions" ON public.questions;

-- 3. Fix user_roles: explicit restrictions for non-admins
-- Drop and recreate admin ALL policy scoped to authenticated
DROP POLICY IF EXISTS "Admins can manage roles" ON public.user_roles;
CREATE POLICY "Admins can manage roles"
  ON public.user_roles FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

-- Update SELECT policy to authenticated only
DROP POLICY IF EXISTS "Users can view own role" ON public.user_roles;
CREATE POLICY "Users can view own role"
  ON public.user_roles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- 4. Fix attempts: remove client INSERT, only service role can insert
DROP POLICY IF EXISTS "Users can create own attempts" ON public.attempts;
