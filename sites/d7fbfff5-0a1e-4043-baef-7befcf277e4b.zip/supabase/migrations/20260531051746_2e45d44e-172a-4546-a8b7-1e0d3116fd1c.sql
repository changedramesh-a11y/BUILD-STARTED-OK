ALTER TABLE public.quizzes ADD COLUMN IF NOT EXISTS max_attempts INTEGER NOT NULL DEFAULT 0;
-- 0 = infinite, otherwise N attempts allowed