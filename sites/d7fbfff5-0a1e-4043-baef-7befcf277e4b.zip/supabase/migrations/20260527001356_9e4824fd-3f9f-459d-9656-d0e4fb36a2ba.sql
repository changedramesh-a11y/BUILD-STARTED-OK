
CREATE TABLE public.quiz_comments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  quiz_id UUID NOT NULL,
  user_id UUID NOT NULL,
  content TEXT NOT NULL CHECK (char_length(content) > 0 AND char_length(content) <= 1000),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE INDEX idx_quiz_comments_quiz_id ON public.quiz_comments(quiz_id, created_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.quiz_comments TO authenticated;
GRANT ALL ON public.quiz_comments TO service_role;

ALTER TABLE public.quiz_comments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can view comments"
ON public.quiz_comments FOR SELECT TO authenticated USING (true);

CREATE POLICY "Users can post own comments"
ON public.quiz_comments FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own comments"
ON public.quiz_comments FOR UPDATE TO authenticated
USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own comments"
ON public.quiz_comments FOR DELETE TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Admins can delete any comment"
ON public.quiz_comments FOR DELETE TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Moderators can delete any comment"
ON public.quiz_comments FOR DELETE TO authenticated
USING (has_role(auth.uid(), 'moderator'::app_role));

CREATE TRIGGER update_quiz_comments_updated_at
BEFORE UPDATE ON public.quiz_comments
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
