ALTER TABLE public.attempts ADD COLUMN IF NOT EXISTS max_marks numeric NOT NULL DEFAULT 0;

UPDATE public.attempts a
SET max_marks = a.total_questions * COALESCE(q.marks_per_question, 1)
FROM public.quizzes q
WHERE q.id = a.quiz_id AND a.max_marks = 0;