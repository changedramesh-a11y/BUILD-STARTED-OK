REVOKE EXECUTE ON FUNCTION public.has_role(uuid, app_role) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.handle_new_user_profile() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.handle_new_user_role() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.update_updated_at_column() FROM PUBLIC;

REVOKE EXECUTE ON FUNCTION public.get_attempt_questions(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_attempt_questions(uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION public.get_public_profile(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_public_profile(uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION public.get_like_count(text, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_like_count(text, uuid) TO authenticated;