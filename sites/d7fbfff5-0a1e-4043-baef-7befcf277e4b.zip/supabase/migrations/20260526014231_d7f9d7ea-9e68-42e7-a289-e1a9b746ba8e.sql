
-- 1) Fix EXPOSED_CORRECT_ANSWERS: hide correct_option from clients via column-revoke and a view
REVOKE SELECT ON public.questions FROM anon, authenticated;
GRANT SELECT (id, quiz_id, question_text, option_a, option_b, option_c, option_d, created_at)
  ON public.questions TO authenticated;

-- 2) Fix has_role enumeration: only allow checking caller's own roles
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT _user_id = auth.uid() AND EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  );
$$;

-- 3) Tighten profiles policies: scope to authenticated role
DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;

CREATE POLICY "Users can insert own profile"
ON public.profiles FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own profile"
ON public.profiles FOR UPDATE TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- 4) Drop broad public listing policy on avatars (public bucket URLs still work via CDN)
DROP POLICY IF EXISTS "Avatar images are publicly accessible" ON storage.objects;
