
-- Create a view with only public fields
CREATE VIEW public.public_profiles AS
SELECT user_id, display_name, about, avatar_url
FROM public.profiles;

-- Grant access to the view
GRANT SELECT ON public.public_profiles TO anon, authenticated;
