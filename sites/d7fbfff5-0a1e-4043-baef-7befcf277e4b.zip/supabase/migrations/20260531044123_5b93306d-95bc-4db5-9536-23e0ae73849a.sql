ALTER TABLE public.quizzes
  ADD COLUMN IF NOT EXISTS marks_per_question numeric NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS negative_marks numeric NOT NULL DEFAULT 0.25;