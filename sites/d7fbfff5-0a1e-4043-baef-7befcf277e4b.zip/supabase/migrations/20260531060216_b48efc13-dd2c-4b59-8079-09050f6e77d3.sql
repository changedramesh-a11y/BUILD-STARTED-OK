
-- Fix: restrict likes SELECT to owner; expose only aggregate count via definer function
DROP POLICY IF EXISTS "Authenticated can view likes" ON public.likes;

CREATE POLICY "Users can view own likes"
ON public.likes
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.get_like_count(p_target_type text, p_target_id uuid)
RETURNS integer
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(COUNT(*), 0)::int
  FROM public.likes
  WHERE target_type = p_target_type AND target_id = p_target_id;
$$;

GRANT EXECUTE ON FUNCTION public.get_like_count(text, uuid) TO anon, authenticated;

-- Fix: add explicit SELECT deny on questions for non-admin/mod to clarify intent.
-- Admin/Moderator ALL policies already grant them access. Add no-op restrictive policy.
CREATE POLICY "Only admins and moderators can read questions directly"
ON public.questions
FOR SELECT
TO authenticated, anon
USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'moderator'::app_role));
