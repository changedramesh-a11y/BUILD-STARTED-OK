
-- Allow authenticated users to view all profiles (email/phone are protected by using the public_profiles view in code)
CREATE POLICY "Authenticated users can view all profiles"
ON public.profiles
FOR SELECT
TO authenticated
USING (true);

-- Drop the restrictive own-profile-only policy since the new one covers it
DROP POLICY "Users can view own profile" ON public.profiles;
