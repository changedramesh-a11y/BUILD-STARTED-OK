
-- 1) Prevent clients from reading correct_option on questions
REVOKE SELECT ON public.questions FROM anon, authenticated;
GRANT SELECT (id, quiz_id, question_text, option_a, option_b, option_c, option_d, created_at)
  ON public.questions TO authenticated;
GRANT ALL ON public.questions TO service_role;

-- 2) Lock down attempts: only the scoring edge function (service_role) may insert/update.
CREATE POLICY "Deny direct inserts on attempts"
ON public.attempts FOR INSERT TO authenticated
WITH CHECK (false);

CREATE POLICY "Deny direct updates on attempts"
ON public.attempts FOR UPDATE TO authenticated
USING (false) WITH CHECK (false);
