-- 1. Scope admin/moderator policies to authenticated role
DROP POLICY IF EXISTS "Admins can delete attempts for quiz cleanup" ON public.attempts;
DROP POLICY IF EXISTS "Moderators can delete attempts for quiz cleanup" ON public.attempts;
CREATE POLICY "Admins can delete attempts for quiz cleanup" ON public.attempts FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Moderators can delete attempts for quiz cleanup" ON public.attempts FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'moderator'));

DROP POLICY IF EXISTS "Admins can manage questions" ON public.questions;
DROP POLICY IF EXISTS "Moderators can manage questions" ON public.questions;
CREATE POLICY "Admins can manage questions" ON public.questions FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Moderators can manage questions" ON public.questions FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'moderator')) WITH CHECK (public.has_role(auth.uid(), 'moderator'));

DROP POLICY IF EXISTS "Admins can manage quizzes" ON public.quizzes;
DROP POLICY IF EXISTS "Moderators can manage quizzes" ON public.quizzes;
CREATE POLICY "Admins can manage quizzes" ON public.quizzes FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Moderators can manage quizzes" ON public.quizzes FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'moderator')) WITH CHECK (public.has_role(auth.uid(), 'moderator'));

-- 2. Remove broad bucket listing/read policies (public buckets still serve files via public URLs)
DROP POLICY IF EXISTS "Story images are public" ON storage.objects;
DROP POLICY IF EXISTS "Community images publicly viewable" ON storage.objects;
DROP POLICY IF EXISTS "Avatars read" ON storage.objects;

-- 3. Lock down SECURITY DEFINER function execution
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, app_role) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user_profile() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user_role() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.update_updated_at_column() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.get_attempt_questions(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION public.get_attempt_questions(uuid) TO authenticated;