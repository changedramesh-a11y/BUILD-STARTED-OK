-- 1) Fix has_role: remove the _user_id = auth.uid() guard so it works in any security-definer context
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  );
$$;

-- 2) Add owner-scoped UPDATE policy on community bucket
DROP POLICY IF EXISTS "Users can update own community files" ON storage.objects;
CREATE POLICY "Users can update own community files"
ON storage.objects
FOR UPDATE
TO authenticated
USING (bucket_id = 'community' AND (auth.uid())::text = (storage.foldername(name))[1])
WITH CHECK (bucket_id = 'community' AND (auth.uid())::text = (storage.foldername(name))[1]);