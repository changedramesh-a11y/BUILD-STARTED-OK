-- Update questions foreign key to cascade on delete
ALTER TABLE public.questions DROP CONSTRAINT IF EXISTS questions_quiz_id_fkey;
ALTER TABLE public.questions ADD CONSTRAINT questions_quiz_id_fkey 
  FOREIGN KEY (quiz_id) REFERENCES public.quizzes(id) ON DELETE CASCADE;

-- Update attempts foreign key to cascade on delete  
ALTER TABLE public.attempts DROP CONSTRAINT IF EXISTS attempts_quiz_id_fkey;
ALTER TABLE public.attempts ADD CONSTRAINT attempts_quiz_id_fkey 
  FOREIGN KEY (quiz_id) REFERENCES public.quizzes(id) ON DELETE CASCADE;

-- Add delete policies for quizzes (ALL already covers it, but ensure attempts can be deleted by admins)
CREATE POLICY "Admins can delete attempts for quiz cleanup"
ON public.attempts FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Moderators can delete attempts for quiz cleanup"
ON public.attempts FOR DELETE
USING (has_role(auth.uid(), 'moderator'::app_role));