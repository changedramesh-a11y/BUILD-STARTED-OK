
ALTER VIEW public.public_questions SET (security_invoker = on);
ALTER VIEW public.public_profiles SET (security_invoker = on);

-- Since public_questions now uses security_invoker, we need a SELECT policy for regular users on the base table
-- But we removed it. Instead, let's use security_barrier = false and keep security_definer but with proper RLS.
-- Actually, let's add a SELECT policy that only exposes non-sensitive columns via the view approach.
-- The simplest fix: add back a SELECT policy for authenticated users only (they still see correct_option via base table, but the client code will use the view)
CREATE POLICY "Authenticated can view questions"
  ON public.questions FOR SELECT
  TO authenticated
  USING (true);
