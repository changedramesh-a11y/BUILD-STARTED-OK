
CREATE OR REPLACE FUNCTION public.get_attempt_questions(p_attempt_id uuid)
RETURNS TABLE(id uuid, question_text text, option_a text, option_b text, option_c text, option_d text, correct_option text, created_at timestamptz)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT q.id, q.question_text, q.option_a, q.option_b, q.option_c, q.option_d, q.correct_option, q.created_at
  FROM public.questions q
  JOIN public.attempts a ON a.quiz_id = q.quiz_id
  WHERE a.id = p_attempt_id AND a.user_id = auth.uid()
  ORDER BY q.created_at;
$$;

GRANT EXECUTE ON FUNCTION public.get_attempt_questions(uuid) TO authenticated;
