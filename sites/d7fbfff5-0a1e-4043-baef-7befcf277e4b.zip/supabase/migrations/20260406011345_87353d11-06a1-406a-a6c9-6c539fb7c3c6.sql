
-- Drop the overly permissive SELECT policy
DROP POLICY "Profiles are viewable by everyone" ON public.profiles;

-- Users can read their own full profile
CREATE POLICY "Users can view own profile"
ON public.profiles
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

-- Create a security definer function to get public profile info without exposing sensitive fields
CREATE OR REPLACE FUNCTION public.get_public_profile(p_user_id uuid)
RETURNS TABLE(user_id uuid, display_name text, about text, avatar_url text)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p.user_id, p.display_name, p.about, p.avatar_url
  FROM public.profiles p
  WHERE p.user_id = p_user_id;
$$;
